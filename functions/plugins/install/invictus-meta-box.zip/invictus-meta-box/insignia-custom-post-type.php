<?php
function testimonial_post_type() {

	$labels = array(
		'name'                  => _x( 'Testimonials', 'Post Type General Name', 'ensign' ),
		'singular_name'         => _x( 'Testimonial', 'Post Type Singular Name', 'ensign' ),
		'menu_name'             => __( 'Testimonial', 'ensign' ),
		'name_admin_bar'        => __( 'Testimonial', 'ensign' ),
		'archives'              => __( 'Testimonial Archives', 'ensign' ),
		'attributes'            => __( 'Item Attributes', 'ensign' ),
		'parent_item_colon'     => __( 'Parent Item:', 'ensign' ),
		'all_items'             => __( 'All Testimonials', 'ensign' ),
		'add_new_item'          => __( 'Add New Testimonial', 'ensign' ),
		'add_new'               => __( 'Add New Testimonial', 'ensign' ),
		'new_item'              => __( 'New Item', 'ensign' ),
		'edit_item'             => __( 'Edit Testimonial', 'ensign' ),
		'update_item'           => __( 'Update Testimonial', 'ensign' ),
		'view_item'             => __( 'View Testimonial', 'ensign' ),
		'view_items'            => __( 'View Testimonials', 'ensign' ),
		'search_items'          => __( 'Search Testimonial', 'ensign' ),
		'not_found'             => __( 'Not found', 'ensign' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'ensign' ),
		'featured_image'        => __( 'Featured Image', 'ensign' ),
		'set_featured_image'    => __( 'Set featured image', 'ensign' ),
		'remove_featured_image' => __( 'Remove featured image', 'ensign' ),
		'use_featured_image'    => __( 'Use as featured image', 'ensign' ),
		'insert_into_item'      => __( 'Insert into Testimonial', 'ensign' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'ensign' ),
		'items_list'            => __( 'Testimonials list', 'ensign' ),
		'items_list_navigation' => __( 'Testimonials list navigation', 'ensign' ),
		'filter_items_list'     => __( 'Filter Testimonials list', 'ensign' ),
	);
	$args = array(
		'label'                 => __( 'Testimonial', 'ensign' ),
		'labels'                => $labels,
                'menu_icon'             => 'dashicons-format-quote',
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
				
		'exclude_from_search'   => true,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'testimonial_post', $args );

}
add_action( 'init', 'testimonial_post_type', 1);



/*
End Testimonial custom post field
*/













// Register Portfolio Custom Post Type


function wp_portfolio() {
	register_post_type( 'portfolio',
		array(
			'labels' => array(
				'name' => ( 'Portfolio' ),
				'singular_name' => ( 'Portfolio' ),
				'add_new' => ( 'Add New ' ),
				'add_new_item' => ( 'Add New Portfolio' ),
				'edit_item' => ( 'Edit Portfolio Item' ),
				'new_item' => ( 'Add New Portfolio Item' ),
				'view_item' => ( 'View Portfolio Item' ),
				'search_items' => ( 'Search Portfolio Item' ),
				'not_found' => ( 'No Portfolio Item found' ),
				'not_found_in_trash' => ( 'No Portfolio Item found in trash' )
			),
			'public' => true,
			'supports' => array( 'title', 'editor', 'thumbnail', 'comments' ),
			'taxonomies' => array('portfolio_category'),
			'capability_type' => 'post',
			'rewrite' => array("slug" => "portfolio"), // Permalinks format
			'menu_position' => 5,
                        'has_archive'           => true,	
                        'menu_icon' => 'dashicons-screenoptions'
		)
	);
}

add_action( 'init', 'wp_portfolio' );


add_action( 'init', 'create_portfolio_tax',0 );

function create_portfolio_tax() {
	register_taxonomy(
		'portfolio_category',
		'portfolio',
		array(
			'label' => __( 'Portfolio Category' ),
			'rewrite' => array( 'slug' => 'portfolio_category' ),
			'hierarchical' => true,
		)
	);
}


// Register Team Custom Post Type





function team_post_type() {

	$labels = array(
		'name'                  => _x( 'Team', 'Post Type General Name', 'ensign' ),
		'singular_name'         => _x( 'Team', 'Post Type Singular Name', 'ensign' ),
		'menu_name'             => __( 'Team', 'ensign' ),
		'name_admin_bar'        => __( 'Team', 'ensign' ),
		'archives'              => __( 'Team Archives', 'ensign' ),
		'attributes'            => __( 'Item Attributes', 'ensign' ),
		'parent_item_colon'     => __( 'Parent Item:', 'ensign' ),
		'all_items'             => __( 'All Team', 'ensign' ),
		'add_new_item'          => __( 'Add New Team', 'ensign' ),
		'add_new'               => __( 'Add New Team', 'ensign' ),
		'new_item'              => __( 'New Item', 'ensign' ),
		'edit_item'             => __( 'Edit Team', 'ensign' ),
		'update_item'           => __( 'Update Team', 'ensign' ),
		'view_item'             => __( 'View Team', 'ensign' ),
		'view_items'            => __( 'View Team', 'ensign' ),
		'search_items'          => __( 'Search Team', 'ensign' ),
		'not_found'             => __( 'Not found', 'ensign' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'ensign' ),
		'featured_image'        => __( 'Featured Image', 'ensign' ),
		'set_featured_image'    => __( 'Set featured image', 'ensign' ),
		'remove_featured_image' => __( 'Remove featured image', 'ensign' ),
		'use_featured_image'    => __( 'Use as featured image', 'ensign' ),
		'insert_into_item'      => __( 'Insert into Team', 'ensign' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'ensign' ),
		'items_list'            => __( 'Team list', 'ensign' ),
		'items_list_navigation' => __( 'Team list navigation', 'ensign' ),
		'filter_items_list'     => __( 'Filter Team list', 'ensign' ),
	);
	$args = array(
		'label'                 => __( 'Team', 'ensign' ),
		'labels'                => $labels,
                'menu_icon'             => 'dashicons-format-quote',
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
				
		'exclude_from_search'   => true,
		'publicly_queryable'    => false,
		'capability_type'       => 'post',
	);
	register_post_type( 'team', $args );

}
add_action( 'init', 'team_post_type', 1);



/*
End Team custom post field
*/
