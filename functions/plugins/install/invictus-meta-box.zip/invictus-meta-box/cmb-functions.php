<?php



global $post;
function get_met($value) {
	$message = $post->ID;
echo $message;
	$field = get_post_meta($post->ID, $value, 1);
	if ( ! empty( $field ) ) {
		return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );
	} else {
		return false;
	}
}
if ( file_exists( plugin_dir_path( __FILE__ ) . '/cmb2/init.php' ) ) {
	require_once plugin_dir_path( __FILE__ ) . '/cmb2/init.php';
} elseif ( file_exists( plugin_dir_path( __FILE__ ) . '/CMB2/init.php' ) ) {
	require_once plugin_dir_path( __FILE__ ) . '/CMB2/init.php';
}


add_action( 'cmb2_init', 'page_header_add_metabox' );
function page_header_add_metabox() {

	$prefix = '_ins_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'page_header',
		'title'        => __( 'Page Header Option', 'ensign' ),
		'object_types' => array( 'page' ),
		'context'      => 'normal',
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'name' => __( 'Page Header', 'ensign' ),
		'id' => $prefix . 'ph_status',
		'type' => 'radio',
		'options' => array(
			'enable' => __( 'Enable', 'ensign' ),
			'disable' => __( 'Disable', 'ensign' ),
		),
	) );

	$cmb->add_field( array(
		'name' => __( 'Page Header Height', 'ensign' ),
		'id' => $prefix . 'ph_height',
		'type' => 'text',
		'desc' => __( 'Enter height of page header. Enter Number with unit for example "300px".', 'cmb2' ),
	) );

	$cmb->add_field( array(
		'name' => __( 'Background Image', 'ensign' ),
		'id' => $prefix . 'ph_image',
		'type' => 'file',
	) );

	$cmb->add_field( array(
		'name' => __( 'Background Color', 'ensign' ),
		'id' => $prefix . 'ph_color',
		'type' => 'colorpicker',
	) );

	$cmb->add_field( array(
		'name' => __( 'Background size', 'ensign' ),
		'id' => $prefix . 'ph_size',
		'type' => 'select',
		'options' => array(
			'inherit from theme option' => __( 'inherit from theme option', 'ensign' ),
			'initial' => __( 'initial', 'ensign' ),
			'inherit' => __( 'inherit', 'ensign' ),
			'contain' => __( 'contain', 'ensign' ),
			'cover' => __( 'cover', 'ensign' ),
		),
	) );

	$cmb->add_field( array(
		'name' => __( 'Background Position', 'ensign' ),
		'id' => $prefix . 'ph_position',
		'type' => 'select',
		'options' => array(
			'inherit from theme option' => __( 'inherit from theme option', 'ensign' ),
			'left top' => __( 'left top', 'ensign' ),
			'left center' => __( 'left center', 'ensign' ),
			'left bottom' => __( 'left bottom', 'ensign' ),
			'right top' => __( 'right top', 'ensign' ),
			'right center' => __( 'right center', 'ensign' ),
			'right bottom' => __( 'right bottom', 'ensign' ),
			'center top' => __( 'center top', 'ensign' ),
			'center center' => __( 'center center', 'ensign' ),
			'center bottom' => __( 'center bottom', 'ensign' ),
		),
	) );

}





/*portfolio metabox*/

add_action( 'cmb2_init', 'ins_add_portfolio_metabox' );
function ins_add_portfolio_metabox() {

	$prefix = '_ins_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'portfolio',
		'title'        => __( 'Portfolio Information', 'ensign' ),
		'object_types' => array( 'portfolio' ),
		'context'      => 'normal',
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'name' => __( 'Client Name', 'ensign' ),
		'id' => $prefix . 'client',
		'type' => 'text',
	) );

	$cmb->add_field( array(
		'name' => __( 'Date', 'ensign' ),
		'id' => $prefix . 'date',
		'type' => 'text_date',
	) );

	$cmb->add_field( array(
		'name' => __( 'Website URL', 'ensign' ),
		'id' => $prefix . 'website',
		'type' => 'text_url',
	) );
	$cmb->add_field( array(
		'name' => __( 'Gallery', 'ensign' ),
		'id' => $prefix . 'portfolio_gallery',
		'type' => 'file_list',
	) );

	$cmb->add_field( array(
		'name' => __( 'Show Portfolio Details', 'ensign' ),
		'id' => $prefix . 'portfolio_details',
		'type' => 'radio_inline',
		'options' => array(
			'enable' => __( 'Enable', 'ensign' ),
			'disable' => __( 'Disable', 'ensign' ),
		),
	) );
}

/*Testimonial Metabox*/
add_action( 'cmb2_init', 'ins_add_testimonial_metabox' );
function ins_add_testimonial_metabox() {

	$prefix = '_ins_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'testimonial',
		'title'        => __( 'Testimonial Options', 'ensign' ),
		'object_types' => array( 'testimonial_post' ),
		'context'      => 'normal',
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'name' => __( 'Author', 'ensign' ),
		'id' => $prefix . 'author',
		'type' => 'text',
	) );

	$cmb->add_field( array(
		'name' => __( 'Position', 'ensign' ),
		'id' => $prefix . 'position',
		'type' => 'text',
	) );

}










/*Team Metabox*/
add_action( 'cmb2_init', 'ins_add_team_metabox' );
function ins_add_team_metabox() {

	$prefix = '_ins_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'team',
		'title'        => __( 'Team Options', 'ensign' ),
		'object_types' => array( 'team' ),
		'context'      => 'normal',
		'priority'     => 'default',
	) );



	$cmb->add_field( array(
		'name' => __( 'Name', 'ensign' ),
		'id' => $prefix . 'name',
		'type' => 'text',
	) );

	$cmb->add_field( array(
		'name' => __( 'Designation', 'ensign' ),
		'id' => $prefix . 'designation',
		'type' => 'text',
	) );

	$cmb->add_field( array(
		'name' => __( 'Company', 'ensign' ),
		'id' => $prefix . 'company',
		'type' => 'text',
	) );
         $cmb->add_field( array(
		'name' => __( 'Phone Number', 'ensign' ),
		'id' => $prefix . 'phone_number',
		'type' => 'text',
	) );

        $cmb->add_field( array(
		'name' => __( 'Email Id', 'ensign' ),
		'id' => $prefix . 'email',
		'type' => 'text',
	) );
  
  

        $cmb->add_field( array(
		'name' => __( 'Facebook', 'ensign' ),
		'id' => $prefix . 'facebook',
		'type' => 'text',
	) );
       
       
        $cmb->add_field( array(
		'name' => __( 'Twitter', 'ensign' ),
		'id' => $prefix . 'twitter',
		'type' => 'text',
	) );

        $cmb->add_field( array(
		'name' => __( 'Youtube', 'ensign' ),
		'id' => $prefix . 'youtube',
		'type' => 'text',
	) );
          $cmb->add_field( array(
		'name' => __( 'Instagram', 'ensign' ),
		'id' => $prefix . 'instagram',
		'type' => 'text',
	) );
           $cmb->add_field( array(
		'name' => __( 'Linkedin', 'ensign' ),
		'id' => $prefix . 'linkedin',
		'type' => 'text',
	) );
     $cmb->add_field( array(
		'name' => __( 'Google Plus', 'ensign' ),
		'id' => $prefix . 'google',
		'type' => 'text',
	) );
      $cmb->add_field( array(
		'name' => __( 'Pinterest', 'ensign' ),
		'id' => $prefix . 'pinterest',
		'type' => 'text',
	) );
  
    



}







add_action( 'cmb2_init', 'ins_add_layout_metabox' );
function ins_add_layout_metabox() {

	$prefix = '_ins_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'layout',
		'title'        => __( 'Select Layout', 'ensign' ),
		'object_types' => array( 'page', 'post' ),
		'context'      => 'side',
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'id' => $prefix . 'select_layout',
		'type' => 'select',
		'default' => 'select_layout',
		'options' => array(
			'select_layout' => __( 'select layout', 'ensign' ),
			'full_width' => __( 'full width', 'ensign' ),
			'left_sidebar' => __( 'left sidebar', 'ensign' ),
			'right_sidebar' => __( 'right sidebar', 'ensign' ),
		),
	) );

}



add_action( 'cmb2_init', 'ins_add_header_footer_metabox' );
function ins_add_header_footer_metabox() {

	$prefix = '_ins_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'header_footer',
		'title'        => __( 'Header Options', 'ensign' ),
		'object_types' => array( 'page', 'post' ),
		'context'      => 'side',
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		//'name' => __( 'Select Header Type', 'ensign' ),
		'id' => $prefix . 'header',
		'type' => 'select',
		'default'  => 'zero',
		'options' => array(
			'zero' => __( 'Select Header', 'ensign' ),
                        'standard' => __( 'Standard Menu', 'ensign' ),
			'hamburger' => __( 'Hamburger Menu', 'ensign' ),
			'top-centered-logo' => __( 'Top Centered Logo Menu', 'ensign' )

			
		),
	) );

}


add_action( 'cmb2_init', 'insignia_add_post_video_metabox' );
function insignia_add_post_video_metabox() {

	$prefix = '_ins_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'post_video',
		'title'        => __( 'Post Video', 'ensign' ),
		'object_types' => array( 'post' ),
		'context'      => 'normal',
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'name' => __( 'YouTube video ID', 'ensign' ),
		'id' => $prefix . 'youtube_video',
		'type' => 'text',
	) );

	$cmb->add_field( array(
		'name' => __( 'Vimeo video ID', 'ensign' ),
		'id' => $prefix . 'vimeo_video',
		'type' => 'text',
	) );

	$cmb->add_field( array(
		'name' => __( 'Self hosted video file in mp4 format', 'ensign' ),
		'id' => $prefix . 'hosted_video_mp4',
		'type' => 'file',
	) );

	$cmb->add_field( array(
		'name' => __( 'Self hosted video file in webM format', 'ensign' ),
		'id' => $prefix . 'hosted_video_webm',
		'type' => 'file',
	) );

}


add_action( 'cmb2_init', 'insignia_add_post_audio_metabox' );
function insignia_add_post_audio_metabox() {

	$prefix = '_ins_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'post_audio',
		'title'        => __( 'Post Audio', 'ensign' ),
		'object_types' => array( 'post' ),
		'context'      => 'normal',
		'priority'     => 'default',
	) );


	$cmb->add_field( array(
		'name' => __( 'Self hosted audio file in mp3 format', 'ensign' ),
		'id' => $prefix . 'hosted_audio',
		'type' => 'file',
	) );

}
add_action( 'cmb2_init', 'insignia_add_post_quote_metabox' );
function insignia_add_post_quote_metabox() {

	$prefix = '_ins_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'post_quote',
		'title'        => __( 'Post Quote', 'ensign' ),
		'object_types' => array( 'post' ),
		'context'      => 'normal',
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'name' => __( 'Quote Text', 'ensign' ),
		'id' => $prefix . 'quote_text',
		'type' => 'wysiwyg',
	) );

	$cmb->add_field( array(
		'name' => __( 'Quote author name', 'ensign' ),
		'id' => $prefix . 'quote_author',
		'type' => 'text',
	) );

	$cmb->add_field( array(
		'name' => __( 'Background color', 'ensign' ),
		'id' => $prefix . 'quote_background_color',
		'default' => '#302f35',
		'type' => 'colorpicker',
	) );

	$cmb->add_field( array(
		'name' => __( 'Quote text color', 'ensign' ),
		'id' => $prefix . 'quote_text_color',
		'default' => '#c1c1c1',
		'type' => 'colorpicker',
	) );

}

add_action( 'cmb2_init', 'insignia_add_post_gallery_metabox' );
function insignia_add_post_gallery_metabox() {

	$prefix = '_ins_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'post_gallery',
		'title'        => __( 'Post Gallery', 'ensign' ),
		'object_types' => array( 'post' ),
		'context'      => 'normal',
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'name' => __( 'Upload Image Gallery', 'ensign' ),
		'id' => $prefix . 'gallery_for_post',
		'type' => 'file_list',
	) );


}



