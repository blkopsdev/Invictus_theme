<?php
/*
Plugin Name: Invictus MetaBox
Plugin URI: http://themes.insigniats.in/
Description: Customize WordPress with powerful, professional Post-types and fields
Version: 1.0
Author: Insignia Technolabs
Author URI: http://insigniatechnolabs.com/
License:  GPL12
*/

	define('META_PLUGIN_PATH', plugin_dir_path( __FILE__ ));

add_action( 'after_setup_theme', 'ins_includes' );
function ins_includes() {
	require_once (META_PLUGIN_PATH . 'cmb-functions.php');
	require_once (META_PLUGIN_PATH . 'insignia-custom-post-type.php');
}