<?php
/***
*
*Instagram widget
*
****/
function insignia_load_widget() {
	register_widget( 'insignia_widget' );
	register_widget('Insignia_Recent_Posts');
}
add_action( 'widgets_init', 'insignia_load_widget' );

// Creating the widget 
class insignia_widget extends WP_Widget {

function __construct() {
parent::__construct(

// Base ID of your widget
'insignia_widget', 

// Widget name will appear in UI
__('Instagram Widget', 'ensign'), 

// Widget description
array( 'description' => __( 'A widget that displays latest Instagram posts', 'ensign' ), ) 
);
}

// Creating widget front-end

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
//$user_id = apply_filters( 'widget_title', $instance['user_id'] );
//$access_token = apply_filters( 'widget_title', $instance['access_token'] );

// before and after widget arguments are defined by themes
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

// This is where you run the code and display the output
	    $userid = $instance[ 'user_id' ];
		$accessToken = $instance[ 'access_token' ];


$json = file_get_contents("https://api.instagram.com/v1/users/$userid/media/recent/?access_token=$accessToken");
$data = json_decode($json);

$images = array();
foreach( $data->data as $user_data ) {
    $images[] = (array) $user_data->images;
}
$standard = array_map( function( $item ) {
    return $item['standard_resolution']->url;
}, $images );

	?>
<div class="insignia_instagram_container clearfix">
	<?php 
     
              $count = 1;
		foreach( $standard as $url ) :
if($count<=9){
?>
	
<div class="col-md-4 col-sm-4 col-xs-4 instagram-widget-padding">
		<a class="group"  href="<?php echo esc_url($url);  ?>"><img src="<?php echo esc_url($url);  ?>" alt="instagram_image" class="road_instagram_img">
<div class="inv-instagram-overlay">
	<div class="inv-instagram-overlay-inner">
		<div class="inv-instagram-overlay-inner2">
			<span class="overlay-icon social-instagram"></span>
		</div>
	</div>
</div>
</a></div>

	<?php 
}
$count++;
endforeach;  ?>
</div>
<?php
echo $args['after_widget'];
}
		
// Widget Backend 
public function form( $instance ) {

if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Instagram', 'ensign' );
}

if ( isset( $instance[ 'user_id' ] ) ) {
$user_id = $instance[ 'user_id' ];
}
else {
$user_id = __( '3054236984', 'ensign' );
}

if ( isset( $instance[ 'access_token' ] ) ) {
$access_token = $instance[ 'access_token' ];
}
else {
$access_token = __( '3054236984.1654d0c.0c7a5e5ba2ef455c9855243da1c6a281', 'ensign' );
}

// Widget admin form
?>
<p>
<label for="<?php echo esc_html($this->get_field_id( 'title' )); ?>"><?php echo esc_html_e( 'Title:','ensign' ); ?></label> 
<input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_html($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_html( $title ); ?>" />
</p>

<p>
<label for="<?php echo esc_html($this->get_field_id( 'user_id' )); ?>"><?php echo esc_html_e( 'UserID:','ensign' ); ?></label> 
<input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'user_id' )); ?>" name="<?php echo esc_html($this->get_field_name( 'user_id' )); ?>" type="text" value="<?php echo esc_html( $user_id ); ?>" />
</p>
<p>You can get your Instagram User-Id from <a href="http://www.ershad7.com/InstagramUserID/" target="_blank">here</a></p>

<p>
<label for="<?php echo esc_html($this->get_field_id( 'access_token' )); ?>"><?php echo esc_html_e( 'Access Token:','ensign' ); ?></label> 
<input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'access_token' )); ?>" name="<?php echo esc_html($this->get_field_name( 'access_token' )); ?>" type="text" value="<?php echo esc_html( $access_token ); ?>" />
</p>
<p>You can get your Instagram Access Token from <a href="http://instagram.pixelunion.net/" target="_blank">here</a></p>
<?php 
}
	
// Updating widget replacing old instances with new
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['user_id'] = ( ! empty( $new_instance['user_id'] ) ) ? strip_tags( $new_instance['user_id'] ) : '';
$instance['access_token'] = ( ! empty( $new_instance['access_token'] ) ) ? strip_tags( $new_instance['access_token'] ) : '';
return $instance;
}
} // Class insignia_widget ends here



/**
*
*Twitter feed
*
**/

/* insignia_Widget_Tweets */

function insignia_twitter_widget() {
	register_widget( 'insignia_Widget_Tweets' );
}
add_action( 'widgets_init', 'insignia_twitter_widget' );

class insignia_Widget_Tweets extends WP_Widget {
	function __construct() {
		$widget_ops = array('Tweets' => 'widget_Tweets', 'description' => __('A widget that displays latest Tweets', 'ensign'));
		parent::__construct('Tweets', __('Tweets', 'ensign'), $widget_ops);
	}

	function widget($args, $instance) {
		extract($args);
		$widget_data = array_merge(array(
			'title' => '',
			'consumer_key' => '',
			'consumer_secret' => '',
			'access_token' => '',
			'access_token_secret' => '',
			'twitter_id' => '',
			'count' => '',
		), $instance);
		echo $before_widget;
		if ($widget_data['title']) {
			echo $before_title . $widget_data['title'] . $after_title;
		}
		if ($widget_data['twitter_id'] && $widget_data['consumer_key'] && $widget_data['consumer_secret'] && $widget_data['access_token'] && $widget_data['access_token_secret'] && $widget_data['count']) {
			$transName = 'list_tweets_' . $args['widget_id'];
			$cacheTime = 10;
			delete_transient($transName);
			if (false === ($twitterData = get_transient($transName))) {
				// require the twitter auth class
				require_once( ABSPATH .'wp-content/plugins/invictus-vc-elements/invictus-widgets/twitteroauth/twitteroauth.php' );
				$twitterConnection = new TwitterOAuth(
					$widget_data['consumer_key'], // Consumer Key
					$widget_data['consumer_secret'], // Consumer secret
					$widget_data['access_token'], // Access token
					$widget_data['access_token_secret'] // Access token secret
				);
				$twitterData = $twitterConnection->get(
					'statuses/user_timeline',
					array(
						'screen_name' => $widget_data['twitter_id'],
						'count' => $widget_data['count'],
						'exclude_replies' => false
					)
				);
				if ($twitterConnection->http_code != 200) {
					$twitterData = get_transient($transName);
				}
				// Save our new transient.
				set_transient($transName, $twitterData, 60 * $cacheTime);
			};
			$twitter = get_transient($transName);
			if ($twitter && is_array($twitter)) {
				?>
				<div class="widget-twitter-box">
					<div class="widget-twitter-holder">
						<div class="b">
							<div class="tweets-container" id="tweets_<?php echo $args['widget_id']; ?>">
								<ul id="insignia-twitter-widget" class="styled">
									<?php foreach ($twitter as $tweet): ?>
									<?php
									$twitterTime = strtotime($tweet->created_at);
									$timeAgo = $this->ago($twitterTime);
									?>
										<li class="widget_list_tweet"><div class="widget_list_tweet_date"><?php echo $timeAgo; ?></div>
											<p class="widget_list_tweet_text tweet-icon-twitter">
												<?php
												$latestTweet = $tweet->text;
												$latestTweet = preg_replace('/https:\/\/([a-z0-9_\.\-\+\&\!\#\~\/\,]+)/i', '&nbsp;<a href="https://$1" target="_blank">https://$1</a>&nbsp;', $latestTweet);
												$latestTweet = preg_replace('/@([a-z0-9_]+)/i', '&nbsp;<a href="https://twitter.com/$1" target="_blank">@$1</a>&nbsp;', $latestTweet);
												echo $latestTweet;
												?>
											</p>



										</li>
									<?php endforeach; ?>
								</ul>
							</div>
						</div>
					</div>
					<span class="arrow"></span>
				</div>
			<?php
			}
		}
		echo $after_widget;
	}

	function ago($time) {
		$periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
		$lengths = array("60", "60", "24", "7", "4.35", "12", "10");
		$now = time();
		$difference = $now - $time;
		$tense = "ago";
		for ($j = 0; $difference >= $lengths[$j] && $j < count($lengths) - 1; $j++) {
			$difference /= $lengths[$j];
		}
		$difference = round($difference);

		if ($difference != 1) {
			$periods[$j] .= "s";
		}
		return "$difference $periods[$j] ago ";
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['consumer_key'] = $new_instance['consumer_key'];
		$instance['consumer_secret'] = $new_instance['consumer_secret'];
		$instance['access_token'] = $new_instance['access_token'];
		$instance['access_token_secret'] = $new_instance['access_token_secret'];
		$instance['twitter_id'] = $new_instance['twitter_id'];
		$instance['count'] = $new_instance['count'];
		return $instance;
	}

	function form($instance) {
		$defaults = array(
			'title' => 'Recent Tweets',
			'twitter_id' => '',
			'count' => 3,
			'consumer_key' => '',
			'consumer_secret' => '',
			'access_token' => '',
			'access_token_secret' => ''
		);
		$instance = wp_parse_args((array)$instance, $defaults); ?>
		<p><?php printf(__('<a href="%s">Find or Create your Twitter App</a>', 'ensign'), 'http://dev.twitter.com/apps'); ?></p>
		<p>
			<label for="<?php echo esc_html($this->get_field_id('title')); ?>"><?php echo esc_html_e('Title:','ensign'); ?> </label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>"
				   name="<?php echo esc_html($this->get_field_name('title')); ?>" value="<?php echo esc_html($instance['title']); ?>"/>
		</p>
		<p>
			<label for="<?php echo esc_html($this->get_field_id('consumer_key')); ?>"><?php echo esc_html_e('Consumer Key:','ensign');?> </label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('consumer_key')); ?>"
				   name="<?php echo esc_html($this->get_field_name('consumer_key')); ?>"
				   value="<?php echo esc_html($instance['consumer_key']); ?>"/>
		</p>

		<p>
			<label for="<?php echo esc_html($this->get_field_id('consumer_secret')); ?>"><?php echo esc_html_e('Consumer Secret:','ensign');?> </label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('consumer_secret')); ?>"
				   name="<?php echo esc_html($this->get_field_name('consumer_secret')); ?>"
				   value="<?php echo esc_html($instance['consumer_secret']); ?>"/>
		</p>
		<p>
			<label for="<?php echo esc_html($this->get_field_id('access_token')); ?>"><?php echo esc_html_e('Access Token:','ensign');?> </label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('access_token')); ?>"
			name="<?php echo esc_html($this->get_field_name('access_token')); ?>"
			value="<?php echo esc_html($instance['access_token']); ?>"/>
		</p>
		<p>
			<label for="<?php echo esc_html($this->get_field_id('access_token_secret')); ?>"><?php echo esc_html_e('Access Token Secret:','ensign');?> </label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('access_token_secret')); ?>"
				   name="<?php echo esc_html($this->get_field_name('access_token_secret')); ?>"
				   value="<?php echo esc_html($instance['access_token_secret']); ?>"/>
		</p>

		<p>
			<label for="<?php echo esc_html($this->get_field_id('twitter_id')); ?>"><?php echo esc_html_e('Twitter ID:','ensign');?> </label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('twitter_id')); ?>"
				   name="<?php echo esc_html($this->get_field_name('twitter_id')); ?>"
				   value="<?php echo esc_html($instance['twitter_id']); ?>"/>
		</p>
		<p>
			<label for="<?php echo esc_html($this->get_field_id('count')); ?>"><?php echo esc_html_e('Number of Tweets:', 'ensign'); ?> </label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('count')); ?>"
				   name="<?php echo esc_html($this->get_field_name('count')); ?>" value="<?php echo esc_html($instance['count']); ?>"/>
		</p>

	<?php
	}
}


class Insignia_Recent_Posts extends WP_Widget {

    function __construct() {
        $widget_ops = array('classname' => 'insignia_widget_recent_entries', 'description' => __( "The most recent posts on your site") );
        parent::__construct('recent-posts', __('Invictus Recent Posts'), $widget_ops);
        $this->alt_option_name = 'insignia_widget_recent_entries';

        add_action( 'save_post', array($this, 'flush_widget_cache') );
        add_action( 'deleted_post', array($this, 'flush_widget_cache') );
        add_action( 'switch_theme', array($this, 'flush_widget_cache') );
    }

    function widget($args, $instance) {
        $cache = wp_cache_get('Insignia_Recent_Posts', 'widget');

        if ( !is_array($cache) )
            $cache = array();

        if ( ! isset( $args['widget_id'] ) )
            $args['widget_id'] = $this->id;

        if ( isset( $cache[ $args['widget_id'] ] ) ) {
            echo $cache[ $args['widget_id'] ];
            return;
        }

        ob_start();
        extract($args);

        $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Recent Posts' );
        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
        $number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 10;
        if ( ! $number )
            $number = 10;
        $show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;

        $r = new WP_Query( apply_filters( 'widget_posts_args', array( 'posts_per_page' => $number, 'no_found_rows' => true, 'post_status' => 'publish', 'ignore_sticky_posts' => true ) ) );
        if ($r->have_posts()) :
?>
        <?php echo $before_widget; ?>
        <?php if ( $title ) echo $before_title . $title . $after_title; ?>
        <ul class="clearfix inv-widget-posts-holder">
        <?php while ( $r->have_posts() ) : $r->the_post(); ?>
            <li class="clearfix inv-widget-posts">
<?php if(has_post_thumbnail()){ ?>
			  <div class="inv-widget-posts-image">
                    <a href="<?php the_permalink(); ?>" style="background-image:url('<?php the_post_thumbnail_url(); ?>');">
                    </a></div> <?php } ?>
                    <div class="inv-widget-posts-content">
                    <div class="inv-widget-posts-item">
                    <a href="<?php the_permalink(); ?>"><?php get_the_title() ? the_title() : the_ID(); ?></a>
                    </div>
            <?php if ( $show_date ) : ?>
                    <div class="inv-widget-posts-date">
                    <span class="post-date"><?php echo get_the_date(); ?></span>
                    </div>
            <?php endif; ?>
			                    </div>
            </li>
        <?php endwhile; ?>
        </ul>
        <?php echo $after_widget; ?>
<?php
        // Reset the global $the_post as this query will have stomped on it
        wp_reset_postdata();

        endif;

        $cache[$args['widget_id']] = ob_get_flush();
        wp_cache_set('Insignia_Recent_Posts', $cache, 'widget');
    }

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['number'] = (int) $new_instance['number'];
        $instance['show_date'] = (bool) $new_instance['show_date'];
        $this->flush_widget_cache();

        $alloptions = wp_cache_get( 'alloptions', 'options' );
        if ( isset($alloptions['insignia_widget_recent_entries']) )
            delete_option('insignia_widget_recent_entries');

        return $instance;
    }

    function flush_widget_cache() {
        wp_cache_delete('Insignia_Recent_Posts', 'widget');
    }

    function form( $instance ) {
        $title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
        $number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
        $show_date = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
?>
        <p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" /></p>

        <p><label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e( 'Number of posts to show:' ); ?></label>
        <input id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="text" value="<?php echo $number; ?>" size="3" /></p>

        <p><input class="checkbox" type="checkbox" <?php checked( $show_date ); ?> id="<?php echo $this->get_field_id( 'show_date' ); ?>" name="<?php echo $this->get_field_name( 'show_date' ); ?>" />
        <label for="<?php echo $this->get_field_id( 'show_date' ); ?>"><?php _e( 'Display post date?' ); ?></label></p>
<?php
    }
}