<?php
/**
 *
 * Testimonial custom field
 *
 */





/*Testimonial Element*/

add_action( 'vc_before_init', 'your_name_integrateWithVC' );
function your_name_integrateWithVC() {

  
   vc_map( array(
      "name" => __( "Testimonials", "ensign" ),
      "base" => "testimonial",
      "class" => "",
       'icon' => 'my_bartag',
      "category" => __( "Insignia", "ensign"),
	"class" => "font-awesome",
	"icon" => "fa fa-quote-right",
     
      "params" => array(
array(
            "type" => "dropdown",
            "class" => "",
            "group" => "General",
            "heading" => __( "Select Testimonial Layout", "ensign" ),
            "param_name" => "testimonial_layout",
            "value"       => array(
       
        
        'Layout 1'   => 'First Option',
        'Layout 2'   => 'Second Option',
        'Layout 3' => 'Third Option',
        'Layout 4'  => 'Fourth Option',
        'Layout 5'  => 'Fifth Option',
        'Layout 6'  => 'Sixth Option'


        
      ),
      
      "std"         => 'Layout 1',
         ),
 array(
            "type" => "textfield",
            "class" => "",
      
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
              "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
            
         ),
         

array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Autoplay", "ensign" ),
            "param_name" => "autoplay",
            "group" => "Carousel setting",
            "value"       => array(
        
        'True'   => 'true',
        'False'   => 'false'
        
      ),
      "std"         => 'True',
        
            "description" => __( "Enable/Disable Autoplay.", "ensign" )
            
         ),
array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Speed", "ensign" ),
            "param_name" => "speed",
            "group" => "Carousel setting",
            "value" => __( "3000", "ensign" ),
      
            "description" => __( "Choose speed for carousel transition in milliseconds (Example:300).", "ensign" )
            
         ),
array(
            "type" => "textfield",
            "class" => "",
          "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesToShow", "ensign" ),
            "param_name" => "slidetoshow",
            "group" => "Carousel setting",
            "value" => __( "1", "ensign" ),
    
            "description" => __( "No. of Testimonials you need to display at a time (Example:3).", "ensign" )
            
         ),
array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesToScroll", "ensign" ),
            "param_name" => "slidetoscroll",
            "group" => "Carousel setting",
            "value" => __( "1", "ensign" ),
      
            "description" => __( "No. of Testimonials you need to scroll at a time (Example:1).", "ensign" )
            
         ),
array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Dots", "ensign" ),
            "param_name" => "testimonial_navigation_dots",
            "group" => "Carousel setting",
            "value"       => array(
       
        'True'   => 'true',
        'False'   => 'false'
        
      ),
      "std"         => '',
            "description" => __( "Dots for navigation.", "ensign" )
            
         ),
array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Arrows", "ensign" ),
            "param_name" => "testimonial_navigation_arrows",
            "group" => "Carousel setting",
            "value"       => array(
        
           'True'   => 'true',
        'False'   => 'false'
        
      ),
      "std"         => '',
            "description" => __( "Arrows for navigation.", "ensign" )
            
         ),
array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "rows", "ensign" ),
            "param_name" => "rows",
            "group" => "Carousel setting",
           
      
            "description" => __( "No. of Rows (Example:2)", "ensign" )
            
         ),
array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesPerRow", "ensign" ),
            "param_name" => "slidesperrow",
            "group" => "Carousel setting",
            "value" => __( "", "ensign" ),
      
            "description" => __( "No. of slidesPerRow (Example:2)", "ensign" )
            
         ),
array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "infinite", "ensign" ),
            "param_name" => "infinite",
            "group" => "Carousel setting",
            "value"       => array(
      
        'True'   => 'true',
        'False'   => 'false'
        
      ),
            "std"         => '',
      
            "description" => __( "Infinite loop sliding.", "ensign" )
            
         ),
array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Testimonial Font Color", "ensign" ),
            "param_name" => "font_color",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Testimonial Font Color.If you leave it empty, It will set theme color", "ensign" )
            

         ),
array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Title Font Color", "ensign" ),
            "param_name" => "title_font_color",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Title Font Color.If you leave it empty, It will set theme color", "ensign" )
            

         ),


array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Designation Font Color", "ensign" ),
            "param_name" => "position_font_color",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Designation Font Color.If you leave it empty, It will set theme color", "ensign" )
            

         ),
array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Content Background Color", "ensign" ),
            "param_name" => "test_bg_color",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Background Color.If you leave it empty, It will set default color", "ensign" ),
            'dependency' => array(
						'element' => 'testimonial_layout',
						'value' => array('Second Option' ,'Fourth Option')
						
                ),
            

         ),

        array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        ),



      )
   ) );
}

add_shortcode( 'testimonial', 'bartag_func' );
function bartag_func( $atts ) {
 extract( shortcode_atts( array(
      'testimonial_layout' => 'Construction',
'testimonial_navigation_arrows' => 'True',
'testimonial_navigation_dots' => 'True',
'slidetoscroll' => '',
'slidetoshow' => '',
'speed' => '',
'autoplay' => '',
'rows' => '',
'slidesperrow' => '',
'extra_class' =>'',
'infinite' => '',
'font_color'=>'',
'title_font_color'=>'',
'position_font_color'=>'',
 'css' => '',

'test_bg_color'=>''
   ), $atts ) );
global $post;   

global $auto1,$speed1,$slidetoshow1,$slidetoscroll1,$testimonial_dots,$testimonial_arrows,$rows1,$slidesperrow1,$infinite1,$extra_class1,$position_font_color1,$title_font_color1,$font_color1,$test_bg_color1,$out,$css1;
$out = ${'testimonial_layout'};
$auto1 = ${'autoplay'};
 $speed1= ${'speed'};
 $slidetoshow1= ${'slidetoshow'};
 $slidetoscroll1= ${'slidetoscroll'};
 $testimonial_dots=${'testimonial_navigation_dots'};
  $testimonial_arrows=${'testimonial_navigation_arrows'};
 $rows1= ${'rows'};
$slidesperrow1 = ${'slidesperrow'};
$infinite1= ${'infinite'};
$extra_class1=${'extra_class'};
$title_font_color1=${'title_font_color'};
$position_font_color1=${'position_font_color'};
$font_color1=${'font_color'};
$test_bg_color1=${'test_bg_color'};
$css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );



if(!isset($extra_class1))
    $extra_class1='';


$loop = new WP_Query( array( 'post_type' => 'testimonial_post') );

 



if($out == "First Option")
{ 

if ($loop->have_posts()){
$return="<div class='".$extra_class1." ".$css1." inv-testimonial-slider slider'>";
  while ( $loop->have_posts() ) : $loop->the_post();
$testimonial_img_src = get_the_post_thumbnail( $post->ID, 'thumbnail' );
$test_author = get_post_meta($post->ID, "_ins_author", true);
$test_position = get_post_meta($post->ID, "_ins_position", true);

$return.="<div class='inv-layout-1-testimonial-layout-wrapper centered-box'>";
if(!empty($testimonial_img_src)){
$return.=$testimonial_img_src;
}
$return.="<div class='inv-layout-1-testimonial-inner inv-layout-1-testimonial-slider'>";
$return.="<p class='inv-layout-1-testimonial-text' style='color:".$font_color1."'>".get_the_content()."</p>";

$return.="<div class='inv-layout-1--testimonial-author'>";
if(!empty($test_author)){
$return.="<h4 class='inv-layout-1-testimonial-author-text' style='color:".$title_font_color1."'>".$test_author."</h4>";
}
if(!empty($test_position)){
$return.="<div class='inv-layout-1-author-position'><span class='inv-layout-1-author-position-text italic-font' style='color:".$position_font_color1."'>".$test_position."</span></div>";
}
$return.="</div>";
$return.="</div>";
$return.="</div>";

endwhile;
 $return .= "</div>";
    
    return $return;
    }
     $return= "<p class='insignia-error-text text-center'>No testimonials found.</p>";
      return $return;
 }



elseif($out == "Second Option")
{ 

if ($loop->have_posts()){
$return="<section class='".$extra_class1." ".$css1." inv-testimonial-slider slider'>";
while ( $loop->have_posts() ) : $loop->the_post(); 
$testimonial_img_src = get_the_post_thumbnail( $post->ID, 'thumbnail' );
$test_author = get_post_meta($post->ID, "_ins_author", true);
$test_position = get_post_meta($post->ID, "_ins_position", true);
$return.="<div class='inv-layout-2-main-test'>";
$return.="<div class='inv-layout-2-testimonial' style='background-color:".$test_bg_color1."'>";
$return.="<div class='inv-layout-2-testimonial-img-box'>";
if(!empty($testimonial_img_src)){
$return.=$testimonial_img_src;
}
$return.="</div>";
$return.="<div class='inv-layout-2-testimonial-name-box'>";
if(!empty($test_author)){
$return.="<p class='pc inv-layout-2-testimonial-name-text' style='color:".$title_font_color1."'>".$test_author."</p>";
}

if(!empty($test_position)){
$return.="<p style='color:".$position_font_color1."'>". $test_position."</p>";
}
$return.="</div>";
$return.="<div class='clearfix'></div>";
$return.="<div class='inv-layout-2-testimonial-text-box' style='color:".$font_color1."'>".get_the_content()."</div>";




$return.="</div>";
$return.="</div>";
endwhile;
$return .= "</section>";
return $return;
}
     $return= "<p class='insignia-error-text text-center'>No testimonials found.</p>";
      return $return;
}






elseif($out == "Third Option")
{ 
if ($loop->have_posts()){
$return="<section class='".$extra_class1." ".$css1." inv-testimonial-slider slider'>";
while ( $loop->have_posts() ) : $loop->the_post(); 
$testimonial_img_src = get_the_post_thumbnail( $post->ID, 'thumbnail' );
$test_author = get_post_meta($post->ID, "_ins_author", true);
$test_position = get_post_meta($post->ID, "_ins_position", true);
$return.= "<div class='inv-layout-3-wrapper'>";
$return.= "<div class='inv-layout-3-inner'>";
if(!empty($testimonial_img_src)){
$return.= "<div class='inv-layout-3-thumb'>".$testimonial_img_src."</div>";
}
$return.="<div class='inv-layout-3-content-main'>";
$return.="<div class='inv-layout-3-content'>";
$return.="<p style='color:".$font_color1."'>".get_the_content()."</p>";
$return.="</div>";
$return.="<div class='inv-layout-3-meta'>";
if(!empty($test_author)){
$return.="<div class='inv-layout-3-author' style='color:".$title_font_color1."'>".$test_author."</div>";
}
if(!empty($test_position)){
$return.="<div class='inv-layout-3-position' style='color:".$position_font_color1."'>".$test_position."</div>";
}
$return.="</div>";
$return.="</div>";
$return.="</div>";
$return.="</div>";

endwhile;
$return .= "</section>";
return $return;
}
     $return= "<p class='insignia-error-text text-center'>No testimonials found.</p>";
      return $return;
}




elseif($out == "Fourth Option")
{ 
if ($loop->have_posts()){
$return="<section class='".$extra_class1." ".$css1." inv-testimonial-slider slider'>";
while ( $loop->have_posts() ) : $loop->the_post(); 
$testimonial_img_src = get_the_post_thumbnail( $post->ID, 'thumbnail' );
$test_author = get_post_meta($post->ID, "_ins_author", true);
$return.= "<div class='inv-layout-4-wrapper'>";
$return.="<div class='inv-layout-4-inner'>";
$return.="<div class='inv-layout-4-testimonials-box'>";
$return.="<div class='inv-layout-4-testimonials-text-box' style='background-color:".$test_bg_color."'>";
$return.="<p style='color:".$font_color1."'>".get_the_content()."</p>";

$return.="</div>";
$return.="<div class='inv-layout-4-testimonials-img-box'>";
if(!empty($testimonial_img_src)){
$return.="<figure>".$testimonial_img_src."</figure>";
}

if(!empty($test_author)){
$return.="<h3 class='inv-layout-4-author' style='color:".$title_font_color1."'>".$test_author."</h3>";
}
$return.="</div>";
$return.="</div>";
$return.="</div>";
$return.="</div>";

endwhile;
$return .= "</section>";
return $return;
}
     $return= "<p class='insignia-error-text text-center'>No testimonials found.</p>";
      return $return;
}


elseif($out == "Fifth Option")
{

if ($loop->have_posts()){
$return="<section class='".$extra_class1." ".$css1." inv-testimonial-slider slider'>";
while ( $loop->have_posts() ) : $loop->the_post(); 
$testimonial_img_src = get_the_post_thumbnail( $post->ID, 'thumbnail' );
$test_author = get_post_meta($post->ID, "_ins_author", true);
$test_position = get_post_meta($post->ID, "_ins_position", true);
$return.="<div class='inv-layout-5-Testimonials-wrapper'>";

$return.="<div class='inv-layout-5-Testimonials-box'>";
$return.="<p style='color:".$font_color1."'>".get_the_content()."</p>";
$return.="<div class='inv-separator-line-holder'>";
$return.="<div class='inv-separator-line-inner'><!--line--></div>";
$return.="</div>";
if(!empty($testimonial_img_src)){
$return.="<div class='inv-layout-5-Testimonials-image-box'>";
$return.="<figure>".$testimonial_img_src."</figure>";
$return.="</div>";
}
$return.="<div class='inv-layout-5-Testimonials-content-box'>";
if(!empty($test_author)){
$return.="<h5 class='inv-layout-5-author' style='color:".$title_font_color1."'>".$test_author."</h5>";
}
if(!empty($test_position)){
$return.="<h6 class='inv-layout-5-position' style='color:".$position_font_color1."'>".$test_position."</h6>";
}
$return.="</div>";

$return.="</div>";
$return.="</div>";


endwhile;
$return .= "</section>";
return $return;
}
     $return= "<p class='insignia-error-text text-center'>No testimonials found.</p>";
      return $return;

}

elseif($out == "Sixth Option")
{

if ($loop->have_posts()){
$return="<section class='".$extra_class1." ".$css1." inv-testimonial-slider slider'>";
while ( $loop->have_posts() ) : $loop->the_post(); 
$test_author = get_post_meta($post->ID, "_ins_author", true);
$test_position = get_post_meta($post->ID, "_ins_position", true);
$return.="<div class='inv-layout-6-Testimonials-wrapper'>";
$return.="<div class='inv-layout-6-testimonial-large-inner inv-layout-6-testimonial-large-slider'>";
$return.="<div class='inv-layout-6-testimonial-large-content centered-box'>";
$return.="<div class='inv-layout-6-testimonial-large-text' style='color:".$font_color1."'>".get_the_content()."</div>";

$return.="<div class='inv-layout-6-testimonial-large-meta' style='color:".$title_font_color1."'>";
$return.="<span class='inv-layout-6-testimonial-large-author' style='color:".$title_font_color1."'>".$test_author."</span> / <span class='inv-layout-6-testimonial-large-job' style='color:".$position_font_color1."'>".$test_position."</span>";
$return.="</div>";

$return.="</div>";

$return.="</div>";
$return.="</div>";


endwhile;
$return .= "</section>";
return $return;
}
     $return= "<p class='insignia-error-text text-center'>No testimonials found.</p>";
      return $return;

}

}
