<?php
/**
 *
 * Section Heading VC element by INSIGNIA
 *
 */



/*Section Heading Element*/


add_action( 'vc_before_init', 'VC_section_heading' );

function VC_section_heading() {
 
 vc_map (

 array(
		"name" => __( "Section Heading", "ensign" ),
		"base" => "insignia_section_heading",
		"class" => "",
		"category" => __( "Insignia", "ensign"),
		"class" => "font-awesome",
		"icon" => "fa fa-header",        
       
      "params" => array(
		array(
			"type" => "textfield",
			"heading" => esc_html__( "Title", "ensign" ),
			"param_name" => "title",
			"description" => esc_html__( "Main heading text.", "ensign" ),
			"value" => "This is a Special Heading" 
		),
		array(
			"type" => "textfield",
			"heading" => esc_html__( "Subtitle", "ensign" ),
			"param_name" => "subtitle",
			"description" => esc_html__( "Smaller text visible below the Title.", "ensign" ),
			"value" => "This is a subtitle, feel free to change it!" 
		),
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Alignment", "ensign" ),
			"param_name" => "align",
			"description" => esc_html__( "Set alignment for the special heading texts.", "ensign" ),
			'value' => array(
			esc_html__( 'Select', "ensign" ) => 'default',
			esc_html__( 'Left', "ensign" ) => 'text-left',
			esc_html__( 'Center', "ensign" ) => 'text-center',
			esc_html__( 'Right', "ensign" ) => 'text-right',
			),
		),

		array(
			"type" => "dropdown",
			"class" => "hidden-label",
			"value" => array(
				esc_html__( "Enable", "ensign" ) => 'enable',
				esc_html__( "Disable", "ensign" ) => 'disable' 
			),
			"heading" => esc_html__( "Separator?", "ensign" ),
			"description" => esc_html__( 'Set below the title Separator', "ensign" ),
			"param_name" => "separator" 
		),

		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', "ensign" ),
			'param_name' => 'extra_class',
			'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', "ensign" ) 
		),

		array(
			"type" => "dropdown",
			"class" => "hidden-label",
			"heading" => esc_html__( "Heading HTML Tag", "ensign" ),
			"param_name" => "heading_tag",
			"value" => array(
			esc_html__( 'Theme defaults' , 'ensign' ) => 'default',
			'h1' => 'h1',
			'h2' => 'h2',
			'h3' => 'h3',
			'h4' => 'h4',
			'h5' => 'h5',  
			'h6' => 'h6',  
			),
			'description' => esc_html__( 'Select a HTML tag for the main heading.', 'ensign' ),
			'group' => esc_html__( "Advanced", "ensign" ) 
		),  
                
               array(
			"type" => "textfield",
			"heading" => esc_html__( "Heading Custom Font-size", "ensign" ),
			"param_name" => "heading_font_size",
			"description" => esc_html__( "Enter Custom font-size(Example:20)", "ensign" ),
			"value" => __( "", "ensign" ),
			'group' => esc_html__( "Advanced", "ensign" ) 

		),    

		array(
			"type" => "dropdown",
			"class" => "hidden-label",
			"heading" => esc_html__( "Heading Font Weight", "ensign" ),
			"param_name" => "font_weight",
			"value" => array(
			esc_html__( 'Theme defaults', 'ensign' ) => 'default',
			esc_html__( '100', 'ensign' ) => 'font-weight-100',
			esc_html__( '200', 'ensign' ) => 'font-weight-200',
			esc_html__( '300', 'ensign' ) => 'font-weight-300',
			esc_html__( '400', 'ensign' ) => 'font-weight-400',
			esc_html__( '500', 'ensign' ) => 'font-weight-500',
			esc_html__( '600', 'ensign' ) => 'font-weight-600',
			esc_html__( '700', 'ensign' ) => 'font-weight-700',
			esc_html__( '900', 'ensign' ) => 'font-weight-900'
			),
			'description' => esc_html__( 'Font weight of the Title.', 'ensign' ),
			'group' => esc_html__( "Advanced", "ensign" ),
		),
		array(
			"type" => "dropdown",
			"class" => "hidden-label",
			"heading" => esc_html__( "Heading Text Transform", "ensign" ),
			"param_name" => "text_transform",
			"value" => array(
			esc_html__( 'Theme defaults', 'ensign' ) => '',
			esc_html__( 'Capitalize', 'ensign' ) => 'text-capitalize', 
			esc_html__( 'Uppercase', 'ensign' ) => 'text-uppercase' 
			),
			'description' => esc_html__( 'Text transform attribute for the Title.', 'ensign' ),
			'group' => esc_html__( "Advanced", "ensign" ) 
		),

		array(
			"type" => "colorpicker",
			"class" => "hidden-label",
			"heading" => esc_html__( "Heading Color", "ensign" ),
			"param_name" => "heading_color",
			"value" => __( "", "ensign" ),
			'description' => esc_html__( 'Select the heading text color.', 'ensign' ),
			'group' => esc_html__( "Advanced", "ensign" ) 
		),

		array(
			"type" => "dropdown",
			"class" => "hidden-label",
			"heading" => esc_html__( "Subtitle Font Size", "ensign" ),
			"param_name" => "subtitle_fs",
			"value" => array(
			esc_html__( 'Theme defaults' , 'ensign' ) => 'default',
			'Extra Small' => 'text-extra-small',
			'Small' => 'text-small',
			'medium' => 'text-medium',
			'large' => 'text-large',
			'extra-large' => 'text-extra-large'
			),
			'description' => esc_html__( 'Size of the subtitle font.', 'ensign' ),
			'group' => esc_html__( "Advanced", "ensign" ) 
		),
		
		array(
			'type'        => 'checkbox',
			'param_name' => 'italic_font',
			'class' => 'hidden-label',
			'group' => esc_html__( 'Advanced', 'ensign' ),
			'value' => array('Subtitle Italic Font'   => '1' ),	
			'description' => esc_html__( 'You can change italic font property from theme options.', 'ensign' ),			
		),
				
		array(
			"type" => "dropdown",
			"class" => "hidden-label",
			"heading" => esc_html__( "Subtitle Text Transform", "ensign" ),
			"param_name" => "subtitle_text_transform",
			"value" => array(
			esc_html__( 'Theme defaults', 'ensign' ) => '',
			esc_html__( 'Capitalize', 'ensign' ) => 'text-capitalize', 
			esc_html__( 'Uppercase', 'ensign' ) => 'text-uppercase' 
			),
			'description' => esc_html__( 'Text transform attribute for the Subtitle.', 'ensign' ),
			'group' => esc_html__( "Advanced", "ensign" ) 
		),

		array(
			"type" => "dropdown",
			"class" => "hidden-label",
			"heading" => esc_html__( "Subtitle Font Weight", "ensign" ),
			"param_name" => "subtitle_font_weight",
			"value" => array(
			esc_html__( 'Theme defaults', 'ensign' ) => '',
			esc_html__( '100', 'ensign' ) => 'font-weight-100',
			esc_html__( '200', 'ensign' ) => 'font-weight-200',
			esc_html__( '300', 'ensign' ) => 'font-weight-300',
			esc_html__( '400', 'ensign' ) => 'font-weight-400',
			esc_html__( '500', 'ensign' ) => 'font-weight-500',
			esc_html__( '600', 'ensign' ) => 'font-weight-600',
			esc_html__( '700', 'ensign' ) => 'font-weight-700',
			esc_html__( '900', 'ensign' ) => 'font-weight-900'
			),
			'description' => esc_html__( 'Font weight of the subtitle.', 'ensign' ),
			'group' => esc_html__( "Advanced", "ensign" ),
		),
		
		array(
			"type" => "colorpicker",
			"class" => "hidden-label",
			"heading" => esc_html__( "Subtitle Color", "ensign" ),
			"param_name" => "subtitle_color",
			"value" => __( "", "ensign" ),
			'description' => esc_html__( 'Select the subtitle text color.', 'ensign' ),
			'group' => esc_html__( "Advanced", "ensign" ) 
		),

		
		array(
			"type" => "colorpicker",
			"class" => "hidden-label",
			"heading" => esc_html__( "Separator Color", "ensign" ),
			"param_name" => "separator_color",
			"value" => __( "", "ensign" ),
			'description' => esc_html__( 'Select the separator border color.', 'ensign' ),
			'group' => esc_html__( "Advanced", "ensign" ) 
		),

		array(
			'type' => 'css_editor',
			'heading' => __( 'Css', 'ensign' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'ensign' ),
			),	
		)
   ));

}
 
add_shortcode( 'insignia_section_heading', 'insignia_section_heading_shortcode' );
function insignia_section_heading_shortcode( $atts,$content) {

	extract( shortcode_atts( array(
      

		"title" => 'This is a Special Heading',
		"subtitle" => 'This is a subtitle, feel free to change it',
		"align" => 'text-left',
		"separator" => 'enable',
		"font_weight" => 'font-weight-600',
		"text_transform" => '',
		"subtitle_fs" => 'text-medium',
		"subtitle_color" => '#343434',
		"subtitle_text_transform" => 'text-capitalize',
		"subtitle_font_weight" => 'font-weight-400',
		"extra_class" => '',
		"heading_tag" => 'h3',
		"italic_font" => '',
		"heading_color" => '#343434',
		"css"=> '',
		"separator_color" => '#343434',
               "heading_font_size" => ''                       
   ), $atts ) );

$css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );


$uniqid = uniqid('ins-heading-');
$css_rules = '';

if($heading_font_size != ''){
$line_height= $heading_font_size + 10;
}


if($heading_font_size != '')
$css_rules .= '#' . $uniqid . ' .ins-section-heading-title-inner {font-size: '.$heading_font_size.'px; line-height:'.$line_height.'px;}';


$subtitle_font = '';
if($italic_font == '1'){
	$subtitle_font = 'italic-font';
}

 //output
	$output = '<div id="'.$uniqid.'" class="inv-section-heading-wrapper '. $align .' position-relative '. $extra_class .' '.$css1.'">';
	if ( $subtitle ) {
	$output .= '<div class="inv-section-heading-subtitle">';
	$output .= '<h6 style="color: '. $subtitle_color .'" class="margin-5px-top margin-10px-bottom '. $subtitle_text_transform .' '.$subtitle_font_weight.' '. $subtitle_fs .' '. $subtitle_font .' ">';
	$output .= $subtitle;
	$output .= '</h6>';
	$output .= '</div>';
	}
	$output .= '<div class="inv-section-heading-title padding-15px-bottom">';
	$output .= '<'.$heading_tag.' style="color: '. $heading_color .'"  class="ins-section-heading-title-inner no-margin '. $text_transform .' '. $font_weight .'">';
	$output .= $title;
	$output .= '</'.$heading_tag.'>';
	$output .= '</div>';
	if ( $separator == 'enable' ) {
	$output .= '<div style="background-color: '. $separator_color .'" class="inv-section-heading-separator"><!--separator--></div>';
	}
	$output .= '</div>';
		if($css_rules != '') {
        $output.=	'<script type="text/javascript">
		(function(jQuery) {';


					$output.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						

					$output.=	'
					})(jQuery);
						</script>';

}
	return $output;
}
