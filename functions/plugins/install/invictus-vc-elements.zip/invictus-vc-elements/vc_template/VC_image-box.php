<?php
/**
 *
 * Image Box VC element by INSIGNIA
 *
 */



/*Image Box Element*/


add_action( 'vc_before_init', 'VC_image_box' );

function VC_image_box() {
  vc_map (

 array(
      "name" => __( "Image Box", "ensign" ),
      "base" => "insignia_image_box",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
	"class" => "font-awesome",
	"icon" => "fa fa-file-image-o",        
       
      "params" => array(

       array(
            "type" => "dropdown",
            "class" => "",
            "heading" => __( "Select Style", "ensign" ),
            "param_name" => "layout_style",
            "group" => "General",
              "description" => __( "Select Image Box layout you would like to use", "ensign" ),
             "value"       => array(
       
       'Select' => '',
        'Style 1'   => 'ins-image-box-layout-1',
        'Style 2'   => 'ins-image-box-layout-2',
        'Style 3'   => 'ins-image-box-layout-3'

        
         ),
      "std"         => '',
            
         ),
      

              array(
      "type" => "attach_image",
      "class" => "",
      "heading" => __( "Add Image", "ensign" ),
      "param_name" => "custom_image",
      "group" => "General",
       "value" => '',
       "description" => __( "Select image of your image box.", "ensign" )
          ),

          array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Title", "ensign" ),
            "param_name" => "image_title",
            "group" => "General",
            "value" => 'Image Box Title ' ,
           
            "description" => __( "The title of your image box.", "ensign" ),

            ),

            array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Number Before Title", "ensign" ),
            "param_name" => "number_box",
            "group" => "General",
            "value" => __( "", "ensign" ),
           
            "description" => __( "Number before title of your image box.", "ensign" ),

            ),
          
           array(
            "type" => "textarea",
            "class" => "",
             
            "heading" => __( "Text Content", "ensign" ),
            "param_name" => "image_text",
            "group" => "General",
             "description" => __( "Description text of the icon box.", "ensign" ),
             "value" => 'Image Box text content, feel free to change it!' 

         ),
         
        array(
                  "type"        => "checkbox",
                  "param_name" => "enable_button",
                  "class" => "",
                  "heading" => __( "Enable Button", "ensign" ),
                  "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
                    "group" => "General",
                     'save_always' => true,
                    "value"         => array('Enable button'   => '1' ),
              ),

     
          array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Button Text", "ensign" ),
            "param_name" => "btn_text",
            "group" => "General",
            "value" => __( "", "ensign" ),
           
            "description" => __( "Button title of your icon box.", "ensign" ),
            'dependency' => array(
						'element' => 'enable_button',
						'value' => array('1')
						
                ),

            ),
             array(
            "type" => "vc_link",

            "class" => "",
            "heading" => __( "Button Link (url)", "ensign" ),
            "param_name" => "btn_link",
            "group" => "General",
            "description" => __( "Button link", "ensign" ),
             "value" => __( "", "ensign" ),
             'dependency' => array(
						'element' => 'enable_button',
						'value' => array('1')
						
                ),

         
            ),
            
            array(
            "type" => "dropdown",
            "class" => "",
              "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Alignment", "ensign" ),
            "param_name" => "box_align",
            "group" => "General",
              "description" => __( "Specify alignment of the image box.", "ensign" ),
             "value"       => array(
         'Select' => 'select',
        'Left'   => 'text-left',
         'Right'   => 'text-right',
          'Center'   => 'text-center'
        

         ),
      "std"         => '',
          
         ),
            
        
         array(
            "type" => "textfield",
            "class" => "",
            
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
            
         ),
         
        
         
          array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Title Font Size", "ensign" ),
            "param_name" => "title_font",
            "group" => "Advanced",
              "description" => __( "Select title font size.", "ensign" ),
             "value"       => array(
       
       'Select' => '',
        'Theme Default'   => 'text-extra-large',
        'Extra Small'   => 'text-extra-small',
        'Small'   => 'text-small',
        'Medium'   => 'text-medium',        
        'Large'   => 'text-large',
        'Extra Large'   => 'text-extra-large'

         
         ),
      "std"         => '',
            
         ),
         
           array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
             "heading" => __( "Text Font Size", "ensign" ),
            "param_name" => "text_font",
            "group" => "Advanced",
              "description" => __( "Select text font size.", "ensign" ),
             "value"       => array(
       
       'Select' => '',
        'Extra Small'   => 'text-extra-small',
        'Small'   => 'text-small',
        'Medium'   => 'text-medium',        
        'Large'   => 'text-large',
        'Extra Large'   => 'text-extra-large'

         
         ),
      "std"         => '',
            
         ),
         
           array(
			"type" => "dropdown",
			 "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",

			"heading" => esc_html__( "Title Font-weight", "ensign" ),
			"param_name" => "title_font_weight",
                        "group" => "Advanced",
                        "description" => esc_html__( "Select Image box title font-weight.", "ensign" ),
                        "value" => array(
			esc_html__( 'Theme defaults', 'ensign' ) => 'default',
			esc_html__( '100', 'ensign' ) => 'font-weight-100',
			esc_html__( '200', 'ensign' ) => 'font-weight-200',
			esc_html__( '300', 'ensign' ) => 'font-weight-300',
			esc_html__( '400', 'ensign' ) => 'font-weight-400',
			esc_html__( '500', 'ensign' ) => 'font-weight-500',
			esc_html__( '600', 'ensign' ) => 'font-weight-600',
			esc_html__( '700', 'ensign' ) => 'font-weight-700',
			esc_html__( '900', 'ensign' ) => 'font-weight-900'
			),
                         
		),

        array(
			"type" => "dropdown",
			 "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",

			"heading" => esc_html__( "Button Font-weight", "ensign" ),
			"param_name" => "btn_font_weight",
                        "group" => "Advanced",
                        "description" => esc_html__( "Select Image box Button Text font-weight.", "ensign" ),
                        "value" => array(
			esc_html__( 'Theme defaults', 'ensign' ) => 'default',
			esc_html__( '100', 'ensign' ) => 'font-weight-100',
			esc_html__( '200', 'ensign' ) => 'font-weight-200',
			esc_html__( '300', 'ensign' ) => 'font-weight-300',
			esc_html__( '400', 'ensign' ) => 'font-weight-400',
			esc_html__( '500', 'ensign' ) => 'font-weight-500',
			esc_html__( '600', 'ensign' ) => 'font-weight-600',
			esc_html__( '700', 'ensign' ) => 'font-weight-700',
			esc_html__( '900', 'ensign' ) => 'font-weight-900'
			),
                         
		),
		
        
  
        array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Title Color", "ensign" ),
            "param_name" => "title_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Title Color.If you leave it empty, It will set default color", "ensign" )
           
             ),
 array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Number Color", "ensign" ),
            "param_name" => "number_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Number Color.If you leave it empty, It will set default color", "ensign" )
           
             ),
             
             array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Text Color", "ensign" ),
            "param_name" => "text_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Text Color.If you leave it empty, It will set default color", "ensign" )
           
             ),
             
             array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Button Color", "ensign" ),
            "param_name" => "btn_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Button Color.If you leave it empty, It will set default color", "ensign" )
           
             ),
             
              array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Background Color", "ensign" ),
            "param_name" => "ins_bg_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Background Color.If you leave it empty, It will set default color", "ensign" ),
               'dependency' => array(
						'element' => 'layout_style',
						'value' => array('ins-image-box-layout-1')
						
                ),
           
             ),

         
            array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        ),
        

     
   ) ));
}

add_shortcode( 'insignia_image_box', 'insignia_image_box_shortcode' );
function insignia_image_box_shortcode( $atts,$content) {

 extract( shortcode_atts( array(
     'layout_style' => '',
     'custom_image' => '',
     'image_title' => esc_html__( 'Image Box Title', "ensign" ),
     'image_text' => esc_html__( 'Image Box text content, feel free to change it!', "ensign" ),
     'enable_button' => '',
     'btn_text' => '',
     'btn_link' => '',
     'extra_class'=>'',
     'css' => '',
     'title_color' => '',
     'text_color' => '',
     'btn_color' => '',
     'title_font' => '',
     'text_font' => '',
     'ins_bg_color' => '',
     'box_align' => '',
     'title_font_weight' => '',
     'btn_font_weight' =>'',
     'number_box' => '',
     'number_color' => ''  
                                
   ), $atts ) );


global $extra_class1,$layout_style1,$custom_image1,$image_title1,$image_text1,$enable_button1,$btn_text1,$btn_link1,$css1,$title_color1,$text_color1,$btn_color1,$title_font1,$text_font1,$ins_bg_color1,$box_align1,$title_font_weight1,$btn_font_weight1,$number_box1,$number_color1;

$extra_class1=${'extra_class'};
$layout_style1=${'layout_style'};
$custom_image1=${'custom_image'};
$image_title1=${'image_title'};
$image_text1=${'image_text'};
$enable_button=${'enable_button'};
$btn_text1=${'btn_text'};
$btn_link1=${'btn_link'};
$title_color1=${'title_color'};
$text_color1=${'text_color'};
$btn_color1=${'btn_color'};
$title_font1=${'title_font'};
$text_font1=${'text_font'};
$ins_bg_color1=${'ins_bg_color'};
$box_align1=${'box_align'};
$title_font_weight1=${'title_font_weight'};
$btn_font_weight1=${'btn_font_weight'};
$number_box1=${'number_box'};
$number_color1=${'number_color'};


$css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );


$uniqid = uniqid('ins-image-box');
$css_rules = '';
if($title_color1 != '')
$css_rules .= '#' . $uniqid . ' .ins-image-box-title-inner {color: '.$title_color1.';}';

if($text_color1!= '')
$css_rules .= '#' . $uniqid . ' .ins-image-box-text {color: '.$text_color1.';}';

if($btn_color1!= '')
$css_rules .= '#' . $uniqid . ' .ins-image-box-btn {color: '.$btn_color1.';}';

if($number_color1 != '')
$css_rules .= '#' . $uniqid . ' .ins-image-box-number {color: '.$number_color1.';}';

if(empty($title_font1)){
   $title_font1= 'text-extra-large';
}

if(empty($ins_bg_color1)){
   $ins_bg_color1= 'bg-white';
}


if($layout_style1  == "ins-image-box-layout-2"){

$return="<div id='".$uniqid."' class='ins-image-box-wrapper ins-image-box-style-2 ".$box_align1." ".$extra_class1." ".$css1."'>";
$return.="<div class='ins-image-box-inner'>";

if(!empty($custom_image1)){
$return.="<div class='ins-image-box-img text-center'>";

$return.="<img src='".wp_get_attachment_url($custom_image1,'large')."'>";

$return.="</div>";
}
$return.="<div class='ins-image-content-wrapper'>";
if(!empty($image_title1)){
$return.="<div class='ins-image-box-title margin-20px-top'>";
$return.="<span class='ins-image-box-title-inner letter-spacing-05 title-font font-weight-500 display-block ".$title_font1." ".$title_font_weight1."'><span class='ins-image-box-number'>".$number_box1."</span> ".$image_title1." </span>";
$return.="<div class='divider-full bg-medium-light-gray'></div>";

$return.="</div>";
}
if(!empty($image_text1)){
$return.="<p class='ins-image-box-text margin-15px-top ".$text_font1."'>".$image_text1."</p>";
}
if(!empty($btn_text1)){
$return.="<div class='ins-image-box-title margin-10px-top'>";
$return.="<a class='ins-image-box-btn text-extra-medium-gray ".$btn_font_weight1."' href='".$btn_link1."'>";
$return.=$btn_text1;
$return.="<i class='fa fa-long-arrow-right'></i>";

$return.="</a>";

$return.="</div>";
}
$return.="</div>";
$return.="</div>";

$return.="</div>";

$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';


return $return;

}elseif($layout_style1  == "ins-image-box-layout-3"){

  $return="<div id='".$uniqid."' class='ins-image-box-wrapper ins-image-box-style-2 ".$box_align1." ".$extra_class1." ".$css1."'>";
$return.="<div class='ins-image-box-inner'>";
if(!empty($image_title1)){
$return.="<div class='ins-image-box-title margin-20px-bottom'>";
$return.="<span class='ins-image-box-title-inner letter-spacing-05 title-font font-weight-500 display-block ".$title_font1." ".$title_font_weight1."'><span class='ins-image-box-number'>".$number_box1."</span> ".$image_title1."</span>";
$return.="<div class='divider-full bg-medium-light-gray'></div>";

$return.="</div>";
}
if(!empty($custom_image1)){
$return.="<div class='ins-image-box-img text-center'>";

$return.="<img src='".wp_get_attachment_url($custom_image1,'large')."'>";

$return.="</div>";
}
$return.="<div class='ins-image-content-wrapper'>";

if(!empty($image_text1)){
$return.="<p class='ins-image-box-text margin-15px-top ".$text_font1."'>".$image_text1."</p>";
}
if(!empty($btn_text1)){
$return.="<div class='ins-image-box-title margin-10px-top'>";
$return.="<a class='ins-image-box-btn text-extra-medium-gray ".$btn_font_weight1."' href='".$btn_link1."'>";
$return.=$btn_text1;
$return.="<i class='fa fa-long-arrow-right'></i>";

$return.="</a>";

$return.="</div>";
}
$return.="</div>";
$return.="</div>";

$return.="</div>";

$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';


return $return;


}else{

$return="<div id='".$uniqid."' class='ins-image-box-wrapper ins-image-box-style-1 ".$box_align1." ".$extra_class1." ".$css1."' style='background-color: ".$ins_bg_color1.";'>";
$return.="<div class='ins-image-box-inner'>";

if(!empty($custom_image1)){
$return.="<div class='ins-image-box-img text-center'>";
$return.="<img src='".wp_get_attachment_url($custom_image1,'large')."'>";

$return.="</div>";
}
$return.="<div class='ins-image-content-wrapper padding-25px-all  border-all'>";
if(!empty($image_title1)){
$return.="<div class='ins-image-box-title margin-10px-bottom'>";
$return.="<span class='ins-image-box-title-inner letter-spacing-05 title-font font-weight-500 display-block ".$title_font1." ".$title_font_weight1."'><span class='ins-image-box-number'>".$number_box1."</span> ".$image_title1."</span>";
$return.="</div>";
}
if(!empty($image_text1)){
$return.="<p class='ins-image-box-text ".$text_font1."'>".$image_text1."</p>";
}
if(!empty($btn_text1)){
$return.="<div class='ins-image-box-title margin-15px-top'>";
$return.="<a class='ins-image-box-btn text-extra-medium-gray ".$btn_font_weight1."' href='".$btn_link1."'>";
$return.=$btn_text1;
$return.="<i class='fa fa-long-arrow-right'></i>";
$return.="</a>";

$return.="</div>";
}
$return.="</div>";
$return.="</div>";

$return.="</div>";

$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';


return $return;


}

}