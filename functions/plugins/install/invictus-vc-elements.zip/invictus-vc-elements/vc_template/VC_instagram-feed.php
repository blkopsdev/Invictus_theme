<?php
/**
 *
 * Instagram Feed VC element by INSIGNIA
 *
 */



/*Instagram Feed Element*/

	 
add_action( 'vc_before_init', 'VC_instagram_feed' );

function VC_instagram_feed() {
  vc_map (

 array(
      "name" => __( "Instagram Feed", "ensign" ),
      "base" => "insignia_instagram_feed",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
       	"class" => "font-awesome",
	"icon" => "fa fa-instagram",
      "params" => array(

   array(
            "type" => "dropdown",
            "class" => "",
             "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "group" => "General",
            "heading" => __( "Select Instagram Field", "ensign" ),
            "param_name" => "insta_field",
            "value"       => array(
       
        'Username'   => 'First Option',
        'Tag'   => 'Second Option'
         
        
      ),
      
      "std"         => "Username",
         ),

      
    array(
            "type" => "textfield",
            "class" => "",
          "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "User Id", "ensign" ),
            "param_name" => "user_id",
            "group" => "General",
              "description" => __( "Enter Instagram user id", "ensign" ),
               'dependency' => array(
						'element' => 'insta_field',
						'value' => array('First Option' ,'Username')
						
                ),             
             
            
         ),
         
             array(
            "type" => "textfield",
            "class" => "",
          "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Tag Name", "ensign" ),
            "param_name" => "tag_name",
            "group" => "General",
              "description" => __( "Enter Tag name", "ensign" ),
              'dependency' => array(
						'element' => 'insta_field',
						'value' => array('Second Option' ,'Tag')
						
                ),
            
         ),
         
         
    array(
            "type" => "textfield",
            "class" => "",
          "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Access Token", "ensign" ),
            "param_name" => "access_token",
            "group" => "General",
              "description" => __( "Enter Access Token", "ensign" )
            
         ),
      array(
            "type" => "textfield",
            "class" => "",
          "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Client Id", "ensign" ),
            "param_name" => "client_id",
            "group" => "General",
              "description" => __( "Enter Client Id", "ensign" )
            
         ),
             array(
            "type" => "textfield",
            "class" => "",
          "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Limit", "ensign" ),
            "param_name" => "limit",
            "group" => "General",
            "value" => __( "", "ensign" ),
              "description" => __( "Maximum number of Images to add. Example:9", "ensign" )
            
         ),
      
                  

       array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
            
         ),
     
     
       
         

        array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Autoplay", "ensign" ),
            "param_name" => "insta_autoplay",
            "group" => "Carousel setting",
            "value"       => array(
       
        'True'   => 'true',
        'False'   => 'false'
        
      ),
      "std"         => 'True',
            "description" => __( "Dots for navigation.", "ensign" )
            
         ),
         

array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Speed", "ensign" ),
            "param_name" => "insta_speed",
            "group" => "Carousel setting",
            "value" => __( "3000", "ensign" ),
      
            "description" => __( "Choose speed for carousel transition in milliseconds (Example:300).", "ensign" )
            
         ),
array(
            "type" => "textfield",
            "class" => "",
          "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesToShow", "ensign" ),
            "param_name" => "insta_slidetoshow",
            "group" => "Carousel setting",
            "value" => __( "1", "ensign" ),
    
            "description" => __( "No. of images you need to display at a time (Example:3).", "ensign" )
            
         ),
array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesToScroll", "ensign" ),
            "param_name" => "insta_slidetoscroll",
            "group" => "Carousel setting",
            "value" => __( "1", "ensign" ),
      
            "description" => __( "No. of images you need to scroll at a time (Example:1).", "ensign" )
            
         ),
array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Dots", "ensign" ),
            "param_name" => "insta_dots",
            "group" => "Carousel setting",
            "value"       => array(
       
        'True'   => 'true',
        'False'   => 'false'
        
      ),
      "std"         => '',
            "description" => __( "Dots for navigation.", "ensign" )
            
         ),
array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Arrows", "ensign" ),
            "param_name" => "insta_arrows",
            "group" => "Carousel setting",
            "value"       => array(
        
           'True'   => 'true',
        'False'   => 'false'
        
      ),
      "std"         => '',
            "description" => __( "Arrows for navigation.", "ensign" )
            
         ),
array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "rows", "ensign" ),
            "param_name" => "insta_rows",
            "group" => "Carousel setting",
           
      
            "description" => __( "No. of Rows (Example:2)", "ensign" )
            
         ),
array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesPerRow", "ensign" ),
            "param_name" => "insta_slidesperrow",
            "group" => "Carousel setting",
            "value" => __( "", "ensign" ),
      
            "description" => __( "No. of slidesPerRow (Example:2)", "ensign" )
            
         ),
array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "infinite", "ensign" ),
            "param_name" => "insta_infinite",
            "group" => "Carousel setting",
            "value"       => array(
      
        'True'   => 'true',
        'False'   => 'false'
        
      ),
            "std"         => '',
      
            "description" => __( "Infinite loop sliding.", "ensign" )
            
         ), 
      
                  
             array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        )     






   ) ));
}

add_shortcode( 'insignia_instagram_feed', 'insignia_instagram_feed_shortcode' );
function insignia_instagram_feed_shortcode( $atts,$content) {
 extract( shortcode_atts( array(
      
      'user_id' => '',
      'access_token' => '',
      'extra_class'=>'',
      'css'=> '',
      'insta_autoplay'=>'',
      'insta_speed'=>'',
      'insta_slidetoshow'=>'',
      'insta_slidetoscroll'=>'',
      'insta_dots'=>'',
      'insta_arrows'=>'',
      'insta_rows'=>'',
      'insta_slidesperrow'=>'',
      'insta_infinite'=>'',
      'insta_field'=>'',
      'tag_name'=>'',
      'limit'=>'',
     'client_id'=>''

   ), $atts ) );


global $user_id1,$access_token1,$extra_class1,$css1,$insta_autoplay1,$insta_speed1,$insta_slidetoshow1,$insta_slidetoscroll1,$insta_dots1,$insta_arrows1,$insta_rows1,$insta_slidesperrow1,$insta_infinite1, $insta_field1,$tag_name1,$limit1,$client_id1; 

$user_id1= ${'user_id'};
$access_token1= ${'access_token'};
$extra_class1=${'extra_class'};
$insta_autoplay1 = ${'insta_autoplay'};
 $insta_speed1= ${'insta_speed'};
 $insta_slidetoshow1= ${'insta_slidetoshow'};
 $insta_slidetoscroll1= ${'insta_slidetoscroll'};
 $insta_dots1=${'insta_dots'};
  $insta_arrows1=${'insta_arrows'};
 $insta_rows1= ${'insta_rows'};
$insta_slidesperrow1 = ${'insta_slidesperrow'};
$insta_infinite1= ${'insta_infinite'};
$insta_field1= ${'insta_field'};
$tag_name1= ${'tag_name'};
$limit1= ${'limit'};
$client_id1= ${'client_id'};



$css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );


if(!isset($extra_class1))
    $extra_class1='';
 
$return="<div id='instafeed' class='".$extra_class1." ".$css1."'>";
$return.="</div>";
    return $return;

}


