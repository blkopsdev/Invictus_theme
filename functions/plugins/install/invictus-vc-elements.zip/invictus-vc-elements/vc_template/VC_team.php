<?php
/**
 *
 * Team VC element by INSIGNIA
 *
 */



/*Team Element*/

add_action( 'vc_before_init', 'insignia_team' );

function insignia_team() {
$team_array = array();
array_unshift($team_array,"Select Team Member"); 
$loops = get_posts( array( 'post_type' => 'team','posts_per_page' => '-1') ); 

foreach( $loops as $loop ):
$team_array[] =$loop->post_title;

endforeach; 

  vc_map (

 array(
      "name" => __( "Team Member", "ensign" ),
      "base" => "team_member",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
        "class" => "font-awesome",
	"icon" => "fa fa-user",
       
      
      "params" => array(
          array(
            "type" => "dropdown",
            "class" => "",
             "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "group" => "General",
            "heading" => __( "Select Team Layout", "ensign" ),
            "param_name" => "team_layout",
            "value"       => array(
        'Select Team Layout'=>'None',
        'Layout 1'   => 'First Option',
        'Layout 2'   => 'Second Option',
         'Layout 3'   => 'Third Option',
         'Layout 4'   => 'Fourth Option',
         'Layout 5'   => 'Fifth Option',
         'Layout 6'   => 'Sixth Option',
         'Layout 7'   => 'Seventh Option'




     
        
        
      ),
      
      "std"         => " ",
         ),
         
          array(
            "type" => "dropdown",
            "class" => "",
            
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Select Team member", "ensign" ),
            "param_name" => "logo_team",
            "group" => "General",
            "value"       => $team_array, 
                      
            "description" => __( "Select Team Member", "ensign" )
           

      ),
       
      
      
  
   array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        ),
          
   
      
      
     array(
            "type" => "textfield",
            "class" => "",
      
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
              "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
            
         ),


   ) ));
}



add_shortcode( 'team_member', 'team_member' );


function team_member( $atts ) {
$css = '';
 extract( shortcode_atts( array(
 'logo_team' => '',       
 'team_layout' => '',
 'extra_class' => '',
 'css' => ''

   ), $atts ) );
global $post;   
$team_out = ${'team_layout'};

global $extra_class1,$logo_team1,$css1,$team_layout1 ;


$team_layout1 = ${'team_layout'};
$extra_class1=${'extra_class'};
$logo_team1 = ${'logo_team'};

$css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );








if(!isset($extra_class1))
    $extra_class1='';

$logo_loop = new WP_Query( array(
    'post_type' => 'team',
     's' => $logo_team1
        )
    
); 




if($team_out == "First Option"){
if ($logo_loop->have_posts()){

while ( $logo_loop ->have_posts() ) : $logo_loop ->the_post();

$image_attributes = wp_get_attachment_image( get_post_thumbnail_id($post->ID), array( '400', '400' ));
$ins_name = get_post_meta($post->ID, "_ins_name", true);
$ins_position = get_post_meta($post->ID, "_ins_designation", true);
$return="<div class='inv-team-member-2-wrapper ".$extra_class1." ".$css1."'>";

$return.="<div class='row'>";
$return.="<div class='inv-team-member-2-inner'>";
 
if(!empty($image_attributes)){
$return.="<div class='inv-team-member-2-thumb'>";
$return.= $image_attributes;
$return.="</div>";
}
$return.="<div class='inv-team-member-2-details clearfix'>";
$return.="<div class='inv-team-member-2-details-inner inv-team-member-section-bg'>";

 if(!empty($ins_name)){ 
$return.="<div class='inv-team-member-name'>".$ins_name."</div>";
}
 if(!empty($ins_position)){ 
$return.="<div class='inv-team-member-position'>".$ins_position."</div>";
}


$return.="<div class='inv-social-media-section'>";
$return.="<ul>";

       $social_facebook = get_post_meta($post->ID, "_ins_facebook", true);
       if (isset($social_facebook ) && $social_facebook != '') { 
       $return.="<li><a href='". get_post_meta($post->ID, "_ins_facebook", true)."' target='_blank'><i class='fa fa-facebook icons inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
         }


         $social_twitter = get_post_meta($post->ID, "_ins_twitter", true);
       if (isset($social_twitter ) && $social_twitter != '') { 
 	$return.="<li><a href='". get_post_meta($post->ID, "_ins_twitter", true)."' target='_blank'><i class='fa fa-twitter inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }

         $social_linkedin = get_post_meta($post->ID, "_ins_linkedin", true);
       if (isset($social_linkedin ) && $social_linkedin != '') { 
 	$return.="<li><a href='". get_post_meta($post->ID, "_ins_linkedin", true)."' target='_blank'><i class='fa fa-linkedin inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }
        
         $social_pinterest = get_post_meta($post->ID, "_ins_pinterest", true);
       if (isset($social_pinterest ) && $social_pinterest != '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_pinterest", true)."' target='_blank'> <i class='fa fa-pinterest-p inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }
       
          $social_youtube = get_post_meta($post->ID, "_ins_youtube", true);
       if (isset($social_youtube) && $social_youtube!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_youtube", true)."' target='_blank'><i class='fa fa-youtube-play inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
         }
         
         $social_instagram = get_post_meta($post->ID, "_ins_instagram", true);
       if (isset($social_instagram ) && $social_instagram!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_instagram", true)."' target='_blank'><i class='fa fa-instagram inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }

         $social_google = get_post_meta($post->ID, "_ins_google", true);
          if (isset($social_google ) && $social_google!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_google", true)."' target='_blank'><i class='fa fa-google-plus inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
       }

    

$return.="</ul>";
$return.="</div>";
$return.="</div>";

$return.="</div>";
$return.="</div>";
$return.="</div>";
$return.="</div>";


endwhile;

 return $return;
}else{
	     $return= "<p class='insignia-error-text text-center'>No Team Member found.</p>";
      return $return;
}
}


elseif($team_out == "Second Option"){
if ($logo_loop->have_posts()){

while ( $logo_loop ->have_posts() ) : $logo_loop ->the_post();
$image_attributes = wp_get_attachment_image( get_post_thumbnail_id($post->ID));
$ins_name = get_post_meta($post->ID, "_ins_name", true);
$ins_position = get_post_meta($post->ID, "_ins_designation", true);
$return="<div class='inv-team-seven-wrapper ".$extra_class1." ".$css1."'>";
$return.="<div class='inv-team-seven-inner centered-box'>";
if(!empty($image_attributes)){
$return.="<div class='inv-team-seven-image'>";
$return.= $image_attributes;
$return.="</div>";
}
$return.="<div class='inv-team-seven-info'>";
 if(!empty($ins_name)){ 
$return.="<div class='inv-team-member-name'>".$ins_name."</div>";
}
 if(!empty($ins_position)){ 
$return.="<div class='inv-team-member-position'>".$ins_position."</div>";
}
$return.="<div class='inv-social-media-section'>";
$return.="<ul>";

       $social_facebook = get_post_meta($post->ID, "_ins_facebook", true);
       if (isset($social_facebook ) && $social_facebook != '') { 
       $return.="<li><a href='". get_post_meta($post->ID, "_ins_facebook", true)."' target='_blank'><i class='fa fa-facebook icons inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
         }

         $social_twitter = get_post_meta($post->ID, "_ins_twitter", true);
       if (isset($social_twitter ) && $social_twitter != '') { 
 	$return.="<li><a href='". get_post_meta($post->ID, "_ins_twitter", true)."' target='_blank'><i class='fa fa-twitter inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }

         $social_linkedin = get_post_meta($post->ID, "_ins_linkedin", true);
       if (isset($social_linkedin ) && $social_linkedin != '') { 
 	$return.="<li><a href='". get_post_meta($post->ID, "_ins_linkedin", true)."' target='_blank'><i class='fa fa-linkedin inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }
        
         $social_pinterest = get_post_meta($post->ID, "_ins_pinterest", true);
       if (isset($social_pinterest ) && $social_pinterest != '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_pinterest", true)."' target='_blank'> <i class='fa fa-pinterest-p inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }
        
          $social_youtube = get_post_meta($post->ID, "_ins_youtube", true);
       if (isset($social_youtube) && $social_youtube!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_youtube", true)."' target='_blank'><i class='fa fa-youtube-play inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
         }

         $social_instagram = get_post_meta($post->ID, "_ins_instagram", true);
       if (isset($social_instagram ) && $social_instagram!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_instagram", true)."' target='_blank'><i class='fa fa-instagram inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }


         $social_google = get_post_meta($post->ID, "_ins_google", true);
          if (isset($social_google ) && $social_google!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_google", true)."' target='_blank'><i class='fa fa-google-plus inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
       }

$return.="</ul>";
$return.="</div>";
$return.="</div>";
$return.="</div>";
$return.="</div>";


endwhile;

 return $return;
 }else{
	     $return= "<p class='insignia-error-text text-center'>No Team Member found.</p>";
      return $return;
}
}



elseif($team_out == "Third Option"){
if ($logo_loop->have_posts()){

while ( $logo_loop ->have_posts() ) : $logo_loop ->the_post();
$image_attributes = wp_get_attachment_image( get_post_thumbnail_id($post->ID), array( '400', '400' ));
$ins_name = get_post_meta($post->ID, "_ins_name", true);
$ins_position = get_post_meta($post->ID, "_ins_designation", true);
$return="<div class='event-Team-box ".$extra_class1." ".$css1."'>";
if(!empty($image_attributes)){
$return.="<div class='event-Team-img-box'>";
$return.= $image_attributes;
$return.="</div>";
}
$return.="<div class='event-Team-details-box'>";
 if(!empty($ins_name)){ 
$return.="<div class='inv-team-member-name'>".$ins_name."</div>";
}
 if(!empty($ins_position)){ 
$return.="<div class='inv-team-member-position pc-bg event-position-field'>".$ins_position."</div>";
}

$return.="</div>";
$return.="</div>";


endwhile;

 return $return;
  }else{
	     $return= "<p class='insignia-error-text text-center'>No Team Member found.</p>";
      return $return;
}
}


elseif($team_out == "Fourth Option"){
if ($logo_loop->have_posts()){

while ( $logo_loop ->have_posts() ) : $logo_loop ->the_post();
$image_attributes = wp_get_attachment_image( get_post_thumbnail_id($post->ID), array( '400', '400' ));
$ins_name = get_post_meta($post->ID, "_ins_name", true);
$ins_position = get_post_meta($post->ID, "_ins_designation", true);
$ins_phone = get_post_meta($post->ID, "_ins_phone_number", true);
$ins_email = get_post_meta($post->ID, "_ins_email", true);

$return="<div class='hospital-team-wrapper ".$extra_class1." ".$css1."'>";

$return.="<div class='hospital-team-inner'>";
if(!empty($image_attributes)){
$return.="<div class='hospital-team-thumb'>";
$return.= $image_attributes;
$return.="</div>";
}
$return.="<div class='hospital-team-detail inv-team-member-section-bg'>";

if(!empty($ins_name)){ 
$return.="<div class='inv-team-member-name'>".$ins_name."</div>";
}
 if(!empty($ins_position)){ 
$return.="<div class='inv-team-member-position hospital-team-position'>".$ins_position."</div>";
}
 if(!empty($ins_phone)){ 
$return.="<div class='inv-team-member-phone'>".$ins_phone."</div>";
}
 if(!empty($ins_email)){ 
$return.="<div class='inv-team-member-email'><i class='fa fa-envelope-o inv-team-member-meta-icon' aria-hidden='true'><!--icon--></i> <a href='mailto:"
. $ins_email . "'>" . $ins_email . "</a></div>";
}

$return.="<div class='inv-social-media-section'>";
$return.="<ul>";

       $social_facebook = get_post_meta($post->ID, "_ins_facebook", true);
       if (isset($social_facebook ) && $social_facebook != '') { 
       $return.="<li><a href='". get_post_meta($post->ID, "_ins_facebook", true)."' target='_blank'><i class='fa fa-facebook icons inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
         }

         $social_twitter = get_post_meta($post->ID, "_ins_twitter", true);
       if (isset($social_twitter ) && $social_twitter != '') { 
 	$return.="<li><a href='". get_post_meta($post->ID, "_ins_twitter", true)."' target='_blank'><i class='fa fa-twitter inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }

         $social_linkedin = get_post_meta($post->ID, "_ins_linkedin", true);
       if (isset($social_linkedin ) && $social_linkedin != '') { 
 	$return.="<li><a href='". get_post_meta($post->ID, "_ins_linkedin", true)."' target='_blank'><i class='fa fa-linkedin inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }
        
         $social_pinterest = get_post_meta($post->ID, "_ins_pinterest", true);
       if (isset($social_pinterest ) && $social_pinterest != '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_pinterest", true)."' target='_blank'> <i class='fa fa-pinterest-p inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }
        
          $social_youtube = get_post_meta($post->ID, "_ins_youtube", true);
       if (isset($social_youtube) && $social_youtube!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_youtube", true)."' target='_blank'><i class='fa fa-youtube-play inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
         }

         $social_instagram = get_post_meta($post->ID, "_ins_instagram", true);
       if (isset($social_instagram ) && $social_instagram!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_instagram", true)."' target='_blank'><i class='fa fa-instagram inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }


         $social_google = get_post_meta($post->ID, "_ins_google", true);
          if (isset($social_google ) && $social_google!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_google", true)."' target='_blank'><i class='fa fa-google-plus inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
       }

$return.="</ul>";
$return.="</div>";


$return.="</div>";

$return.="<div class='separator-line-holder'>";
$return.="<div class='separator-line-inner'><!--line--></div>";
$return.="</div>";
$return.="</div>";
$return.="</div>";

endwhile;

 return $return;
 }else{
	     $return= "<p class='insignia-error-text text-center'>No Team Member found.</p>";
      return $return;
}
}


elseif($team_out == "Fifth Option"){
if ($logo_loop->have_posts()){

while ( $logo_loop ->have_posts() ) : $logo_loop ->the_post();
$image_attributes = wp_get_attachment_image( get_post_thumbnail_id($post->ID));
$ins_name = get_post_meta($post->ID, "_ins_name", true);
$ins_position = get_post_meta($post->ID, "_ins_designation", true);
$ins_phone = get_post_meta($post->ID, "_ins_phone_number", true);
$ins_email = get_post_meta($post->ID, "_ins_email", true);

$return="<div class='inv-team-small-wrapper ".$extra_class1." ".$css1."'>";

$return.="<div class='inv-team-small-inner inv-team-member-section-bg'>";
if(!empty($image_attributes)){
$return.="<div class='inv-team-small-thumb'>";
$return.= $image_attributes;
$return.="</div>";
}
$return.="<div class='inv-team-small-content'>";

if(!empty($ins_name)){ 
$return.="<div class='inv-team-small-name inv-team-member-name'>".$ins_name."</div>";
}
 if(!empty($ins_position)){ 
$return.="<div class='inv-team-member-position inv-team-small-job'>".$ins_position."</div>";
}
$return.="</div>";

$return.="<div class='inv-team-small-meta'>";
if(!empty($ins_phone)){ 
$return.="<div class='inv-team-member-phone'><span class='ti-headphone-alt team-icon inv-team-member-meta-icon'><!--icon--></span>".$ins_phone."</div>";
}
 if(!empty($ins_email)){ 
$return.="<div class='inv-team-member-email'><span class='ti-email team-icon inv-team-member-meta-icon'><!--icon--></span><a href='mailto:"
. $ins_email . "'>" . $ins_email . "</a></div>";
}

$return.="<div class='inv-social-media-section'>";
$return.="<ul>";

       $social_facebook = get_post_meta($post->ID, "_ins_facebook", true);
       if (isset($social_facebook ) && $social_facebook != '') { 
       $return.="<li><a href='". get_post_meta($post->ID, "_ins_facebook", true)."' target='_blank'><i class='fa fa-facebook icons inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
         }

         $social_twitter = get_post_meta($post->ID, "_ins_twitter", true);
       if (isset($social_twitter ) && $social_twitter != '') { 
 	$return.="<li><a href='". get_post_meta($post->ID, "_ins_twitter", true)."' target='_blank'><i class='fa fa-twitter inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }

         $social_linkedin = get_post_meta($post->ID, "_ins_linkedin", true);
       if (isset($social_linkedin ) && $social_linkedin != '') { 
 	$return.="<li><a href='". get_post_meta($post->ID, "_ins_linkedin", true)."' target='_blank'><i class='fa fa-linkedin inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }
        
         $social_pinterest = get_post_meta($post->ID, "_ins_pinterest", true);
       if (isset($social_pinterest ) && $social_pinterest != '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_pinterest", true)."' target='_blank'> <i class='fa fa-pinterest-p inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }
        
          $social_youtube = get_post_meta($post->ID, "_ins_youtube", true);
       if (isset($social_youtube) && $social_youtube!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_youtube", true)."' target='_blank'><i class='fa fa-youtube-play inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
         }

         $social_instagram = get_post_meta($post->ID, "_ins_instagram", true);
       if (isset($social_instagram ) && $social_instagram!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_instagram", true)."' target='_blank'><i class='fa fa-instagram inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }


         $social_google = get_post_meta($post->ID, "_ins_google", true);
          if (isset($social_google ) && $social_google!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_google", true)."' target='_blank'><i class='fa fa-google-plus inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
       }

$return.="</ul>";
$return.="</div>";
$return.="</div>";


$return.="</div>";

$return.="</div>";

endwhile;

 return $return;
 }else{
	     $return= "<p class='insignia-error-text text-center'>No Team Member found.</p>";
      return $return;
}
}


elseif($team_out == "Sixth Option"){
if ($logo_loop->have_posts()){

while ( $logo_loop ->have_posts() ) : $logo_loop ->the_post();
$image_attributes = wp_get_attachment_image( get_post_thumbnail_id($post->ID), array( '400', '400' ));
$ins_name = get_post_meta($post->ID, "_ins_name", true);
$ins_position = get_post_meta($post->ID, "_ins_designation", true);

$return="<div class='inv-team-six-wrapper ".$extra_class1." ".$css1."'>";

$return.="<div class='inv-team-six-inner'>";

$return.="<div class='inv-team-six-image'>";
$return.= $image_attributes;
$return.="<div class='inv-team-six-info-holder inv-team-member-section-bg'>";
$return.="<div class='inv-team-six-info'>";
$return.="<div class='inv-team-six-info-inner'>";

if(!empty($ins_name)){ 
$return.="<div class='inv-team-six-title-holder inv-team-member-name'>".$ins_name."</div>";
}
if(!empty($ins_position)){ 
$return.="<div class='inv-team-member-position inv-team-six-job-holder'>".$ins_position."</div>";
}

$return.="<div class='inv-team-six-social-holder'>";

$return.="<div class='inv-social-media-section inv-team-six-social-inner'>";
$return.="<ul>";

       $social_facebook = get_post_meta($post->ID, "_ins_facebook", true);
       if (isset($social_facebook ) && $social_facebook != '') { 
       $return.="<li><a href='". get_post_meta($post->ID, "_ins_facebook", true)."' target='_blank'><i class='fa fa-facebook icons inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
         }

         $social_twitter = get_post_meta($post->ID, "_ins_twitter", true);
       if (isset($social_twitter ) && $social_twitter != '') { 
 	$return.="<li><a href='". get_post_meta($post->ID, "_ins_twitter", true)."' target='_blank'><i class='fa fa-twitter inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }

         $social_linkedin = get_post_meta($post->ID, "_ins_linkedin", true);
       if (isset($social_linkedin ) && $social_linkedin != '') { 
 	$return.="<li><a href='". get_post_meta($post->ID, "_ins_linkedin", true)."' target='_blank'><i class='fa fa-linkedin inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }
        
         $social_pinterest = get_post_meta($post->ID, "_ins_pinterest", true);
       if (isset($social_pinterest ) && $social_pinterest != '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_pinterest", true)."' target='_blank'> <i class='fa fa-pinterest-p inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }
        
          $social_youtube = get_post_meta($post->ID, "_ins_youtube", true);
       if (isset($social_youtube) && $social_youtube!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_youtube", true)."' target='_blank'><i class='fa fa-youtube-play inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
         }

         $social_instagram = get_post_meta($post->ID, "_ins_instagram", true);
       if (isset($social_instagram ) && $social_instagram!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_instagram", true)."' target='_blank'><i class='fa fa-instagram inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }


         $social_google = get_post_meta($post->ID, "_ins_google", true);
          if (isset($social_google ) && $social_google!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_google", true)."' target='_blank'><i class='fa fa-google-plus inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
       }

$return.="</ul>";
$return.="</div>";


$return.="</div>";
$return.="</div>";
$return.="</div>";
$return.="</div>";
$return.="</div>";
$return.="</div>";
$return.="</div>";

endwhile;

 return $return;
 }else{
	     $return= "<p class='insignia-error-text text-center'>No Team Member found.</p>";
      return $return;
}
}


elseif($team_out == "Seventh Option"){
	if ($logo_loop->have_posts()){
while ( $logo_loop ->have_posts() ) : $logo_loop ->the_post();
$image_attributes = wp_get_attachment_image( get_post_thumbnail_id($post->ID), array( '400', '400' ));
$ins_name = get_post_meta($post->ID, "_ins_name", true);
$ins_phone = get_post_meta($post->ID, "_ins_phone_number", true);
$ins_email = get_post_meta($post->ID, "_ins_email", true);
$return="<div class='gym-team-main-box ".$extra_class1." ".$css1."'>";
$return.="<div class='gym-team-member-main-box'>";
$return.="<div class='gym-team-box inv-team-member-section-bg'>";
if(!empty($image_attributes)){
$return.="<div class='gym-team-img-info col-lg-6 col-md-6 col-sm-6 col-sm-6 col-xs-12'>";
$return.="<figure>";
$return.= $image_attributes;
$return.="</figure>";
$return.="</div>";
}
$return.="<div class='gym-team-info col-lg-6 col-md-6 col-sm-6 col-sm-6 col-xs-12'>";
if(!empty($ins_name)){ 
$return.="<div class='inv-team-member-name gym-team-name'>".$ins_name."</div>";
}

$return.="<div class='inv-team-member-content'>".get_the_excerpt()."</div>";
$return.="<div class='gym-bottom-info-section'>";

if(!empty($ins_phone)){ 
$return.="<div class='inv-team-member-phone'><span class='ti-headphone-alt inv-team-member-meta-icon team-icon'><!--icon--></span>".$ins_phone."</div>";
}
 if(!empty($ins_email)){ 
$return.="<div class='inv-team-member-email'><span class='ti-email inv-team-member-meta-icon team-icon'><!--icon--></span><a href='mailto:"
. $ins_email . "'>" . $ins_email . "</a></div>";
}
$return.="</div>";

$return.="<div class='inv-social-media-section gym-social-media-section'>";
$return.="<ul>";

       $social_facebook = get_post_meta($post->ID, "_ins_facebook", true);
       if (isset($social_facebook ) && $social_facebook != '') { 
       $return.="<li><a href='". get_post_meta($post->ID, "_ins_facebook", true)."' target='_blank'><i class='fa fa-facebook icons inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
         }

         $social_twitter = get_post_meta($post->ID, "_ins_twitter", true);
       if (isset($social_twitter ) && $social_twitter != '') { 
 	$return.="<li><a href='". get_post_meta($post->ID, "_ins_twitter", true)."' target='_blank'><i class='fa fa-twitter inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }

         $social_linkedin = get_post_meta($post->ID, "_ins_linkedin", true);
       if (isset($social_linkedin ) && $social_linkedin != '') { 
 	$return.="<li><a href='". get_post_meta($post->ID, "_ins_linkedin", true)."' target='_blank'><i class='fa fa-linkedin inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }
        
         $social_pinterest = get_post_meta($post->ID, "_ins_pinterest", true);
       if (isset($social_pinterest ) && $social_pinterest != '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_pinterest", true)."' target='_blank'><i class='fa fa-pinterest-p inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }
        
          $social_youtube = get_post_meta($post->ID, "_ins_youtube", true);
       if (isset($social_youtube) && $social_youtube!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_youtube", true)."' target='_blank'><i class='fa fa-youtube-play inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
         }

         $social_instagram = get_post_meta($post->ID, "_ins_instagram", true);
       if (isset($social_instagram ) && $social_instagram!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_instagram", true)."' target='_blank'><i class='fa fa-instagram inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
        }


         $social_google = get_post_meta($post->ID, "_ins_google", true);
          if (isset($social_google ) && $social_google!= '') { 
        $return.="<li><a href='". get_post_meta($post->ID, "_ins_google", true)."' target='_blank'><i class='fa fa-google-plus inv-team-member-social-icon' aria-hidden='true'><!-- icon --></i></a></li>";
       }

$return.="</ul>";
$return.="</div>";
$return.="</div>";
$return.="<div class='clearfix'></div>";
$return.="</div>";

$return.="<div class='clearfix'></div>";


$return.="</div>";

$return.="</div>";

endwhile;
return $return;
}else{
	     $return= "<p class='insignia-error-text text-center'>No Team Member found.</p>";
      return $return;
}
}
}


