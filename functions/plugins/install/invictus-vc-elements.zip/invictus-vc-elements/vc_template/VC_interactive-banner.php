<?php
/**
 *
 * Interactive banner VC element by INSIGNIA
 *
 */



/*Interactive banner Element*/



add_action( 'vc_before_init', 'VC_interactive_banner' );

function VC_interactive_banner() {
  vc_map (

 array(
      "name" => __( "Interactive Banner", "ensign" ),
      "base" => "insignia_interactive_banner",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
        "class" => "font-awesome",
	"icon" => "fa fa-id-card-o ",
       
      "params" => array(
      
        array(
		"type" => "dropdown",
		"class" => "hidden-label",
		"heading" => esc_html__( "Style", "ensign" ),
		"param_name" => "style",
		"group" => "General",

		"value" => array(
			esc_html__( "Select", "ensign" ) => "default",
                        esc_html__( "Style 1", "ensign" ) => "style1",
			esc_html__( "Style 2", "ensign" ) => "style2",
			esc_html__( "Style 3", "ensign" ) => "style3",
                       	esc_html__( "Style 4", "ensign" ) => "style4",
                       	esc_html__( "Style 5", "ensign" ) => "style5",

		),
		"description" => esc_html__( "Choose a style for interactive banner.", "ensign" ) 
	),
	
	array(
		'type' => 'attach_image',
		'heading' => esc_html__( 'Person Image', "ensign" ),
		'param_name' => 'img',
		'group' => 'General',
                'value' => '',
		'description' => esc_html__( 'Select a person image.', "ensign" ),
	),

      array(
		"type" => "checkbox",
		"heading" => esc_html__( "Add Icon?", "ensign" ),
		"param_name" => "add_icon",
            "group" => "General",

		"class" => "hidden-label",
		"value" => array(
			esc_html__( "Yes", "ensign" ) => "true",
		),
		"description" => esc_html__( "Display icon above the special heading.", "ensign" ) 
	),


      array(
	'type' => 'dropdown',
	'heading' => __( 'Icon library', 'ensign' ),
	'value' => array(      __( 'Font Awesome', 'ensign' ) => 'fontawesome',
				__( 'Open Iconic', 'ensign' ) => 'openiconic',
				__( 'Typicons', 'ensign' ) => 'typicons',
				__( 'Entypo', 'ensign' ) => 'entypo',
				__( 'Linecons', 'ensign' ) => 'linecons',
				__( 'Mono Social', 'ensign' ) => 'monosocial',
				__( 'Material', 'ensign' ) => 'material',
				__( 'Themify', 'ensign' ) => 'themify',

			),
	'admin_label' => true,
	'param_name' => 'icon_type',
            "group" => "General",
          'dependency' => array(
				'element' =>'style',
				'value' => array('style1' ,'style2','style4')
			), 
	'description' => __( 'Select icon library.', 'ensign' ),

         'dependency' => array(
						'element' => 'add_icon',
						'value' => array('true')
						
                ),
	),
		
		
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_fontawesome',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
			),
			'dependency' => array(
				'element' =>'icon_type',
				'value' => 'fontawesome',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
    ),
         
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_openiconic',
	'value' => 'vc-oi vc-oi-dial',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'openiconic',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'openiconic',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
		
		
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_typicons',
	'value' => 'typcn typcn-adjust-brightness',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'typicons',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'typicons',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_entypo',
	'value' => 'entypo-icon entypo-icon-note',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'entypo',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'entypo',
			),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_linecons',
	'value' => 'vc_li vc_li-heart',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'linecons',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'linecons',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_monosocial',
	'value' => 'vc-mono vc-mono-fivehundredpx',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'monosocial',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'monosocial',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_material',
	'value' => 'vc-material vc-material-cake',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'material',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'material',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
			'type' => 'iconpicker',
			'heading' => __( 'Icon', 'ensign' ),
			'param_name' => 'icon_themify',
                        	'value' => 'ti-wand',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				'type' => 'themify' ,
				// default true, display an "EMPTY" icon?
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
			),
			'dependency' => array(
				'element' =>'icon_type',
				'value' => 'themify',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),

		),
		
      array(
		"type" => "textfield",
		"class" => "hidden-label",
		"heading" => esc_html__( "Title", "ensign" ),
		"param_name" => "title",
		"group" => "General",

		"value" => '',
		"description" => esc_html__( "Intreractive banner title", "ensign" ) 
	),

     array(
		"type" => "textfield",
		"class" => "hidden-label",
		"heading" => esc_html__( "Subtitle", "ensign" ),
		"param_name" => "subtitle",
		"group" => "General",

		"value" => '',
		"description" => esc_html__( "Intreractive banner subtitle", "ensign" ),
		 'dependency' => array(
				'element' =>'style',
				'value' => array('style1' ,'style2')
			),   
	),

      array(
		"type" => "textarea",
		"class" => "hidden-label",
		"heading" => esc_html__( "Content", "ensign" ),
		"param_name" => "description",
	        "group" => "General",
	
		"value" => '',
		"description" => esc_html__( "Intreractive banner description", "ensign" ) 
	),

        array(
                  "type"        => "checkbox",
                  "param_name" => "btn_check",
                  "class" => "",
                   "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
                    "group" => "General",
                     'save_always' => true,
                    "value"         => array('Enable Button'   => '1' ),
                   
                    
						
                ),
      array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Button Text", "ensign" ),
            "param_name" => "btn_text",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Button title of your icon box.", "ensign" ),
             'dependency' => array(
						'element' => 'btn_check',
						'value' => array('1')
						
                ),
            
         ),
  array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Button Link", "ensign" ),
            "param_name" => "btn_link",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Optional icon link.", "ensign" ),
             'dependency' => array(
						'element' => 'btn_check',
						'value' => array('1')
						
                ),
            
         ),

  array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" ),
            
         ),
         
          array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Overlay Background Color", "ensign" ),
            "param_name" => "overlay_bg_color",
            "group" => "Advanced",
            "value" => __( "#252525", "ensign" ),
              "description" => __( " Choose a custom overlay background color.", "ensign" ),
             
               						
                ),
                
             array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
             "heading" => __( "Overlay Background Opacity", "ensign" ),
            "param_name" => "opacity",
            "group" => "Advanced",
              "description" => __( "Select overlay background opacity", "ensign" ),
             "value"       => array(
       
       'Select' => '',
        '0.2'   => '0.2',
        '0.3'   => '0.3',
        '0.4'   => '0.4',        
        '0.5'   => '0.5',
        '0.6'   => '0.6',
        '0.7'   => '0.7',
        '0.8'   => '0.8',
        '1'   => '1'

         ),
      "std"         => '0.2',
            
         ),  
         
        array(
            "type" => "dropdown",
            "class" => "",
              "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Icon Size", "ensign" ),
            "param_name" => "icon_size",
	   'group' => esc_html__( "Advanced", "ensign" ),
              "description" => __( "Select size of the icon.", "ensign" ),
             "value"       => array(
         'Select' => 'select',
         'Very Small' => 'icon-very-small',
        'Small'   => 'icon-small',
         'Medium'   => 'icon-medium',
         'Extra Medium'   =>'icon-extra-medium',
 	'Large'   => 'icon-large',
 	'Extra Large'   => 'icon-extra-large',
 	
        

         ),
      "std"         => 'icon-large',
         'dependency' => array(
				'element' =>'style',
				'value' => array('style1' ,'style2','style4')
			), 

           
         ),
         
            array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Icon Color", "ensign" ),
            "param_name" => "icon_color",
            "group" => "Advanced",
            "value" => __( "#ffffff", "ensign" ),
              "description" => __( " Choose a custom icon color.", "ensign" ),
             'dependency' => array(
				'element' =>'style',
				'value' => array('style1' ,'style2','style4')
			), 

               						
          ),
                  
         array(
			"type" => "textfield",
			"heading" => esc_html__( "Title Font-size", "ensign" ),
			"edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",

			"param_name" => "title_font_size",
			"description" => esc_html__( "Enter custom title font-size (example:20)", "ensign" ),
                        "value" => __( "19px", "ensign" ),
			'group' => esc_html__( "Advanced", "ensign" ) 

		),
		
        array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Title Color", "ensign" ),
            "param_name" => "title_color",
            "group" => "Advanced",
            "value" => __( "#ffffff", "ensign" ),
              "description" => __( " Choose a custom title color.", "ensign" ),
             
               						
          ),
          
           array(
			"type" => "textfield",
			"heading" => esc_html__( "Subtitle Font-size", "ensign" ),
			 "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",

			"param_name" => "subtitle_font_size",
			"description" => esc_html__( "Enter custom subtitle font-size (example:20)", "ensign" ),
                        "value" => __( "12px", "ensign" ),
			'group' => esc_html__( "Advanced", "ensign" ),
			'dependency' => array(
				'element' =>'style',
				'value' => array('style1' ,'style2','style4')
			), 
 

		),
		
        array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "subtitle Color", "ensign" ),
            "param_name" => "subtitle_color",
            "group" => "Advanced",
            "value" => __( "#ffffff", "ensign" ),
              "description" => __( " Choose a custom subtitle color.", "ensign" ),
             'dependency' => array(
				'element' =>'style',
				'value' => array('style1' ,'style2','style4')
			), 

               						
          ),
          
           array(
			"type" => "textfield",
			"heading" => esc_html__( "Description Font-size", "ensign" ),
			"edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",

			"param_name" => "description_font_size",
			"description" => esc_html__( "Enter custom description font-size (example:14)", "ensign" ),
                        "value" => __( "14px", "ensign" ),
			'group' => esc_html__( "Advanced", "ensign" ) 

		),
		
        array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Description Color", "ensign" ),
            "param_name" => "description_color",
            "group" => "Advanced",
            "value" => __( "#ffffff", "ensign" ),
              "description" => __( " Choose a custom description color.", "ensign" ),
             
               						
          ),
          
          array(
			"type" => "textfield",
			"heading" => esc_html__( "Button Font-size", "ensign" ),
			"edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",

			"param_name" => "button_font_size",
			"description" => esc_html__( "Enter custom button font-size (example:14)", "ensign" ),
                        "value" => __( "12px", "ensign" ),
			'group' => esc_html__( "Advanced", "ensign" ) 

		),
		
        array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Button Color", "ensign" ),
            "param_name" => "button_color",
            "group" => "Advanced",
            "value" => __( "#ffffff", "ensign" ),
              "description" => __( "Choose a custom button color.", "ensign" ),
             
               						
          ),								
    

array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        ),



       ) ));
}

add_shortcode( 'insignia_interactive_banner', 'insignia_interactive_banner_shortcode' );
function insignia_interactive_banner_shortcode( $atts,$content) {
$defaultFont      = 'fontawesome';
	$defaultIconClass = 'fa fa-user-o';
 extract( shortcode_atts( array(

    'icon_type'=>  $defaultFont,

        'icon_fontawesome'=>  $defaultIconClass,
        'icon_openiconic'=> '', 
        'icon_typicons'=> '', 
        'icon_entypo'=> '', 
        'icon_linecons'=> '', 
        'icon_monosocial'=> '', 
        'icon_material'=> '',   
        'icon_themify'=> '',
        'title'=> '',
        'subtitle' => '',
        'description' =>'',
        'btn_check' => '',        
        'btn_text' => '',        
        'btn_link' => '',
        'css' => '',
        'extra_class' => '',
        'style' => '',
        'img'=> '',
        'overlay_bg_color' => '#252525',
        'opacity' => '0.2',
        'icon_size' => 'icon-large',
        'icon_color' => '#ffffff',
        'title_font_size' => '19',
        'title_color' => '#ffffff',
        'subtitle_font_size' => '12',
        'subtitle_color' => '#ffffff',
        'description_font_size' => '14',
        'description_color' => '#ffffff',
        'button_font_size' => '12',
        'button_color' => '#ffffff',
	    "add_icon" => 'false'

        
        
        
         ), $atts ) );
         
       	if ( $add_icon != "false" ) {

         
     $icon = str_replace( 'fa-', '', '' );
	vc_icon_element_fonts_enqueue( $icon_type );
	
	$iconClass = isset( ${"icon_" . $icon_type} ) ? ${"icon_" . $icon_type} : $defaultIconClass;

}

$css=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );    
         
    $uniqid = uniqid('ins-banner');

$css_rules = '';


$line_height_title= $title_font_size + 10;
$line_height_subtitle= $subtitle_font_size+ 10;
$line_height_content= $description_font_size+ 10;
$line_height_button= $button_font_size+ 10;



if($overlay_bg_color != '')
$css_rules .= '#' . $uniqid . ' .ins-feature-box-overlay, #' . $uniqid . ' .ins-feature-box-5:before  {background-color: '.$overlay_bg_color.';}';

if($opacity != '')
$css_rules .= '#' . $uniqid . ' .ins-feature-box-background, #' . $uniqid . ' .ins-feature-box-5:before {opacity: '.$opacity.';}';

if($icon_color != '')
$css_rules .= '#' . $uniqid . ' .ins-feature-box-item-icon {color: '.$icon_color.';}';

if($title_font_size != '')
$css_rules .= '#' . $uniqid . ' .ins-feature-box-item-title {font-size: '.$title_font_size.'px; line-height:'.$line_height_title.'px;}';

if($title_color != '')
$css_rules .= '#' . $uniqid . ' .ins-feature-box-item-title {color: '.$title_color.';}';

if($subtitle_font_size != '')
$css_rules .= '#' . $uniqid . ' .ins-feature-box-item-subtitle {font-size: '.$subtitle_font_size.'px; line-height:'.$line_height_subtitle.'px;}';

if($subtitle_color != '')
$css_rules .= '#' . $uniqid . ' .ins-feature-box-item-subtitle {color: '.$subtitle_color.';}';

if($description_font_size != '')
$css_rules .= '#' . $uniqid . ' .ins-feature-box-item-content {font-size: '.$description_font_size.'px; line-height:'.$line_height_content.'px;}';

if($description_color != '')
$css_rules .= '#' . $uniqid . ' .ins-feature-box-item-content {color: '.$description_color.';}';

if($button_font_size != '')
$css_rules .= '#' . $uniqid . ' .ins-feature-box-link {font-size: '.$button_font_size.'px; line-height:'.$line_height_button.'px;}';

if($button_color != '')
$css_rules .= '#' . $uniqid . ' .ins-feature-box-link {color: '.$button_color.';}';

if($style== "style2"){
   
   $return="<div id='".$uniqid."' class='ins-feature-box-wrapper clearfix position-relative ".$extra_class." ".$css."'>";

     $return.="<div class='ins-feature-box-inner ins-feature-box-2 position-relative'>";
     $return.="<div class='ins-feature-box-overlay overflow-hidden position-relative padding-40px-all'>";
       if(!empty($img)) {
       $return.="<div class='ins-feature-box-background position-absolute top-0 bottom-0 left-0 right-0 cover-background' style='background-image: url(".wp_get_attachment_url($img,'large').");'></div>";
		}
		$return.="<div class='ins-feature-box-content ins-feature-box-2-content position-relative'>";
		         if(!empty($iconClass)) {
                            $return.="<i class='ins-feature-box-item-icon ".$iconClass." ".$icon_size." margin-20px-bottom margin-5px-top display-inline-block'></i>";
			}
			if(!empty($title)) {
                           $return.="<div class='ins-feature-box-item-title ins-feature-box-2-item-title title-font font-weight-600 margin-5px-top'>".$title."</div>";
                           }
                        if(!empty($subtitle)) {
                          $return.="<div class='ins-feature-box-item-subtitle ins-feature-box-item-2-subtitle'>".$subtitle."</div>";
                          }
                        if(!empty($description)) {
                          $return.="<div class='ins-feature-box-item-content ins-feature-box-2-item-content margin-10px-top margin-5px-bottom'>".$description."</div>";
                          }
                          if(!empty($btn_text)) {
                            $return.="<a class='ins-feature-box-link text-uppercase' href='".$btn_link."' target='_self'>".$btn_text."</a>";
			}
               $return.="</div>";   
          $return.="</div>";   
      $return.="</div>";   
   $return.="</div>";  
   
   $return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';
   
   
       return $return;
 
}elseif($style== "style3"){

 
   $return="<div id='".$uniqid."' class='ins-feature-box-wrapper clearfix position-relative ".$extra_class." ".$css."'>";

     $return.="<div class='ins-feature-box-inner ins-feature-box-3 overflow-hidden position-relative'>";
       if(!empty($img)) {
     
       $return.="<img src='".wp_get_attachment_url($img,'large')."' class='icon-image'>";
		}
		$return.="<div class='ins-feature-box-content ins-feature-box-3-content'>";
		$return.="<div class='opacity-full-dark bg-extra-dark-gray'></div>";
		$return.="<div class='display-table height-100 width-100 position-relative'>";
		$return.="<div class='vertical-align-middle display-table-cell padding-25px-lr padding-20px-tb'>";

			if(!empty($title)) {
                           $return.="<div class='ins-feature-box-item-title ins-feature-box-3-item-title title-font font-weight-600 margin-15px-bottom'>".$title."</div>";
                           }
                       
                        if(!empty($description)) {
                          $return.="<div class='ins-feature-box-item-content width-85 margin-5px-bottom'>".$description."</div>";
                          }
                          if(!empty($btn_text)) {
                            $return.="<a class='ins-feature-box-link text-uppercase' href='".$btn_link."' target='_self'>".$btn_text."</a>";
			}
               $return.="</div>"; 
            $return.="</div>";   
          $return.="</div>"; 
      $return.="</div>";   
   $return.="</div>";  
   
   $return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';
   
   
       return $return;

}elseif($style== "style4"){

 
  $return="<div id='".$uniqid."' class='ins-feature-box-wrapper clearfix position-relative ".$extra_class." ".$css."'>";

     $return.="<div class='ins-feature-box-inner ins-feature-box-4 position-relative width-100 height-100'>";
     $return.="<div class='ins-feature-box-overlay overflow-hidden position-relative padding-20px-all'>";
       if(!empty($img)) {
       $return.="<div class='ins-feature-box-background position-absolute top-0 bottom-0 left-0 right-0 cover-background' style='background-image: url(".wp_get_attachment_url($img,'large').");'></div>";
		}
		         if(!empty($iconClass)) {
		              $return.="<span class='ins-feature-box-item-icon ins-feature-box-item-icon-4 padding-40px-all display-block position-absolute top-0'><i class='ins-feature-box-item-icon ".$iconClass." ".$icon_size." margin-20px-bottom margin-5px-top display-inline-block'></i></span>";
			}
			$return.="<div class='ins-feature-box-content ins-feature-box-4-content position-absolute width-100 max-height-100 z-index-1 overflow-hidden padding-40px-lr padding-65px-bottom bottom-0 left-0'>";

			if(!empty($title)) {
                           $return.="<div class='ins-feature-box-item-title ins-feature-box-4-item-title title-font font-weight-600 margin-10px-bottom width-95'>".$title."</div>";
                           }
                        
                        if(!empty($description)) {
                          $return.="<div class='ins-feature-box-item-content ins-feature-box-4-item-content margin-5px-bottom overflow-hidden'>".$description."</div>";
                          }
                          if(!empty($btn_text)) {
                            $return.="<a class='ins-feature-box-link text-uppercase ins-feature-box-link-icon position-absolute bottom-30 left-40 icon-very-small text-white' href='".$btn_link."' target='_self'>".$btn_text."</a>";
			}
		$return.="</div>";   

          $return.="</div>";   
      $return.="</div>";   
   $return.="</div>";  
   
   $return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';
   
   
       return $return;

}elseif($style== "style5"){

  $return="<div id='".$uniqid."' class='ins-feature-box-wrapper clearfix position-relative ".$extra_class." ".$css."'>";


$return.="<div class='ins-feature-box-inner ins-feature-box-5'>";
       if(!empty($img)) {

$return.="<div class='ins-feature-box-inner-img'>";
       $return.="<img src='".wp_get_attachment_url($img,'large')."'>";
   $return.="</div>";  
   }
 $return.="<div class='ins-feature-banner-desc text-center position-absolute top-0 bottom-0 left-0 right-0 z-index-5 display-table'>";
 
 if(!empty($title)) {
$return.="<div class='ins-feature-box-item-title ins-feature-box-5-item-title title-font font-weight-600 margin-5px-top'>".$title."</div>";
 }
 
  if(!empty($description)) {
$return.="<div class='ins-feature-box-item-content ins-feature-box-5-item-content margin-10px-top margin-15px-bottom'>".$description."</div>";
}

if(!empty($btn_text)) {
                            $return.="<a class='ins-feature-box-link text-uppercase ins-feature-box-link-icon icon-very-small' href='".$btn_link."' target='_self'>".$btn_text."</a>";
			}

          $return.="</div>";   
          $return.="</div>";   
          $return.="</div>";   

$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';
   
   
       return $return;


}else{

$return="<div id='".$uniqid."' class='ins-feature-box-wrapper clearfix position-relative ".$extra_class." ".$css."'>";

     $return.="<div class='ins-feature-box-inner ins-feature-box-1 position-relative'>";
     $return.="<div class='ins-feature-box-overlay overflow-hidden position-relative padding-40px-all'>";
       if(!empty($img)) {
       $return.="<div class='ins-feature-box-background position-absolute top-0 bottom-0 left-0 right-0 cover-background' style='background-image: url(".wp_get_attachment_url($img,'large').");'></div>";
		}
		$return.="<div class='ins-feature-box-content ins-feature-box-1-content position-relative'>";
		         if(!empty($iconClass)) {
                            $return.="<i class='ins-feature-box-item-icon ".$iconClass." ".$icon_size." margin-20px-bottom margin-5px-top display-inline-block'></i>";
			}
			if(!empty($title)) {
                           $return.="<div class='ins-feature-box-item-title ins-feature-box-1-item-title title-font font-weight-600 margin-5px-top'>".$title."</div>";
                           }
                        if(!empty($subtitle)) {
                          $return.="<div class='ins-feature-box-item-subtitle ins-feature-box-item-1-subtitle'>".$subtitle."</div>";
                          }
                        if(!empty($description)) {
                          $return.="<div class='ins-feature-box-item-content ins-feature-box-1-item-content margin-10px-top margin-5px-bottom'>".$description."</div>";
                          }
                          if(!empty($btn_text)) {
                            $return.="<a class='ins-feature-box-link text-uppercase text-uppercase' href='".$btn_link."' target='_self'>".$btn_text."</a>";
			}
               $return.="</div>";   
          $return.="</div>";   
      $return.="</div>";   
   $return.="</div>";  
   
   $return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';
   
   
       return $return;
 

}
}