<?php
/**
 *
 * Icon Box VC element by INSIGNIA
 *
 */



/*Icon Box Element*/



add_action( 'vc_before_init', 'VC_icon_box' );

function VC_icon_box() {

  vc_map (

 array(
      "name" => __( "Icon Box", "ensign" ),
      "base" => "insignia_icon_box",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
        "class" => "font-awesome",
	"icon" => "fa fa-check-circle-o",
       
      "params" => array(
      
      array(
            "type" => "dropdown",
            "class" => "",
              "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Select Layouts", "ensign" ),
            "param_name" => "layout_style",
            "group" => "General",
              "description" => __( "Select Icon Box layout you would like to use", "ensign" ),
             "value"       => array(
       
        'Select Layout'   => 'first',
         'Top Icon Basic'   => 'ins-top-icon-basic',
          'Top Icon Outline'   => 'ins-icon-box-icon-circle-outline',
        'Top Icon Background'   => 'ins-icon-box-icon-circle-background',
        'Aligned Left Basic'   => 'ins-icon-box-align-left-basic',
        'Aligned Left Outline'   => 'ins-icon-box-align-left-circle-outline',
        'Aligned Left Bcakground'   => 'ins-icon-box-align-left-circle-background',
        'Aligned Right Basic'   => 'ins-icon-box-align-right-basic',
        'Aligned Right Outline'   => 'ins-icon-box-align-right-circle-outline',
        'Aligned Right Background'   => 'ins-icon-box-align-right-circle-background',
        'Icon Near The Title' => 'ins-icon-box-icon-near-title'

        ),
      "std"         => '',
         
         ),
          array(
            "type" => "dropdown",
            "class" => "",
              "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Icon Alignment", "ensign" ),
            "param_name" => "icon_align",
            "group" => "General",
              "description" => __( "Specify alignment of the big icon.", "ensign" ),
             "value"       => array(
         'Select' => 'select',
        'Left'   => 'text-left',
         'Right'   => 'text-right',
          'Center'   => 'text-center'
        

         ),
      "std"         => '',
            'dependency' => array(
				'element' =>'layout_style',
				'value' => array('ins-top-icon-basic' ,'ins-icon-box-icon-circle-outline', 'ins-icon-box-icon-circle-background')
			),   
         ),
   
       
array(
	'type' => 'dropdown',
	'heading' => __( 'Icon library', 'ensign' ),
	'value' => array(      __( 'Font Awesome', 'ensign' ) => 'fontawesome',
				__( 'Open Iconic', 'ensign' ) => 'openiconic',
				__( 'Typicons', 'ensign' ) => 'typicons',
				__( 'Entypo', 'ensign' ) => 'entypo',
				__( 'Linecons', 'ensign' ) => 'linecons',
				__( 'Mono Social', 'ensign' ) => 'monosocial',
				__( 'Material', 'ensign' ) => 'material',
				__( 'Themify', 'ensign' ) => 'themify',

			),
	'admin_label' => true,
	'param_name' => 'icon_type',
            "group" => "General",

	'description' => __( 'Select icon library.', 'ensign' ),
	),
		
		
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_fontawesome',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
			),
			'dependency' => array(
				'element' =>'icon_type',
				'value' => 'fontawesome',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
    ),
         
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_openiconic',
	'value' => 'vc-oi vc-oi-dial',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'openiconic',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'openiconic',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
		
		
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_typicons',
	'value' => 'typcn typcn-adjust-brightness',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'typicons',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'typicons',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_entypo',
	'value' => 'entypo-icon entypo-icon-note',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'entypo',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'entypo',
			),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_linecons',
	'value' => 'vc_li vc_li-heart',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'linecons',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'linecons',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_monosocial',
	'value' => 'vc-mono vc-mono-fivehundredpx',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'monosocial',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'monosocial',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_material',
	'value' => 'vc-material vc-material-cake',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'material',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'material',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
			'type' => 'iconpicker',
			'heading' => __( 'Icon', 'ensign' ),
			'param_name' => 'icon_themify',
			'value' => 'ti-wand',
			"group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				'type' => 'themify' ,
				// default true, display an "EMPTY" icon?
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
			),
			'dependency' => array(
				'element' =>'icon_type',
				'value' => 'themify',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),

		),
		
		
		 array(
            "type" => "dropdown",
            "class" => "",
              "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Icon Size", "ensign" ),
            "param_name" => "icon_size",
            "group" => "General",
              "description" => __( "Specify size of the icon.", "ensign" ),
             "value"       => array(
         'Select' => 'select',
         'Very Small' => 'icon-very-small',
        'Small'   => 'icon-small',
         'Medium'   => 'icon-medium',
         'Extra Medium'   =>'icon-extra-medium',
 	'Large'   => 'icon-large',
 	'Extra Large'   => 'icon-extra-large',
 	
        

         ),
      "std"         => 'icon-medium',
        'dependency' => array(
				'element' =>'layout_style',
				'value' => array('ins-top-icon-basic' ,'ins-icon-box-icon-circle-outline', 'ins-icon-box-icon-circle-background')
			),   
           
         ),
			
               
          array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Title", "ensign" ),
            "param_name" => "icon_title",
            "group" => "General",
             "description" => __( "The title of your icon box.", "ensign" ),
            "value" => 'Icon Box Title' 

         ),
         
         array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Subtitle", "ensign" ),
            "param_name" => "sub_title",
            "group" => "General",
             "description" => __( "The subtitle of your icon box.", "ensign" ),
            "value" => 'Icon Box Subtitle',
            'dependency' => array(
				'element' =>'layout_style',
				'value' => array('ins-icon-box-icon-near-title')
			), 

         ),
      
                
                

       array(
            "type" => "textarea",
            "class" => "",
             
            "heading" => __( "Text Content", "ensign" ),
            "param_name" => "icon_text",
            "group" => "General",
             "description" => __( "Description text of the icon box.", "ensign" ),
             "value" => 'Icon Box text content, feel free to change it!' 

         ),

        array(
                  "type"        => "checkbox",
                  "param_name" => "btn_check",
                  "class" => "",
                   "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
                    "group" => "General",
                     'save_always' => true,
                    "value"         => array('Enable Button'   => '1' ),
                   
                    
						
                ),
      array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Button Text", "ensign" ),
            "param_name" => "btn_text",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Button title of your icon box.", "ensign" ),
             'dependency' => array(
						'element' => 'btn_check',
						'value' => array('1')
						
                ),
            
         ),
  array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Button Link", "ensign" ),
            "param_name" => "btn_link",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Optional icon link.", "ensign" ),
             'dependency' => array(
						'element' => 'btn_check',
						'value' => array('1')
						
                ),
            
         ),

         array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Icon Border Radius", "ensign" ),
            "param_name" => "border_radius",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Enter Icon Border Radius. (Example:5px)", "ensign" ),
            'dependency' => array(
				'element' =>'layout_style',
				'value' => array('ins-icon-box-icon-circle-outline', 'ins-icon-box-icon-circle-background', 'ins-icon-box-align-left-circle-outline', 'ins-icon-box-align-left-circle-background', 'ins-icon-box-align-right-circle-outline', 'ins-icon-box-align-right-circle-background'),      
         ),
            
         ),

 array(
                  "type"        => "checkbox",
                  "param_name" => "box_shadow",
                  "class" => "",
                   "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
                    "group" => "General",
                    "heading" => esc_html__( "Enable Box Shadow?", "ensign" ),

                   "value" => array(
			esc_html__( "Yes", "ensign" ) => "ins-icon-box-shadow",
			),      
			'dependency' => array(
				'element' =>'layout_style',
				'value' => array('ins-top-icon-basic' ,'ins-icon-box-icon-circle-outline', 'ins-icon-box-icon-circle-background')
			),   
                    
						
                ),
                
   array(
                  "type"        => "checkbox",
                  "param_name" => "hover_box_shadow",
                  "class" => "",
                   "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
                    "group" => "General",
                    "heading" => esc_html__( "On Hover Box Shadow?", "ensign" ),

                   "value" => array(
			esc_html__( "Yes", "ensign" ) => "ins-icon-hover-box-shadow",
			),      
			'dependency' => array(
				'element' =>'layout_style',
				'value' => array('ins-top-icon-basic' ,'ins-icon-box-icon-circle-outline', 'ins-icon-box-icon-circle-background')
			),   
                    
						
                ),


       array(
			"type" => "dropdown",
			"class" => "hidden-label",
			"value" => array(
				esc_html__( "Select Separator", "ensign" ) => 'select',
				esc_html__( "Enable", "ensign" ) => 'enable',
				esc_html__( "Disable", "ensign" ) => 'disable' 
			),
			"heading" => esc_html__( "Separator?", "ensign" ),
                         "group" => "General",

			"description" => esc_html__( 'Set below the title Separator', "ensign" ),
			"param_name" => "separator" ,
                     
                           'dependency' => array(
				'element' =>'layout_style',
				'value' => array('ins-top-icon-basic' ,'ins-icon-box-icon-circle-outline', 'ins-icon-box-icon-circle-background')
			),   
           
        
		),             


                
      array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" ),
            
         ),

          array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Title Font Size", "ensign" ),
            "param_name" => "title_font",
            "group" => "Advanced",
              "description" => __( "Select title font size.", "ensign" ),
             "value"       => array(
       
       'Select' => '',
        'Theme Default'   => 'text-large',
        'Extra Small'   => 'text-extra-small',
        'Small'   => 'text-small',
        'Medium'   => 'text-medium',        
        'Large'   => 'text-large',
        'Extra Large'   => 'text-extra-large'

         
         ),
      "std"         => '',
       'dependency' => array(
				'element' =>'layout_style',
				'value' => array('ins-top-icon-basic' ,'ins-icon-box-icon-circle-outline', 'ins-icon-box-icon-circle-background', 'ins-icon-box-align-left-circle-outline', 'ins-icon-box-align-left-circle-background', 'ins-icon-box-align-left-basic', 'ins-icon-box-align-right-basic', 'ins-icon-box-align-right-circle-outline', 'ins-icon-box-align-right-circle-background'),      
         ),
         
         ),
         
           array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
             "heading" => __( "Text Font Size", "ensign" ),
            "param_name" => "text_font",
            "group" => "Advanced",
              "description" => __( "Select text font size.", "ensign" ),
             "value"       => array(
       
       'Select' => '',
        'Extra Small'   => 'text-extra-small',
        'Small'   => 'text-small',
        'Medium'   => 'text-medium',        
        'Large'   => 'text-large',
        'Extra Large'   => 'text-extra-large'

         
         ),
      "std"         => '',
           'dependency' => array(
				'element' =>'layout_style',
				'value' => array('ins-top-icon-basic' ,'ins-icon-box-icon-circle-outline', 'ins-icon-box-icon-circle-background', 'ins-icon-box-align-left-circle-outline', 'ins-icon-box-align-left-circle-background', 'ins-icon-box-align-left-basic', 'ins-icon-box-align-right-basic', 'ins-icon-box-align-right-circle-outline', 'ins-icon-box-align-right-circle-background'),      
         ),
         
  
         ),



  array(
			"type" => "dropdown",
			 "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",

			"heading" => esc_html__( "Title Font-weight", "ensign" ),
			"param_name" => "title_font_weight",
                        "group" => "Advanced",
                        "description" => esc_html__( "Select Title font-weight.", "ensign" ),
                        "value"       => array(
			esc_html__( 'Theme defaults', 'ensign' ) => 'default',
			esc_html__( '100', 'ensign' ) => 'font-weight-100',
			esc_html__( '200', 'ensign' ) => 'font-weight-200',
			esc_html__( '300', 'ensign' ) => 'font-weight-300',
			esc_html__( '400', 'ensign' ) => 'font-weight-400',
			esc_html__( '500', 'ensign' ) => 'font-weight-500',
			esc_html__( '600', 'ensign' ) => 'font-weight-600',
			esc_html__( '700', 'ensign' ) => 'font-weight-700',
			esc_html__( '900', 'ensign' ) => 'font-weight-900'
			),
                         
		),
         
      array(
			"type" => "dropdown",
			 "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",

			"heading" => esc_html__( "Text Font-weight", "ensign" ),
			"param_name" => "text_font_weight",
                        "group" => "Advanced",
                        "description" => esc_html__( "Select sun sub-heading font-weight.", "ensign" ),
                        "value" => array(
			esc_html__( 'Theme defaults', 'ensign' ) => 'default',
			esc_html__( '100', 'ensign' ) => 'font-weight-100',
			esc_html__( '200', 'ensign' ) => 'font-weight-200',
			esc_html__( '300', 'ensign' ) => 'font-weight-300',
			esc_html__( '400', 'ensign' ) => 'font-weight-400',
			esc_html__( '500', 'ensign' ) => 'font-weight-500',
			esc_html__( '600', 'ensign' ) => 'font-weight-600',
			esc_html__( '700', 'ensign' ) => 'font-weight-700',
			esc_html__( '900', 'ensign' ) => 'font-weight-900'
			),
                         
		),
         

      	 array(
            "type" => "dropdown",
            "class" => "",
              "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Title letter-spacing", "ensign" ),
            "param_name" => "title_letter_spacing",
              "group" => "Advanced",
              "description" => __( "Specify letter-spacing of the title", "ensign" ),
             "value"       => array(
         'Select' => 'select',
        'No-letter-spacing' => 'no-letter-spacing',
        '0.5' => 'letter-spacing-0.5',
         '1' => 'letter-spacing-1',
        '2'   => 'letter-spacing-2',
         '3'   => 'letter-spacing-3',
         '4'   =>'letter-spacing-4',
 	'5'   => 'letter-spacing-5',
 	'6'   => 'letter-spacing-6',
 	'7'   => 'letter-spacing-7',
 	'8'   => 'letter-spacing-8',
 	'9'   => 'letter-spacing-9',
 	'10'   => 'letter-spacing-10'

         ),
      "std"         => 'no-letter-spacing',
       
           
         ),
  	

        array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Icon Color", "ensign" ),
            "param_name" => "icon_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose a color for your icon box.", "ensign" ),
              
               						
                ),
       
      array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Title Custom Color", "ensign" ),
            "param_name" => "title_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose a custom title color.", "ensign" ),
              
               						
                ),
                
          array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Subtitle Custom Color", "ensign" ),
            "param_name" => "sub_title_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose a custom subtitle color.", "ensign" ),
               'dependency' => array(
				'element' =>'layout_style',
				'value' => array('ins-icon-box-icon-near-title')
			),  
               						
                ),        
   array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Text Custom Color", "ensign" ),
            "param_name" => "text_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose a custom text color.", "ensign" ),
              
               						
                ),
                
      array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Icon Background Color", "ensign" ),
            "param_name" => "icon_bg_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose a custom icon background color.", "ensign" ),
              'dependency' => array(
						'element' => 'layout_style',
						'value' => array('ins-icon-box-icon-circle-background','ins-icon-box-align-left-circle-background', 'ins-icon-box-align-right-circle-background')
						
                ),
               						
                ),
          
            array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Icon Outline Color", "ensign" ),
            "param_name" => "icon_outline_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose a custom icon outline color.", "ensign" ),
              'dependency' => array(
						'element' => 'layout_style',
						'value' => array('ins-icon-box-icon-circle-outline','ins-icon-box-align-left-circle-outline', 'ins-icon-box-align-right-circle-outline' )
						
                ),
               						
                ),  
                   
                array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Button Custom Color", "ensign" ),
            "param_name" => "btn_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose a custom button color.", "ensign" ),
                'dependency' => array(
						'element' => 'btn_check',
						'value' => array('1')
						
                ),

               						
                ), 

              array(
			"type" => "colorpicker",
			"class" => "hidden-label",
			"heading" => esc_html__( "Separator Color", "ensign" ),
			"param_name" => "separator_color",
			"value" => __( "#343434", "ensign" ),
			'description' => esc_html__( 'Select the separator border color.', 'ensign' ),
			'group' => esc_html__( "Advanced", "ensign" ),
                           'dependency' => array(
				'element' =>'layout_style',
				'value' => array('ins-top-icon-basic' ,'ins-icon-box-icon-circle-outline', 'ins-icon-box-icon-circle-background')
			),   
           
          
		),
              
     
     
        array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        ),

  
   ) ));
}

add_shortcode( 'insignia_icon_box', 'insignia_icon_box_shortcode' );
function insignia_icon_box_shortcode( $atts,$content) {
$defaultFont      = 'fontawesome';
	$defaultIconClass = 'fa fa-user-o';
 extract( shortcode_atts( array(
 
 	
      
     'layout_style' => '',
      'extra_class'=>'',
       'css'=> '',
        'icon_type'=>  $defaultFont,
        'icon_fontawesome'=>  $defaultIconClass,
        'icon_openiconic'=> '', 
        'icon_typicons'=> '',
         'icon_entypo'=> '', 
        'icon_linecons'=> '', 
        'icon_monosocial'=> '', 
        'icon_material'=> '',   
        'icon_themify'=> '',
        'icon_align'=> '',
        'icon_title'=> esc_html__( 'Icon Box Title', "ensign" ),
        'icon_text'=> esc_html__( 'Icon Box text content, feel free to change it!', "ensign" ),
        'btn_check' => '',        
        'btn_text' => '',        
        'btn_link' => '',
        'icon_size' => 'icon-medium',
        'icon_color' => '',
        'text_color' => '',
        'title_color' => '',
        'title_font' => '',
         'text_font' => '',
         'icon_bg_color' => '',
         'icon_outline_color' => '',
         'btn_color' => '',
        'sub_title' => esc_html__( 'Icon Box Subtitle', "ensign" ),
         'sub_title_color' => '',
         'border_radius' => '',
         'box_shadow'=> '',
         'hover_box_shadow' => '',
          'text_font_weight' =>'',
          'title_font_weight' =>'',
         "separator" => '',
 	"separator_color" => '#343434',
        'title_letter_spacing' => 'no-letter-spacing'  
   
        

   ), $atts ) );


global $layout_style1,$extra_class1,$css1,$icon_type1,$icon_fontawesome1,$icon_openiconic1,$icon_typicons1,$icon_entypo1,$icon_linecons1,$icon_monosocial1,$icon_material1,$icon_themify1,$icon_align1,$icon_text1,$icon_title1,$btn_check1,$btn_text1,$btn_link1,$icon_size1,$icon_color1,$icon_color1,$text_color1,$title_color1,$title_font1,$text_font1,$icon_bg_color1,$icon_outline_color1,$btn_color1,$border_radius1,$box_shadow1,$hover_box_shadow1,$text_font_weight1,$title_font_weight1,$separator1,$separator_color1,$title_letter_spacing1;

$layout_style1= ${'layout_style'};
$extra_class1=${'extra_class'};
$icon_type1=${'icon_type'};
$icon_fontawesome1=${'icon_fontawesome'};
$icon_openiconic1=${'icon_openiconic'};
$icon_typicons1=${'icon_typicons'};
$icon_entypo1=${'icon_entypo'};
$icon_linecons1=${'icon_linecons'};
$icon_monosocial1=${'icon_monosocial'};
$icon_material1=${'icon_material'};
$icon_themify1=${'icon_themify'};
$icon_align1=${'icon_align'};
$icon_title1=${'icon_title'};
$icon_text1=${'icon_text'};
$btn_check1=${'btn_check'};
$btn_text1=${'btn_text'};
$btn_link1=${'btn_link'};
$icon_size1=${'icon_size'};
$text_color1=${'text_color'};
$title_color1=${'title_color'};
$icon_color1=${'icon_color'};
$title_font1=${'title_font'};
$text_font1=${'text_font'};
$icon_bg_color1=${'icon_bg_color'};
$icon_outline_color1=${'icon_outline_color'};
$btn_color1=${'btn_color'};
$sub_title1=${'sub_title'};
$sub_title_color1=${'sub_title_color'};
$border_radius1=${'border_radius'};
$box_shadow1=${'box_shadow'};
$hover_box_shadow1=${'hover_box_shadow'};
$title_font_weight1=${'title_font_weight'};
$text_font_weight1=${'text_font_weight'};
$separator1=${'separator'};
$separator_color1=${'separator_color'};
$title_letter_spacing1=${'title_letter_spacing'};



$icon = str_replace( 'fa-', '', '' );
	vc_icon_element_fonts_enqueue( $icon_type1 );
	
	$iconClass = isset( ${"icon_" . $icon_type1} ) ? ${"icon_" . $icon_type1} : $defaultIconClass;

$css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );

if(empty($title_font1)){
   $title_font1= 'text-large';
}

	
$uniqid = uniqid('ins-icon-');
$icon_css = '';

if($icon_color1 != '')
$icon_css .= '#' . $uniqid . ' .ins-icon-box-icon i, #' . $uniqid . ' .ins-float-icon-inner i, #' . $uniqid . ' .ins-float-right-icon-inner i {color: '.$icon_color1.';}';


if($title_color1 != '')
$icon_css .= '#' . $uniqid . ' .ins-icon-box-title, #' . $uniqid . ' .ins-float-icon-box-title {color: '.$title_color1.';}';

if($text_color1 != '')
$icon_css .= '#' . $uniqid . ' .ins-icon-box-text, #' . $uniqid . ' .ins-float-icon-box-text {color: '.$text_color1.';}';


if($icon_bg_color1 != '')
$icon_css .= '#' . $uniqid . ' .ins-icon-box-icon-circle-background, #' . $uniqid . '.ins-icon-box-align-left-circle-background .ins-float-icon-inner, #' . $uniqid . '.ins-icon-box-align-right-circle-background .ins-float-right-icon-inner {background: '.$icon_bg_color1.';}';

if($icon_outline_color1 != '')
$icon_css .= '#' . $uniqid . ' .ins-icon-box-icon-circle-outline, #' . $uniqid . '.ins-icon-box-align-left-circle-outline .ins-float-icon-inner, #' . $uniqid . '.ins-icon-box-align-right-circle-outline .ins-float-right-icon-inner {border-color: '.$icon_outline_color1.';}';


if($btn_color1!= '')
$icon_css .= '#' . $uniqid . ' .ins-image-box-btn {color: '.$btn_color1.';}';

if($border_radius1 != '')
$icon_css .= '#' . $uniqid . ' .ins-icon-box-icon-circle-background, #' . $uniqid . ' .ins-icon-box-icon-circle-outline, #' . $uniqid . '.ins-icon-box-align-left-circle-outline .ins-float-icon-inner, #' . $uniqid . '.ins-icon-box-align-left-circle-background .ins-float-icon-inner, #' . $uniqid . '.ins-icon-box-align-right-circle-outline .ins-float-right-icon-inner, #' . $uniqid . '.ins-icon-box-align-right-circle-background .ins-float-right-icon-inner  {border-radius: '.$border_radius1.';}';




if($layout_style1== "ins-icon-box-align-left-basic" || $layout_style1== "ins-icon-box-align-left-circle-outline" || $layout_style1== "ins-icon-box-align-left-circle-background"){

$return="<div id='".$uniqid."' class='ins-float-icon-wrapper margin-20px-bottom ".$layout_style1." ".$extra_class1." ".$css1."'>";
$return.="<div class='ins-float-icon-inner position-relative'>";

$return.="<i class='link-icon text-medium-gray icon-medium ".$iconClass." ".$icon_size1."'></i>";
$return.="</div>";

$return.="<div class='ins-float-icon-box-content'>";
if(!empty($icon_title1)) {
$return.="<div class='ins-float-icon-box-title text-extra-dark-gray margin-5px-bottom title-font ".$title_font_weight1." ".$title_font1." ".$title_letter_spacing1."'>".$icon_title1."</div>";
}

if(!empty($icon_text1)) {
$return.="<div class='last-paragraph-no-margin'>";
$return.="<p class='ins-float-icon-box-text ".$text_font1." ".$text_font_weight1."'>".$icon_text1."</p>";
$return.="</div>";
}
if(!empty($btn_text1)) {
$return.="<a class='ins-image-box-btn text-extra-medium-gray' href='".$btn_link1."'>";
$return.=$btn_text1;
$return.="<i class='fa fa-long-arrow-right'></i>";
$return.="</a>";
}

$return.="</div>";
$return.="</div>";

$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($icon_css != '') {
					$return.= 'jQuery("head").append("<style>'.$icon_css.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';

    return $return;


}elseif($layout_style1== "ins-icon-box-align-right-basic" || $layout_style1== "ins-icon-box-align-right-circle-outline" || $layout_style1== "ins-icon-box-align-right-circle-background"){

$return="<div id='".$uniqid."' class='ins-float-icon-wrapper margin-20px-bottom ".$layout_style1." ".$extra_class1." ".$css1."'>";
$return.="<div class='ins-float-right-icon-inner position-relative'>";

$return.="<i class='link-icon text-medium-gray icon-medium ".$iconClass." ".$icon_size1."'></i>";
$return.="</div>";

$return.="<div class='ins-float-icon-box-content'>";
if(!empty($icon_title1)) {
$return.="<div class='ins-float-icon-box-title text-extra-dark-gray margin-5px-bottom title-font ".$title_font_weight1." ".$title_font1." ".$title_font_weight1." ".$title_letter_spacing1."'>".$icon_title1."</div>";
}

if(!empty($icon_text1)) {
$return.="<div class='last-paragraph-no-margin'>";
$return.="<p class='ins-float-icon-box-text ".$text_font1." ".$text_font_weight1."'>".$icon_text1."</p>";
$return.="</div>";
}
if(!empty($btn_text1)) {
$return.="<a class='ins-image-box-btn text-extra-medium-gray' href='".$btn_link1."'>";
$return.=$btn_text1;
$return.="<i class='fa fa-long-arrow-right'></i>";
$return.="</a>";

}

$return.="</div>";
$return.="</div>";

$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($icon_css != '') {
					$return.= 'jQuery("head").append("<style>'.$icon_css.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';

    return $return;


}elseif($layout_style1== "ins-icon-box-icon-near-title") {

$return="<div id='".$uniqid."' class='ins-icon-wrapper margin-20px-bottom ".$extra_class1." ".$css1." ".$icon_align1."'>";
$return.="<div class='ins-icon-box-icon margin-20px-bottom ".$layout_style1."'>";
$return.="<i class='icon-box-icon icon-medium ".$iconClass."'></i>";
$return.="<span class='ins-icon-box-sub-title text-small title-font'>".$sub_title1."</span>";

if(!empty($icon_title1)) {
$return.="<p class='ins-icon-box-title title-font ".$title_font1." ".$title_font_weight1." ".$title_letter_spacing1."'>".$icon_title1."</p>";
}

$return.="</div>";
$return.="<div class='ins-icon-box-content'>";

if(!empty($icon_text1)) {
$return.="<p class='ins-icon-box-text ".$text_font1." ".$text_font_weight1."'>".$icon_text1."</p>";
}
if(!empty($btn_text1)) {
$return.="<a class='ins-image-box-btn text-extra-medium-gray' href='".$btn_link1."'>";
$return.=$btn_text1;
$return.="<i class='fa fa-long-arrow-right'></i>";
$return.="</a>";

}
$return.="</div>";
$return.="</div>";



$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($icon_css != '') {
					$return.= 'jQuery("head").append("<style>'.$icon_css.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';


    return $return;

}else{

$return="<div id='".$uniqid."' class='ins-icon-wrapper margin-20px-bottom ".$extra_class1." ".$css1." ".$icon_align1." ".$box_shadow1." ".$hover_box_shadow1."'>";
$return.="<div class='ins-icon-box-icon margin-20px-bottom ".$layout_style1." ".$icon_size1."'>";
$return.="<i class='".$iconClass."'></i>";
$return.="</div>";
$return.="<div class='ins-icon-box-content'>";
if(!empty($icon_title1)) {
$return.="<div class='ins-icon-box-title title-font margin-10px-bottom sm-margin-5px-bottom ".$title_font1." ".$title_font_weight1." ".$title_letter_spacing1."'>".$icon_title1."</div>";
}
if ( $separator1 == 'enable' ) {
	$return .= '<div style="background-color: '. $separator_color1 .'" class="inv-icon-box-separator"><!--separator--></div>';
	}
if(!empty($icon_text1)) {
$return.="<p class='ins-icon-box-text ".$text_font1." ".$text_font_weight1."'>".$icon_text1."</p>";
}
if(!empty($btn_text1)) {
$return.="<a class='ins-image-box-btn text-extra-medium-gray' href='".$btn_link1."'>";
$return.=$btn_text1;
$return.="<i class='fa fa-long-arrow-right'></i>";
$return.="</a>";

}
$return.="</div>";
$return.="</div>";



$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($icon_css != '') {
					$return.= 'jQuery("head").append("<style>'.$icon_css.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';


    return $return;

}
}
