<?php
/**
 *
 * Simple Icon List VC element by INSIGNIA
 *
 */



/*Simple Icon List Element*/


add_action( 'vc_before_init', 'VC_simple_icon_list' );

function VC_simple_icon_list() {
  vc_map (

 array(
      "name" => __( "Simple Icon List", "ensign" ),
      "base" => "insignia_simple_icon_list",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
        "class" => "font-awesome",
	"icon" => "fa fa-list-ul",
       
      "params" => array(
      
      
        
   
       
array(
	'type' => 'dropdown',
	'heading' => __( 'Icon library', 'ensign' ),
	'value' => array(      __( 'Font Awesome', 'ensign' ) => 'fontawesome',
				__( 'Open Iconic', 'ensign' ) => 'openiconic',
				__( 'Typicons', 'ensign' ) => 'typicons',
				__( 'Entypo', 'ensign' ) => 'entypo',
				__( 'Linecons', 'ensign' ) => 'linecons',
				__( 'Mono Social', 'ensign' ) => 'monosocial',
				__( 'Material', 'ensign' ) => 'material',

			),
	'admin_label' => true,
	'param_name' => 'icon_type',
            "group" => "General",

	'description' => __( 'Select icon library.', 'ensign' ),
	),
		
		
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_fontawesome',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
			),
			'dependency' => array(
				'element' =>'icon_type',
				'value' => 'fontawesome',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
    ),
         
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_openiconic',
	'value' => 'vc-oi vc-oi-dial',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'openiconic',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'openiconic',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
		
		
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_typicons',
	'value' => 'typcn typcn-adjust-brightness',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'typicons',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'typicons',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_entypo',
	'value' => 'entypo-icon entypo-icon-note',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'entypo',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'entypo',
			),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_linecons',
	'value' => 'vc_li vc_li-heart',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'linecons',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'linecons',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_monosocial',
	'value' => 'vc-mono vc-mono-fivehundredpx',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'monosocial',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'monosocial',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_material',
	'value' => 'vc-material vc-material-cake',
            "group" => "General",

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'material',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'material',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
		
       
		
			
               
          array(
            "type" => "exploded_textarea",
            "class" => "",
             
            "heading" => __( "List Items", "ensign" ),
            "param_name" => "list_items",
            "group" => "General",
             "description" => __( "Enter list items here. Divide each item with linebreaks (Enter).", "ensign" ),
            "value" => 'List Item 1,List Item 2,List Item 3' 

         ),

     array(
            "type" => "dropdown",
            "class" => "",
              "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Icon Style", "ensign" ),
            "param_name" => "icon_style",
            "group" => "General",
              "description" => __( "Choose a style of icons in the list.", "ensign" ),
             "value"       => array(
       
        'Select Style'   => 'ins-icon-list-simple',
         'Simple'   => 'ins-icon-list-simple',
          'Circle'   => 'ins-icon-list-circle',
        'Outline'   => 'ins-icon-list-outline'
        

         ),
      "std"         => '',
         
         ),

         array(
            "type" => "dropdown",
            "class" => "",
              "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Icon Size", "ensign" ),
            "param_name" => "icon_size",
            "group" => "General",
              "description" => __( "Specify size of the icon.", "ensign" ),
             "value"       => array(
         'Select' => 'list-icon-small',
        'Small'   => 'list-icon-small',
         'Medium'   => 'list-icon-medium',
 	'Large'   => 'list-icon-large',
 	
        

         ),
      "std"         => '',
        
           
         ),

        array(
            "type" => "dropdown",
            "class" => "",
              "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Border", "ensign" ),
            "param_name" => "border_bottom",
            "group" => "General",
              "description" => __( "Enable/disable 1px solid border between list elements.", "ensign" ),
             "value"       => array(
           'Select' => 'select',
          'Off'   => 'list-icon-border-none',
         'On'   => 'list-icon-border',
 	
        ),

      "std"         => '',
       		
         ),
                
           array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" ),
            
         ),     
        
          array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Icon Color", "ensign" ),
            "param_name" => "icon_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose a color for your list icon.", "ensign" ),
              
               						
                ),
       
      
   array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Text Custom Color", "ensign" ),
            "param_name" => "text_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose a custom text color.", "ensign" ),
              
               						
                ),
                
      array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Icon Background Color", "ensign" ),
            "param_name" => "icon_bg_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose a custom icon background color.", "ensign" ),
              'dependency' => array(
						'element' => 'icon_style',
						'value' => array('ins-icon-list-circle')
						
                ),
               						
                ),
          
            array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Icon Outline Color", "ensign" ),
            "param_name" => "icon_outline_color",
            "group" => "Advanced",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose a custom icon outline color.", "ensign" ),
              'dependency' => array(
						'element' => 'icon_style',
						'value' => array('ins-icon-list-outline')
						
                ),				
                ),
               					
     
     
        array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        ),

  
   ) ));
}

add_shortcode( 'insignia_simple_icon_list', 'insignia_simple_icon_list_shortcode' );
function insignia_simple_icon_list_shortcode( $atts,$content) {
$defaultFont      = 'fontawesome';
	$defaultIconClass = 'fa fa-user-o';
 extract( shortcode_atts( array(
 
 	
      
      'extra_class'=>'',
       'css'=> '',
        'icon_type'=>  $defaultFont,
        'icon_fontawesome'=>  $defaultIconClass,
        'icon_openiconic'=> '', 
        'icon_typicons'=> '', 
        'icon_entypo'=> '', 
        'icon_linecons'=> '', 
        'icon_monosocial'=> '', 
        'icon_material'=> '',   
        'list_items'=> esc_html__( 'List Item 1,List Item 2,List Item 3', "ensign" ),
        'icon_style' => '',
        'icon_size' => 'list-icon-small',
        'border_bottom' => '',
        'icon_color' => '',
        'text_color' => '',
        'icon_bg_color' => '',
        'icon_outline_color' => ''
        
        
   
        

   ), $atts ) );


global $extra_class1,$css1,$icon_type1,$icon_fontawesome1,$icon_openiconic1,$icon_typicons1,$icon_entypo1,$icon_linecons1,$icon_monosocial1,$icon_material1,$list_items1,$icon_style1,$icon_size1,$border_bottom1,$icon_color1,$text_color1,$icon_bg_color1,$icon_outline_color1;


$extra_class1=${'extra_class'};
$icon_type1=${'icon_type'};
$icon_fontawesome1=${'icon_fontawesome'};
$icon_openiconic1=${'icon_openiconic'};
$icon_typicons1=${'icon_typicons'};
$icon_entypo1=${'icon_entypo'};
$icon_linecons1=${'icon_linecons'};
$icon_monosocial1=${'icon_monosocial'};
$icon_material1=${'icon_material'};
$list_items1=${'list_items'};
$icon_style1=${'icon_style'};
$icon_size1=${'icon_size'};
$border_bottom1=${'border_bottom'};
$icon_color1=${'icon_color'};
$text_color1=${'text_color'};
$icon_bg_color1=${'icon_bg_color'};
$icon_outline_color1=${'icon_outline_color'};



$icon = str_replace( 'fa-', '', '' );
	vc_icon_element_fonts_enqueue( $icon_type1 );
	
	$iconClass = isset( ${"icon_" . $icon_type1} ) ? ${"icon_" . $icon_type1} : $defaultIconClass;

$css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );

$items_arr = explode( ',',$list_items1);


if(empty($icon_size1)){
   $icon_size1= 'list-icon-small';
}


$uniqid = uniqid('ins-list-icon-');
$list_css = '';

if($icon_color1 != '')
$list_css .= '#' . $uniqid . ' .ins-list-style .ins-icon-list-icon{color: '.$icon_color1.';}';

if($text_color1 != '')
$list_css .= '#' . $uniqid . ' .ins-list-style{color: '.$text_color1.';}';

if($icon_bg_color1 != '')
$list_css .= '#' . $uniqid .'.ins-icon-list-circle i{background: '.$icon_bg_color1.';}';

if($icon_outline_color1 != '')
$list_css .= '#' . $uniqid .'.ins-icon-list-outline i{border-color: '.$icon_outline_color1.';}';



$return="<div id='".$uniqid."' class='ins-simple-icon-list margin-35px-bottom ".$icon_style1." ".$icon_size1." ".$border_bottom1." ".$extra_class1." ".$css1."'>";
$return.="<ul class='ins-simple-icon-list-inner list-style-none no-padding'>";
foreach ( $items_arr as $list_items1 ) {

		$return.="<li class='ins-list-style margin-10px-bottom position-relative'><i class='ins-icon-list-icon margin-10px-right display-inline-block position-absolute left-0 ". $iconClass."'></i> ". $list_items1 ."</li>";
	}
	

$return.="</ul>";
$return.="</div>";

   $return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($list_css != '') {
					$return.= 'jQuery("head").append("<style>'.$list_css.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';


    return $return;


}
