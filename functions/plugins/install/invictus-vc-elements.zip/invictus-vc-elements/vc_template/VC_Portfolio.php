<?php
/**
 *
 * Portfolio VC element by INSIGNIA
 *
 */



/*portfolio*/

add_action( 'vc_before_init', 'insignia_portfolio' );

function insignia_portfolio() {
 $terms = get_terms([
    'taxonomy' => 'portfolio_category',
    'hide_empty' => false,
]);
    $port_categories = array();
    foreach ($terms as $term) {
        $port_categories[$term->slug] = $term->slug;
    }


  vc_map (

 array(
      "name" => __( "Portfolio", "ensign" ),
      "base" => "portfolio",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
	"class" => "font-awesome",
	"icon" => "fa fa-th",
       
      
      "params" => array(
          array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "group" => "General",
            "heading" => __( "Portfolio Layout", "ensign" ),
            "param_name" => "port_layout",
            "admin_label" => true,
            "value"       => array(
	'Select Layout'   => 'Grid',       
	'Grid 2 Columns'   => 'port_grid2',
	'Grid 3 Columns'   => 'port_grid3',
	'Grid 4 Columns' => 'port_grid4',
	'Masonry 2 Columns'  => 'port_masonry2',
	'Masonry 3 Columns'  => 'port_masonry3',
	'Masonry 4 Columns'  => 'port_masonry4',
        'Portfolio Carousel' => 'port_carousel'
      ),
      ),

          array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "group" => "General",
            "heading" => __( "Animation on hover", "ensign" ),
            "param_name" => "port_on_hover",
            "value"       => array(
	'Select Layout'   => 'default',       
	'Layout 1'   => 'layout_1',
	'Layout 2'   => 'layout_2',
	'Layout 3' => 'layout_3',
	'Layout 4'  => 'layout_4',
	'Layout 5'  => 'layout_5',
	'Layout 6'  => 'layout_6',
      ),
      ),

        
          array(
            "type" => "checkbox",
            "class" => "",
            "edit_field_class" => "vc_col-xs-12 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Select Category", "ensign" ),
            "param_name" => "port_cat",
            "group" => "General",
	'save_always' => true,
            "value"       => $port_categories,
     
            "description" => __( "Select Categories. You can choose multiple categories", "ensign" )

      ),

          array(
            "type" => "checkbox",
            "class" => "",
            "edit_field_class" => "vc_col-xs-12 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Force full height", "ensign" ),
            "param_name" => "full_height",
            "group" => "General",
	    'save_always' => true,
            "value"       =>  array('Yes'   => 'full_height_on'),    
             'dependency' => array(
						'element' => 'port_layout',
						'value' => array('port_carousel')
						
                ),     

      ),

          array(
            "type" => "checkbox",
            "class" => "",
            "edit_field_class" => "vc_col-xs-12 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Show filter", "ensign" ),
            "param_name" => "port_filter",
            "group" => "General",
	    'save_always' => true,
            "value"       =>  array('Yes'   => 'filter_on'),         

      ),
          
          
          array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-12 vc_edit_form_elements vc_column-with-padding vc_column",
            "group" => "General",
            "heading" => __( "Filter Button Layout", "ensign" ),
            "param_name" => "filter_layout",
            "value"       => array(
	'Select Layout'   => 'filter_default',       
	'Simple'   => '_simple',
	'Bordered'   => '_bordered',
	'Solid Background' => '_solid_bg'
      ),
            'dependency' => array(
				'element' => 'port_filter',
				'value' => array('filter_on')				
                ),
      ),
      

          
  array(
            "type" => "textfield",
            "class" => "",
      "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Number of Posts to display.", "ensign" ),
            "param_name" => "port_no_posts",
            "group" => "General",
            "value" => __( "", "ensign" ),
              "description" => __( "You can choose limited number of posts to display on page.", "ensign" )
            
         ),
          
          array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "group" => "General",
            "heading" => __( "Load More Options", "ensign" ),
            "param_name" => "port_load_more",
            "value"       => array(
       
        'None'   => 'none',
        'Ajax Load more'   => 'ajax_button',
        'Infinite Scroll' => 'infinite',
        'Numeric Pagination'  => 'pagination'
      ),
      'dependency' => array(
						'element' => 'port_layout',
						'value' => array('Grid','port_grid2','port_grid3','port_grid4','port_masonry2','port_masonry3','port_masonry4')
						
                ),

   ),

  array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Gap", "ensign" ),
            "param_name" => "port_gap",
            "group" => "General",
            "value" => __( "", "ensign" ),
            "description" => __( "Select gap between grid columns(in pixels).Enter Number only, do not add 'px'.", "ensign" )
            
         ),


          array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "group" => "General",
            "heading" => __( "Appear Effects", "ensign" ),
            "param_name" => "appear_effects",
            "value"       => array(
	'Select Effect'   => 'default',       
	'Fade Up'   => 'fade-up',
	'Fade Down'   => 'fade-down',
	'Fade Right' => 'fade-right',
	'Fade Left'  => 'fade-left',
	'Zoom In'  => 'zoom-in',
	'Zoom Out'  => 'zoom-out',
	'Flip Up'  => 'flip-up',
	'Flip Down'  => 'flip-down'
      ),
      ),


         array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Color to overlay image on hover", "ensign" ),
            "param_name" => "port_overlay_color",
            "group" => "General",
            "value" => __( "", "ensign" )
            
         ),

      array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-12 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
              "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
            
         ),
          
      array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Title font size", "ensign" ),
            "param_name" => "title_size",
            "group" => "Typography",
            "value" => __( "", "ensign" ),
            "description" => __( "Select Portfolio title font-size(in pixels).Enter Number only, do not add 'px'.", "ensign" )  
         ),

          array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Title font color", "ensign" ),
            "param_name" => "title_color",
            "group" => "Typography",
            "value" => __( "", "ensign" ),
            "description" => __( "Select Portfolio title font color", "ensign" )
            
         ),


      array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Category font size", "ensign" ),
            "param_name" => "category_size",
            "group" => "Typography",
            "value" => __( "", "ensign" ),
            "description" => __( "Select Portfolio category font-size(in pixels).Enter Number only, do not add 'px'.", "ensign" ) 
         ),

         array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Category font color", "ensign" ),
            "param_name" => "category_color",
            "group" => "Typography",
            "value" => __( "", "ensign" ),
            "description" => __( "Select Portfolio category font color", "ensign" )
            
         ),
  array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Autoplay", "ensign" ),
            "param_name" => "port_autoplay",
            "group" => "Carousel setting",
            "value"       => array(
        
        'True'   => 'true',
        'False'   => 'false'
        
      ),
      "std"         => 'True',
        
            "description" => __( "Enable/Disable Autoplay.", "ensign" ),
             'dependency' => array(
						'element' => 'port_layout',
						'value' => array('port_carousel')
						
                ),
            
         ),
            array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Speed", "ensign" ),
            "param_name" => "port_speed",
            "group" => "Carousel setting",
            "value" => __( "3000", "ensign" ),
            "description" => __( "Choose speed for carousel transition in milliseconds (Example:300).", "ensign" ),
            'dependency' => array(
						'element' => 'port_layout',
						'value' => array('port_carousel')
						
                ),
            
         ),
        array(
            "type" => "textfield",
            "class" => "",
          "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesToShow", "ensign" ),
            "param_name" => "port_slidetoshow",
            "group" => "Carousel setting",
            "value" => __( "1", "ensign" ),
    
            "description" => __( "No. of Testimonials you need to display at a time (Example:3).", "ensign" ),
            'dependency' => array(
						'element' => 'port_layout',
						'value' => array('port_carousel')
						
                ),
            
         ),
     array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesToScroll", "ensign" ),
            "param_name" => "port_slidetoscroll",
            "group" => "Carousel setting",
            "value" => __( "1", "ensign" ),
      
            "description" => __( "No. of Testimonials you need to scroll at a time (Example:1).", "ensign" ),
            'dependency' => array(
						'element' => 'port_layout',
						'value' => array('port_carousel')
						
                ),
            
         ),
        array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Dots", "ensign" ),
            "param_name" => "port_navigation_dots",
            "group" => "Carousel setting",
            "value"       => array(
       
        'True'   => 'true',
        'False'   => 'false'
        
      ),
      "std"         => 'True',
            "description" => __( "Dots for navigation.", "ensign" ),
            'dependency' => array(
						'element' => 'port_layout',
						'value' => array('port_carousel')
						
                ),
            
         ),
    array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Arrows", "ensign" ),
            "param_name" => "port_navigation_arrows",
            "group" => "Carousel setting",
            "value"       => array(
        
           'True'   => 'true',
        'False'   => 'false'
        
      ),
      "std"         => 'True',
            "description" => __( "Arrows for navigation.", "ensign" ),
            'dependency' => array(
						'element' => 'port_layout',
						'value' => array('port_carousel')
						
                ),
            
         ),
    array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "rows", "ensign" ),
            "param_name" => "port_rows",
            "group" => "Carousel setting",
           
      
            "description" => __( "No. of Rows (Example:2)", "ensign" ),
            'dependency' => array(
						'element' => 'port_layout',
						'value' => array('port_carousel')
						
                ),
            
         ),
     array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesPerRow", "ensign" ),
            "param_name" => "port_slidesperrow",
            "group" => "Carousel setting",
            "value" => __( "", "ensign" ),
      
            "description" => __( "No. of slidesPerRow (Example:2)", "ensign" ),
            'dependency' => array(
						'element' => 'port_layout',
						'value' => array('port_carousel')
						
                ),
            
         ),
    array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "infinite", "ensign" ),
            "param_name" => "port_infinite",
            "group" => "Carousel setting",
            "value"       => array(
      
        'True'   => 'true',
        'False'   => 'false'
        
      ),
            "std"         => 'True',
      
            "description" => __( "Infinite loop sliding.", "ensign" ),
            'dependency' => array(
						'element' => 'port_layout',
						'value' => array('port_carousel')
						
                ),
            
         ),
      array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        )


    )));
}



add_shortcode( 'portfolio', 'portfolio_shortcode' );


function portfolio_shortcode( $atts ) {
$css = '';
 extract( shortcode_atts( array(
 'port_layout' => '',
 'port_on_hover' => '',
 'appear_effects' => '',
 'port_no_posts' => '',
 'port_cat' => '',
 'port_filter' => '',
 'full_height' => '',
 'filter_layout' => '',
 'filter_transitions' => '',
 'port_load_more' => '',
 'port_gap' => '',
 'port_overlay_color' =>'',
 'port_autoplay' => '',
 'port_speed' => '',
 'port_slidetoshow' => '',
 'port_slidetoscroll' => '',
 'port_navigation_dots' => '',
 'port_navigation_arrows' => '',
 'port_rows' => '',
 'port_slidesperrow' => '',
 'port_infinite' => '',
 'css' => '',
 'extra_class' => '',
 'title_size' => '',
 'title_color' => '',
 'category_size' => '',
 'category_color' => '',

 'fieldName' => ''
   ), $atts ) );

global $post, $port_no_posts1, $port_out, $port_on_hover1, $appear_effects1, $port_filter1, $filter_layout1, $filter_transitions1, $port_cat1, $port_load_more1, $port_gap1, $port_overlay_color1, $port_auto1, $port_speed1, $port_slidetoshow1, $port_slidetoscroll1, $port_dots, $port_arrows, $port_rows1, $port_slidesperrow1, $port_infinite1, $css1, $portfolio_extra_class1, $title_size1, $title_color1, $category_size1, $category_color1, $full_height1;

$port_auto1= ${'port_autoplay'};

$port_out = ${'port_layout'};
$port_on_hover1 = ${'port_on_hover'};
$appear_effects1 = ${'appear_effects'};
$port_no_posts1 = ${'port_no_posts'}; 
$port_cat1 = ${'port_cat'};
$port_load_more1 = ${'port_load_more'};
$port_gap1  = ${'port_gap'};
$port_overlay_color1 = ${'port_overlay_color'};
$port_filter1 = ${'port_filter'};
$full_height1 = ${'full_height'};

$filter_layout1 = ${'filter_layout'};
$filter_transitions1 = ${'filter_transitions'};
	$port_speed1= ${'port_speed'};
	$port_slidetoshow1= ${'port_slidetoshow'};
	$port_slidetoscroll1= ${'port_slidetoscroll'};
	$port_dots=${'port_navigation_dots'};
	$port_arrows=${'port_navigation_arrows'};
	$port_rows1= ${'port_rows'};
	$port_slidesperrow1 = ${'port_slidesperrow'};
	$port_infinite1= ${'port_infinite'};
        $css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
        $portfolio_extra_class1=${'extra_class'};
 $title_size1 = ${'title_size'};
 $title_color1 = ${'title_color'};
 $category_size1 = ${'category_size'};
 $category_color1 = ${'category_color'};

      
       if(!isset($portfolio_extra_class1))
        $portfolio_extra_class1='';

       if(empty($port_no_posts1)){
        $port_no_posts1='-1'; }


$selected_cat = explode(',', $port_cat1);
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	if(empty($port_cat1)){

	$args = array(
	'post_type' => 'portfolio',
	'posts_per_page' => $port_no_posts1,
	'paged'=>$paged
);
} else{

	$args = array(
	'post_type' => 'portfolio',
	'posts_per_page' => $port_no_posts1,
	'tax_query' => array(
		array(
			'taxonomy' => 'portfolio_category',
			'field'    => 'slug',
		 'terms' => $selected_cat
		),
	),
       'paged'=>$paged
	
);
}
	
	
		$posts = new WP_Query($args);
if ( $posts->have_posts() ) {
if($port_out == "port_grid2" || $port_out == "port_grid3" || $port_out == "port_grid4")
{
	ob_start();
	include(locate_template('templates/portfolio/archive/portfolio-grid-main.php'));
	$return_html = trim(preg_replace('/\s\s+/', ' ', ob_get_clean()));
	return $return_html;
}

elseif($port_out == "port_masonry2" || $port_out == "port_masonry3" || $port_out == "port_masonry4")  {
	ob_start();
	include(locate_template('templates/portfolio/archive/portfolio-masonry-main.php'));
	$return_html = trim(preg_replace('/\s\s+/', ' ', ob_get_clean()));
	return $return_html;
}

elseif($port_out == "port_carousel")  {
	ob_start();
	include(locate_template('templates/portfolio/archive/portfolio-carousel-main.php'));
	$return_html = trim(preg_replace('/\s\s+/', ' ', ob_get_clean()));
	return $return_html;
}

else{
	ob_start();
	include(locate_template('templates/portfolio/archive/portfolio-grid-main.php'));
	$return_html = trim(preg_replace('/\s\s+/', ' ', ob_get_clean()));
	return $return_html;
}
}else{
	echo "<p class='insignia-error-text text-center'>No Portfolio found.</p>";
}
}


