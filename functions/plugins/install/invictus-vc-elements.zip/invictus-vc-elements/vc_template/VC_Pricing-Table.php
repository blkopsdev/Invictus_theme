<?php
/**
 *
 * Pricing Table VC element by INSIGNIA
 *
 */



/*Price Table Element*/


add_action( 'vc_before_init', 'VC_pricing_table' );

function VC_pricing_table() {
  vc_map (

 array(
      "name" => __( "Pricing Table", "ensign" ),
      "base" => "insignia_pricing_table",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
        "class" => "font-awesome",
	"icon" => "fa fa-usd",
       
      "params" => array(
      
      array(
            "type" => "dropdown",
            "class" => "",
              "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Select Design Style", "ensign" ),
            "param_name" => "design_style",
            "group" => "General",
              "description" => __( "Select Pricing table design you would like to use", "ensign" ),
             "value"       => array(
       
        'Design 1'   => 'first',
         'Design 2'   => 'second',
          'Design 3'   => 'three',
        'Design 4'   => 'four',
        'Design 5'   => 'five',
        'Design 6'   => 'six'


         ),
      "std"         => '',
            
         ),
         
    array(
            "type" => "iconpicker",
            "class" => "",
             "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",

            "heading" => __( "Select icon", "ensign" ),
            "param_name" => "social_icon",
            "group" => "General",
            "value" => __( "", "ensign" ),
             'dependency' => array(
						'element' => 'design_style',
						'value' => array('second')
						
                ),
            
         ),
       


array(
            "type" => "textfield",
            "class" => "",
          "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Package Name / Title", "ensign" ),
            "param_name" => "package_name",
            "group" => "General",
            "value" => __( "", "ensign" ),
              "description" => __( "Enter the package name or table heading", "ensign" )
            
         ),
         
         /*
array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Sub Heading", "ensign" ),
            "param_name" => "sub_heading",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Enter short description for this package", "ensign" ),
             
            
         ),*/


 array(
            "type" => "textfield",
            "class" => "",
          "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Price Value", "ensign" ),
            "param_name" => "price_value",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Currency or other value prices. e.g. $", "ensign" )
         
         ),




 array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
             "heading" => __( "Package Price", "ensign" ),
            "param_name" => "package_price",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Enter the price for this package. e.g. $157", "ensign" )
         
         ),
 array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Price Unit", "ensign" ),
            "param_name" => "price_sub_heading",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Enter the price unit for this package. e.g. per month", "ensign" ),
            
         
         ),




     array(
            "type" => "textarea_html",
            "class" => "",
            
            "heading" => __( "Features", "ensign" ),
            "param_name" => "content",
            "group" => "General",
             "value" => __( "<p class='xyz'>I am test text block. Click edit button to change this text.</p>", "ensign" )
     
          
            ),



       array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Button Text", "ensign" ),
            "param_name" => "button_text",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Enter call to action button text", "ensign" )
             
         ),

      
       array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Button Link", "ensign" ),
            "param_name" => "button_link",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "enter the link for call to action button", "ensign" )
            
         ),
         
          
          array(
                  "type"        => "checkbox",
                  "param_name" => "bg_color",
                  "class" => "",
                   "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
                    "group" => "General",
                     'save_always' => true,
                    "value"         => array('Make it Featured'   => '1' ),
                   
                    
						
                ),
                
                 array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Background Color", "ensign" ),
            "param_name" => "background",
            "group" => "General",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Background Color.If you leave it empty, It will set theme color", "ensign" ),
              'dependency' => array(
						'element' => 'bg_color',
						'value' => array('1')
						
                ),
               						
                ),
                
      
                
                

       array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
            
         ),
     
     
        array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        )
         

         
      
                  
                 






   ) ));
}

add_shortcode( 'insignia_pricing_table', 'insignia_pricing_table_shortcode' );
function insignia_pricing_table_shortcode( $atts,$content) {
 extract( shortcode_atts( array(
      
     'design_style' => '',
      'package_name' => '',
      'sub_heading' => '',
      'price_value' => '',
      'box_image' =>'',
      'price_sub_heading'=>'',
        'content' =>$content,
        'extra_class'=>'',
        'button_text' => '',
        'button_link' => '',
        'bg_color' =>'',
        'package_price' => '',
        'background'=>'',
        'btn_size'=>'',
        'css'=> '',
        'social_icon'=> ''

   ), $atts ) );


global $design_style1,$package_name1,$sub_heading1,$price_value1,$price_sub_heading1,$content1,$button_text1,$extra_class1,$button_link1,$package_price1,$background1,$css1,$social_icon1; 

$design_style1= ${'design_style'};
$package_name1= ${'package_name'};
$sub_heading1= ${'sub_heading'};
$price_value1= ${'price_value'};
$price_sub_heading1= ${'price_sub_heading'};
$content1= ${'content'};
$extra_class1=${'extra_class'};
$button_text1= ${'button_text'};

$button_link1= ${'button_link'};
$bg_color1=${'bg_color'};
$package_price1=${'package_price'};
$background1=${'background'};
$social_icon1=${'social_icon'};

$css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );









if($design_style1== "first")
{


$return="<div class='layout-1-pricing-plan-wrapper ".$extra_class1." ".$css1."'>";
if(!empty($bg_color1)) {
 $return.="<div class='layout-1-pricing-plan-inner layout-1-pricing-plan-featured centered-box' style='background-color:".$background1."'>";
}else{

     $return.="<div class='layout-1-pricing-plan-inner centered-box'>";
}

if(!empty($package_name1)) {

if(!empty($bg_color1)) {
 $return.="<div class='layout-1-pricing-plan-header' style='background-color:".$background1."'>";
}else{

     $return.="<div class='layout-1-pricing-plan-header'>";
}

$return.="<h3>".$package_name1."</h3>";

$return.="</div>";
}
$return.="<div class='layout-1-pricing-plan-sub-header'>";
$return.="<div class='layout-1-pricing-plan-price-inner'>";
if(!empty($package_price1)) {

$return.="<span class='layout-1-pricing-plan-price'>";
if(!empty($price_value1)) {
$return.="<sup class='dollar-icon'>".$price_value1."</sup>";
}
$return.=$package_price1;


$return.="</span>";
}
if(!empty($price_sub_heading1)) {
$return.="<span class='layout-1-pricing-plan-time'>".$price_sub_heading1."</span>";
}
$return.="</div>";
$return.="</div>";
$return.="<div class='layout-1-pricing-table-list'>";
if(!empty($content1)) {
$return.="<p>".$content1."</p>";
}
if(!empty($button_text1)) {
$return.="<div class='layout-1-button-holder layout-1-pricing-button'><a class='layout-1-button pc-bg' href='".$button_link1."'>".$button_text1."</a>";
}
$return.="</div>";
$return.="</div>";
$return.="</div>";

$return.="</div>";

return $return;

}


elseif($design_style1== "second")
{

if(!empty($bg_color1)) {
 $return="<div class='layout-2-pricing-table-box layout-2-pricing-table-bg ".$extra_class1." ".$css1."' style='background-color:".$background1."'>";
}else{

     $return="<div class='layout-2-pricing-table-box ".$extra_class1." ".$css1."'>";
}

$return.="<i class='".$social_icon1."'><!--hh--></i>";
if(!empty($package_name1)) {
$return.="<h3 class='layout-2-package-name'>".$package_name1."</h3>";
}
if(!empty($package_price1)) {

$return.="<h6 class='layout-2-price-wrapper'>";
if(!empty($price_value1)) {
$return.="<span class='layout-2-dollar-text'>".$price_value1."</span>";
}
$return.=$package_price1;
if(!empty($price_sub_heading1)) {
$return.="<span class='layout-2-month-text'>/ ".$price_sub_heading1."</span>";
}
$return.="</h6>";
}
if(!empty($content1)) {
$return.="<p>".$content1."</p>";
}
if(!empty($button_text1)) {

$return.="<p><a class='layout-2-pricing-table-button' href='".$button_link1."'>".$button_text1."</a>";
}
$return.="</div>";

return $return;

}

elseif($design_style1== "three")
{



     $return="<div class='inv-pricing-three-wrapper ".$extra_class1." ".$css1."'>";


if(!empty($bg_color1)) {
 $return.="<div class='inv-pricing-three-inner inv-pricing-three-wrapper-bg ".$extra_class1." ".$css1."' style='background-color:".$background1."'>";
}else{

     $return.="<div class='inv-pricing-three-inner ".$extra_class1." ".$css1."'>";
}
if(!empty($package_name1)) {

$return.="<h5 class='inv-pricing-three-title'>".$package_name1."</h5>";
}
if(!empty($package_price1)) {

$return.="<p class='inv-pricing-three-price'>";
if(!empty($price_value1)) {
$return.="<span class='inv-pricing-three-currency'>".$price_value1."</span>";
}
$return.=$package_price1;
if(!empty($price_sub_heading1)) {
$return.="<span class='inv-pricing-three-duration'>/ ".$price_sub_heading1."</span>";
}
$return.="</p>";
}
if(!empty($content1)) {
$return.="<p>".$content1."</p>";
}
if(!empty($button_text1)) {

$return.="<div class='app-button-holder'><a class='app-button' href='".$button_link1."'>".$button_text1."</a></div>";
}


$return.="</div>";
$return.="</div>";


return $return;


}
elseif($design_style1== "four")
{
if(!empty($bg_color1)) {
 $return="<div class='layout-4-pricing-tabels-box layout-4-pricing-tabels-box-bg ".$extra_class1." ".$css1."' style='background-color:".$background1."'>";
}else{

     $return="<div class='layout-4-pricing-tabels-box ".$extra_class1." ".$css1."'>";
}
if(!empty($package_name1)) {
$return.="<h4>".$package_name1."</h4>";
}
if(!empty($package_price1)) {
$return.="<h5>".$price_value1."".$package_price1."</h5>";
}
if(!empty($price_sub_heading1)) {
$return.="<h6>".$price_sub_heading1."</h6>";
}
if(!empty($content1)) {
$return.="<p>".$content1."</p>";
}
if(!empty($button_text1)) {

$return.="<div class='layout-4-button-holder centered-box layout-4-pricing-table-button'><a class='layout-4-button-bg' href='".$button_link1."'>".$button_text1."</a></div>";
}
$return.="</div>";


return $return;

}

elseif($design_style1== "five")
{

if(!empty($bg_color1)) {
 $return="<div class='layout-5-pricing-plan-wrapper layout-5-pricing-tabels-box-bg ".$extra_class1." ".$css1."' style='background-color:".$background1."'>";
}else{

    $return="<div class='layout-5-pricing-plan-wrapper ".$extra_class1." ".$css1."'>";
}

  
$return.="<div class='layout-5-pricing-plan-inner'>";
$return.="<div class='layout-5-pricing-plan-title-wrapper'>";
if(!empty($package_name1)) {
$return.="<div class='layout-5-pricing-plan-title-inner'>";
$return.="<h2 class='layout-5-pricing-plan-title'>".$package_name1."</h2>";
$return.="</div>";
}
$return.="<div class='layout-5-pricing-plan-price-wrapper'>";
$return.="<div class='layout-5-pricing-plan-price-inner'>";
if(!empty($package_price1)) {
$return.="<span class='layout-5-pricing-plan-price'>".$price_value1."".$package_price1."</span>";
}
if(!empty($price_sub_heading1)) {
$return.="<span class='layout-5-pricing-plan-time'>".$price_sub_heading1."</span>";
}
$return.="</div>";
$return.="</div>";
$return.="</div>";
$return.="<div class='layout-5-pricing-content'>";
if(!empty($content1)) {
$return.="<p>".$content1."</p>";
}
$return.="<div class='layout-5-button-holder layout-5-pricing-button centered-box'>";
if(!empty($button_text1)) {
$return.="<a class='layout-5-button' href='".$button_link1."'>".$button_text1."</a>";
}
$return.="</div>";
$return.="</div>";
$return.="</div>";
$return.="</div>";

return $return;

}


elseif($design_style1== "six")
{

if(!empty($bg_color1)) {
 $return="<div class='layout-6-pricing-main-wrapper layout-6-pricing-tabels-box-bg ".$extra_class1." ".$css1."'>";
}else{

    $return="<div class='layout-6-pricing-main-wrapper ".$extra_class1." ".$css1."'>";
}


$return.="<div class='layout-6-pricing-inner'>";
if(!empty($package_name1)) {
$return.="<h3 class='layout-6-pricing-title'>".$package_name1."</h3>";
}
if(!empty($package_price1)) {
$return.="<div class='layout-6-pricing-price'>";
$return.="<span class='layout-6-pricing-currency'>".$price_value1."</span>";
$return.=$package_price1;
$return.="</div>";
}
if(!empty($price_sub_heading1)) {
$return.="<p class='layout-6-pricing-sentence'>".$price_sub_heading1."</p>";
}
if(!empty($content1)) {
$return.="<p>".$content1."</p>";
}
if(!empty($button_text1)) {

$return.="<div class='layout-6-button-wrapper layout-6-pricing-button'>";
$return.="<a class='layout-6-button' href='".$button_link1."'><span class='layout-6-button-text pc-bg pc-border'>".$button_text1."</span></a>";
$return.="</div>";
}
$return.="</div>";
$return.="</div>";

return $return;

}
}
