<?php
/**
 *
 * Twitter Feed
 *
 */



/*Twitter Feed Element*/

add_action( 'vc_before_init', 'VC_twitter' );
function VC_twitter() {


   vc_map( array(
      "name" => __( "Twitter Feeds", "ensign" ),
      "base" => "twitter_feed",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
     	"class" => "font-awesome",
	"icon" => "fa fa-twitter",
      "params" => array(

             array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Consumer Key:", "ensign" ),
            "param_name" => "twitter_consumer_key",
            "group" => "General"
         ),

             array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Consumer Secret:", "ensign" ),
            "param_name" => "twitter_consumer_secret",
            "group" => "General"
         ),

             array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Access Token:", "ensign" ),
            "param_name" => "twitter_access_token",
            "group" => "General"
         ),

             array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Access Token Secret:", "ensign" ),
            "param_name" => "twitter_access_token_secret",
            "group" => "General"
         ),

             array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Twitter ID:", "ensign" ),
            "param_name" => "twitter_id",
            "group" => "General"
         ),   

             array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Number of Tweets:", "ensign" ),
            "param_name" => "twitter_no_of_tweets",
            "group" => "General"
         ),
         
             array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "twitter_extra_class",
            "group" => "General",
            
             "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
         ),
 
         array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-4 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Icon Color", "ensign" ),
            "param_name" => "twitter_icon_color",
            "group" => "Typography",
            "value" => __( "", "ensign" )
            
         ),

   array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-4 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Tweet Text Color", "ensign" ),
            "param_name" => "twitter_tweet_color",
            "group" => "Typography",
            "value" => __( "", "ensign" )
            
         ),

   array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-4 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Date color", "ensign" ),
            "param_name" => "tweet_date_color",
            "group" => "Typography",
            "value" => __( "", "ensign" )
            
         ),


       
       )
   ) );
}

add_shortcode( 'twitter_feed', 'twitter_feed_shortcode' );
function twitter_feed_shortcode( $atts ) {
 extract( shortcode_atts( array(

      'twitter_consumer_key' => '',
      'twitter_consumer_secret' => '',
      'twitter_access_token' => '',
      'twitter_access_token_secret' => '',
      'twitter_id' => '',
      'twitter_no_of_tweets' => '',
      'twitter_extra_class' => '',
      'twitter_icon_color' => '',
      'twitter_tweet_color' => '',
      'tweet_date_color' => ''
       
             
 ), $atts ) );
global $post;   

global $twitter_consumer_key1 , $twitter_consumer_secret1, $twitter_access_token1, $twitter_access_token_secret1, $twitter_id1, $twitter_no_of_tweets1, $twitter_extra_class1, $twitter_icon_color1, $twitter_tweet_color1, $tweet_date_color1;

$twitter_consumer_key1 = ${'twitter_consumer_key'};
$twitter_consumer_secret1 = ${'twitter_consumer_secret'};
$twitter_access_token1 = ${'twitter_access_token'};
$twitter_access_token_secret1 = ${'twitter_access_token_secret'};
$twitter_id1 = ${'twitter_id'};
$twitter_no_of_tweets1 = ${'twitter_no_of_tweets'};
$twitter_extra_class1 = ${'twitter_extra_class'};
$twitter_icon_color1 = ${'twitter_icon_color'};
$twitter_tweet_color1 = ${'twitter_tweet_color'};
$tweet_date_color1 = ${'tweet_date_color'};

 
if(!isset($twitter_extra_class1)){
    $twitter_extra_class1='';
}
if(!isset($twitter_icon_color1) || empty($twitter_icon_color1) ){
    $twitter_icon_color1='#666666';
}
if(!isset($twitter_tweet_color1) || empty($twitter_tweet_color1)){
    $twitter_tweet_color1='#666666';
}
if(!isset($tweet_date_color1) || empty($tweet_date_color1)){
    $tweet_date_color1='#666666';
}


	ob_start();
	include(locate_template('templates/twitter/twitter-feed.php'));
	$return_html = trim(preg_replace('/\s\s+/', ' ', ob_get_clean()));
	return $return_html;



} 

