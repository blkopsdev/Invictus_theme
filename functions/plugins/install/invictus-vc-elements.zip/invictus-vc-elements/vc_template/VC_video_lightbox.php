<?php
/**
 *
 * Video Light Box
 *
 */



/*Video model Element*/

add_action( 'vc_before_init', 'VC_video_lightbox' );
function VC_video_lightbox() {


   vc_map( array(
      "name" => __( "Video Lightbox", "ensign" ),
      "base" => "vc_video_box",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
     	"class" => "font-awesome",
	"icon" => "fa fa-play-circle",
      "params" => array(

             array(
            "type" => "textfield",
            "class" => "",
            "heading" => __( "Youtube/Vimeo Video link:", "ensign" ),
            "param_name" => "video_link",
            "group" => "General"
         ),

             array(
            "type" => "attach_image",
            "class" => "",
            "edit_field_class" => "vc_col-xs-12 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Select Background Image", "insignia" ),
            "param_name" => "video_image",
            "group" => "General",
            "value" => __( "", "insignia" )
            
         ),
         
             array(
            "type" => "textfield",
            "class" => "",
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "video_extra_class",
            "group" => "General",
             "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
         ),
        array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        )
       
       )
   ) );
}

add_shortcode( 'vc_video_box', 'vc_video_shortcode' );
function vc_video_shortcode( $atts ) {
$css = '';
 extract( shortcode_atts( array(

      'video_link' => '',
      'video_image' => '',
      'video_bg_color' => '',
      'video_extra_class' => '',
      'css'=> '',
       
             
 ), $atts ) );
global $post;   

global $video_link1 , $video_image1, $video_extra_class1, $css1;

$video_link1 = ${'video_link'};
$video_image1 = ${'video_image'};
$video_extra_class1 = ${'video_extra_class'};

$css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );

 
if(!isset($video_extra_class1)){
    $video_extra_class1='';
}

	$return="<div class='inv-video-lightbox inv-color-scheme-white inv-video-lightbox-img clearfix ".$video_extra_class1." ".$css1."'>";
	$return.="<div class='inv-video-lightbox-inner'>";
	$return.="<div class='inv-video-lightbox-image-holder' style='background-image:url(".wp_get_attachment_url($video_image1).")'>";
	$return.="<div class='inv-bg-overlay'>";
	$return.="</div>";
	$return.="<a href='".$video_link1."' class='inv-video-link inv-video-lightbox-element'>";
	$return.="<div class='inv-video-lightbox-image-icon'>";
	$return.="<i class='inv-video-lightbox-play-icon icon-control-play icons'></i>";
	$return.="</div>";
	$return.="</a>";
	$return.="</div>";
	$return.="</div>";
	$return.="</div>";
	return $return;



} 

