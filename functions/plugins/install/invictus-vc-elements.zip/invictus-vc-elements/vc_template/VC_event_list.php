<?php
/**
 *
 * Event VC element by INSIGNIA
 *
 */



/*Event List*/

add_action( 'vc_before_init', 'insignia_event' );

function insignia_event() {



  vc_map (

 array(
      "name" => __( "Event list", "ensign" ),
      "base" => "event_list",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
	"class" => "font-awesome",
	"icon" => "fa fa-calendar",       
       
      
      "params" => array(
        
          
  array(
            "type" => "textfield", 
            "class" => "",
      "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Number of Events to display.", "ensign" ),
            "param_name" => "event_no_posts",
            "group" => "General",
            "value" => __( "", "ensign" ),
              "description" => __( "You can choose limited number of posts to display on page.", "ensign" )
            
         ),
          
          array(
            "type" => "checkbox",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Ignore Running Events", "ensign" ),
            "param_name" => "running_events",
            "group" => "General",
	'save_always' => true,
            "value"       => __( "true", "ensign" )
            

      ),
  
      array(
            "type" => "textfield",
            "class" => "",
      "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",      
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "event_extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
              "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
            
         ),
        array(
            "type" => "",
            "class" => "",
            "edit_field_class" => "vc_col-xs-12 vc_edit_form_elements vc_column-with-padding vc_column ins_vc_element_title",      
            "heading" => __( "Default Color Styles:", "ensign" ),
            "param_name" => "event_default_style_title",
            "group" => "Typography",
            "value" => __( "", "ensign" )
         ),
       array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-4 vc_edit_form_elements vc_column-with-padding vc_column",      
            "heading" => __( "Date text color", "ensign" ),
            "param_name" => "event_date_color",
            "group" => "Typography",
            "value" => "#666666"
         ),
       array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-4 vc_edit_form_elements vc_column-with-padding vc_column",      
            "heading" => __( "Event name text color", "ensign" ),
            "param_name" => "event_name_color",
            "group" => "Typography",
            "value" => __( "#ec5355", "ensign" )
         ),
       array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-4 vc_edit_form_elements vc_column-with-padding vc_column",      
            "heading" => __( "location text color", "ensign" ),
            "param_name" => "event_location_color",
            "group" => "Typography",
            "value" => __( "#666666", "ensign" )
         ),
       array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-4 vc_edit_form_elements vc_column-with-padding vc_column",      
            "heading" => __( "Button text color", "ensign" ),
            "param_name" => "event_button_text_color",
            "group" => "Typography",
            "value" => __( "#f5f5f5", "ensign" )
         ),
       array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-4 vc_edit_form_elements vc_column-with-padding vc_column",      
            "heading" => __( "Button background color", "ensign" ),
            "param_name" => "event_button_bg_color",
            "group" => "Typography",
            "value" => __( "#ec5355", "ensign" )
         ),
       
      array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        )


    )));
}



add_shortcode( 'event_list', 'event_list_shortcode' );


function event_list_shortcode( $atts ) {
$css = '';
 extract( shortcode_atts( array(
 'event_layout' => '',
 'event_no_posts' => '',
 'running_events' => '',
 'event_date_color' => '',
 'event_name_color' => '',
 'event_location_color' => '',
 'event_button_text_color' => '',
 'event_button_bg_color' => '',

 'css' => '',
 'event_extra_class' => '',


 'fieldName' => ''
   ), $atts ) );

global $post, $event_no_posts1, $running_events1, $event_out, $css1, $event_extra_class1, $event_date_color1, $event_name_color1, $event_location_color1, $event_button_text_color1, $event_button_bg_color1;


$event_out = ${'event_layout'};
$event_no_posts1 = ${'event_no_posts'};
$running_events1 = ${'running_events'}; 
	$event_date_color1 = ${'event_date_color'};
	$event_name_color1 = ${'event_name_color'};
	$event_location_color1 = ${'event_location_color'};
	$event_button_text_color1 = ${'event_button_text_color'};
	$event_button_bg_color1 = ${'event_button_bg_color'};
	
	
        $css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
        $event_extra_class1=${'event_extra_class'};

      
       if(!isset($event_extra_class1))
        $event_extra_class1='';
  

	$args = array(
  'post_status'=>'publish',
  'post_type'=>array(Tribe__Events__Main::POSTTYPE),
  'posts_per_page'=>$event_no_posts1
	
);
	
		$get_posts = null;
		$get_posts = new WP_Query();


	ob_start();
	include(locate_template('templates/events/event-list.php'));
	$return_html = trim(preg_replace('/\s\s+/', ' ', ob_get_clean()));
	return $return_html;



}



