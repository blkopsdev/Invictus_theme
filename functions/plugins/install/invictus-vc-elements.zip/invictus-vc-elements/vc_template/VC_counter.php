<?php
/**
 *
 * Counter custom field
 *
 */



/*Counter Element*/

add_action( 'vc_before_init', 'VC_counter' );
function VC_counter() {
   vc_map( array(
      "name" => __( "Counter-Box", "ensign" ),
      "base" => "counter",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
     	"class" => "font-awesome",
	"icon" => "fa fa-sort-numeric-asc",
      "params" => array(

 array(
            "type" => "textfield",
            "class" => "",
            "heading" => __( "Date", "ensign" ),
            "param_name" => "date",
            "group" => "General",
              "value" => __( "", "ensign" ),

          "description" => __( "Date Format (Example:20-May-2017)", "ensign" )
            
         ),
 array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-3 vc_edit_form_elements vc_column-with-padding vc_column",

            "heading" => __( "Hours", "ensign" ),
            "param_name" => "hour",
            "group" => "General",
              "value" => __( "", "ensign" ),

          "description" => __( "Example:05", "ensign" )
            
         ),
 array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-3 vc_edit_form_elements vc_column-with-padding vc_column",

            "heading" => __( "Minutes", "ensign" ),
            "param_name" => "minute",
            "group" => "General",
              "value" => __( "", "ensign" ),

          "description" => __( "Example:30", "ensign" )
            
         ),

array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-2 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "AM/PM", "ensign" ),
            "param_name" => "time",
            "group" => "General",
            "value"       => array(
        
        'AM'   => 'am',
        'PM'   => 'pm'
        
      ),
      "std"         => 'AM',
        
            "description" => __( "Select AM or PM.", "ensign" )
            
         ),

            
             array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            
             "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
         ),

        array(
            "type" => "textfield",
            "class" => "",
              "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Number Font-Size", "ensign" ),
            "param_name" => "date_font",
            "group" => "Typography",
            "value" => __( "", "ensign" )
            
         ),
         array(
            "type" => "textfield",
            "class" => "",
           "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Text Font-Size", "ensign" ),
            "param_name" => "label_font",
            "group" => "Typography",
            "value" => __( "", "ensign" )
            
         ),
 
         array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Number Color", "ensign" ),
            "param_name" => "date_color",
            "group" => "Typography",
            "value" => __( "", "ensign" )
            
         ),

   array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Text Color", "ensign" ),
            "param_name" => "label_color",
            "group" => "Typography",
            "value" => __( "", "ensign" )
            
         ),


       
       )
   ) );
}

add_shortcode( 'counter', 'counter_shortcode' );
function counter_shortcode( $atts ) {
 extract( shortcode_atts( array(
      'date' => '',
      'extra_class' =>'',
      'label_font' => '',
      'date_font' => '',
      'date_color' => '',
      'label_color' => '',
      'hour' => '',
      'minute' => '',
      'time' => ''

       
             
 ), $atts ) );
global $post;   

global $date1,$extra_class1,$label_font1,$date_font1,$date_color1,$label_color1,$ins_opt,$hour1,$minute1,$time1;

$date1= ${'date'};
$extra_class1=${'extra_class'};
$label_font1=${'label_font'};
$date_font1=${'date_font'};
$date_color1=${'date_color'};
$label_color1=${'label_color'};
$hour1=${'hour'};
$minute1=${'minute'};
$time1=${'time'};




 
if(!isset($extra_class1))
    $extra_class1='';



if(empty($date_color1))
    $date_color1=$ins_opt['ins-opt-pc'];


if(empty($label_color1))
    $label_color1=$ins_opt['ins-opt-pc'];



if(!empty($date1)):
$return="<div id='getting-started' class='".$extra_class1." counter-box clearfix'>";
$date1;
$return.="</div>";

 return $return;
endif;
} 

