<?php
/**
 *
 * Product category VC element by INSIGNIA
 *
 */



/*Product category Element*/

add_action( 'vc_before_init', 'insignia_prdct_cat' );

function insignia_prdct_cat() {

$terms = get_terms( 'product_cat');
    $product_categories = array();
array_unshift($product_categories,"Select Product category");
foreach ( $terms as $term ) {
        $product_categories[$term->name] = $term->slug;
}

  vc_map (

 array(
      "name" => __( "Product Category", "ensign" ),
      "base" => "product_cat",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
	"class" => "font-awesome",
	"icon" => "fa fa-shopping-cart",        
       
      
      "params" => array(
          array(
            "type" => "dropdown",
            "class" => "",
             "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "group" => "General",
            "heading" => __( "Select layout", "ensign" ),
            "param_name" => "product_cat_layout",
            "value"       => array(
        'Select Layout'=>'None',
        'Layout 1'   => 'Style 1',
        'Layout 2'   => 'Style 2',
         'Layout 3'   => 'Style 3'

      ),
         ),
         
          array(
            "type" => "dropdown",
            "class" => "",
            
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Select Product Cateogry", "ensign" ),
            "param_name" => "product_cat_name",
            "group" => "General",
            "value"       => $product_categories, 
                      
            "description" => __( "Select Product Cateogry", "ensign" )
           

      ),
      
  
   array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        ),
          
   
      
      
     array(
            "type" => "textfield",
            "class" => "",
      
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
              "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
            
         ),


   ) ));
}



add_shortcode( 'product_cat', 'product_cat' );


function product_cat( $atts ) {
$css = '';
 extract( shortcode_atts( array(
 'product_cat_name' => '',       
 'product_cat_layout' => '',
 'extra_class' => '',
 'css' => ''

   ), $atts ) );
global $post;   

global $extra_class1, $product_cat_name1 , $css1, $product_cat_layout1;





$product_cat_name1 = ${'product_cat_name'};
$product_cat_link = get_term_link( $product_cat_name1, 'product_cat' );
$term1 = get_term_by('slug', $product_cat_name1, 'product_cat');
$product_cat_id = $term1->term_id;
$thumbnail_id = get_woocommerce_term_meta( $term1->term_id, 'thumbnail_id', true );
$product_cat_image = wp_get_attachment_url( $thumbnail_id );
$term = get_term($product_cat_id, 'product_cat' );
$term_count = $term->count;
$extra_class1 = ${'extra_class'};
$product_cat_layout1 = ${'product_cat_layout'};

$css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );


if(!isset($extra_class1))
    $extra_class1='';

if($product_cat_layout1 == "Style 1")
{


$return="<article class='inv-product-cat-hover-1-wrapper ".$extra_class1." ".$css1."'>";
$return.="<div class='inv-product-cat-hover-1-content'>";
$return.="<a class='inv-product-cat-link' href=". $product_cat_link . ">";
$return.="<img src=' ".$product_cat_image."' alt='cat-img'>";
$return.="</a>";
$return.="<div class='inv-product-cat-1-info'>";
$return.="<h4 class='inv-product-cat-1-title'>";
$return.=$product_cat_name1;
$return.="</h4>";
$return.="<div class='inv-product-cat-1-prd-num'>";
$return.= $term_count ." Products";
$return.="</div>";
$return.="</div>";
$return.="</div>";
$return.="</article>";

    return $return;
    

}elseif($product_cat_layout1 == "Style 2")
{


$return="<article class='inv-product-cat-hover-2-wrapper ".$extra_class1." ".$css1."'>";
$return.="<div class='inv-product-cat-hover-2-content'>";
$return.="<a class='inv-product-cat-2-link' href=". $product_cat_link . ">";
$return.="<div class='inv-product-cat-hover-2'>";
$return.="</div>";
$return.="<img src=' ".$product_cat_image."' alt='cat-img'>";
$return.="</a>";
$return.="<div class='inv-product-cat-2-info'>";
$return.="<h4 class='inv-product-cat-2-title'>";
$return.=$product_cat_name1;
$return.="</h4>";
$return.="<div class='inv-product-cat-2-prd-num'>";
$return.= $term_count ." Products";
$return.="</div>";
$return.="</div>";
$return.="</div>";
$return.="</article>";

    return $return;
    
} else{


$return="<article class='inv-product-cat-hover-3-wrapper js-tilt ".$extra_class1." ".$css1."' data-tilt-glare='false' data-tilt-speed='400' data-tilt-scale='1.04' data-tilt-maxtilt='50' data-tilt-perspective='2500' data-tilt-easing='cubic-bezier(.03,.98,.52,.99)'>";
$return.="<div class='inv-product-cat-hover-3-content'>";
$return.="<a class='inv-product-cat-3-link' href=". $product_cat_link . ">";
$return.="<div class='inv-product-cat-hover-3'>";
$return.="</div>";
$return.="<img src=' ".$product_cat_image."' alt='cat-img'>";
$return.="</a>";
$return.="<div class='inv-product-cat-3-info'>";
$return.="<h4 class='inv-product-cat-3-title'>";
$return.="<span>";
$return.=$product_cat_name1;
$return.="</span>";
$return.="</h4>";
$return.="</div>";
$return.="</div>";
$return.="</article>";

    return $return;

}

}

