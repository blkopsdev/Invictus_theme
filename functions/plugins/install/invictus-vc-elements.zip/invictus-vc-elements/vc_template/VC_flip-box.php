<?php
/**
 *
 * Flip Box VC element by INSIGNIA
 *
 */



/*Flip Box Element*/




add_action( 'vc_before_init', 'VC_flip_box' );

function VC_flip_box() {
  vc_map (

 array(
      "name" => __( "Flip Box", "ensign" ),
      "base" => "insignia_flip_box",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
        "class" => "font-awesome",
	"icon" => "fa fa-repeat",
       
      "params" => array(
            
        array(
		'type' => 'attach_image',
		'heading' => __( 'Background Image', 'ensign' ),
		'param_name' => 'image',
		'value' =>'',
		'description' => __( 'Select image from media library.', 'ensign' ),
	),
	array(
		"type" => "dropdown",
		"class" => "",
		"heading" => esc_html__( "Background Image Overlay", 'ensign' ),
		"param_name" => "bg_overlay",
		"value" =>  array(
		esc_html__( "None", "ensign" ) => "none",
		esc_html__( "Dark 10%", "ensign" ) => "dark10",
		esc_html__( "Dark 20%", "ensign" ) => "dark20",
		esc_html__( "Dark 30%", "ensign" ) => "dark30",
		esc_html__( "Dark 40%", "ensign" ) => "dark40",
		esc_html__( "Dark 50%", "ensign" ) => "dark50",
		esc_html__( "Dark 60%", "ensign" ) => "dark60",
		esc_html__( "Dark 70%", "ensign" ) => "dark70",
		esc_html__( "Dark 80%", "ensign" ) => "dark80",
		esc_html__( "Dark 90%", "ensign" ) => "dark90",
		esc_html__( "Light 20%", "ensign" ) => "light20",
		esc_html__( "Light 40%", "ensign" ) => "light40",
		esc_html__( "Light 60%", "ensign" ) => "light60",
		esc_html__( "Light 80%", "ensign" ) => "light80",
	),		
                'dependency' => array(
			'element' => 'image',
			'not_empty' => true,
		),
		"description" => esc_html__( "Set a background overlay to darken or lighten the background image and improve the text visibility.", "ensign" ) 
	),
	
	array(
		'type' => 'colorpicker',
		'heading' => __( 'Custom Background Color', 'ensign' ),
		'param_name' => 'main_bg_color_custom',
		'description' => __( 'Select a custom box background color.', 'ensign' ),
		
	),
	array(
		'type' => 'textfield',
		'heading' => __( 'Primary title', 'ensign' ),
		'param_name' => 'primary_title',
		'value' => __( 'Hover Box Element', 'ensign' ),
		'description' => __( 'Enter text for heading line.', 'ensign' ),
		'edit_field_class' => 'vc_col-sm-9',
	),

       array(
		'type' => 'textarea',
		'heading' => __( 'Primary text', 'ensign' ),
		'param_name' => 'primary_content',
		'value' => __( 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'ensign' ),
		'description' => __( 'Primary part text.', 'ensign' ),
	), 
	
	array(
		'type' => 'textfield',
		'heading' => __( 'Hover title', 'ensign' ),
		'param_name' => 'hover_title',
		'value' => 'Hover Box Element',
		'description' => __( 'Hover Box Element', 'ensign' ),
		'group' => __( 'Hover Block', 'ensign' ),
		'edit_field_class' => 'vc_col-sm-9',
	),
	array(
		'type' => 'dropdown',
		'heading' => __( 'Hover title alignment', 'ensign' ),
		'param_name' => 'hover_align',
		'value' => getVcShared( 'text align' ),
		'std' => 'center',
		'group' => __( 'Hover Block', 'ensign' ),
		'description' => __( 'Select text alignment for hovered title.', 'ensign' ),
	),
	array(
		'type' => 'textarea',
		'heading' => __( 'Hover text', 'ensign' ),
		'param_name' => 'hover_content',
		'value' => __( 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'ensign' ),
		'group' => __( 'Hover Block', 'ensign' ),
		'description' => __( 'Hover part text.', 'ensign' ),
	),
	
	array(
		"type" => "dropdown",
		"class" => "",
		"heading" => esc_html__( "Front Box Color Scheme", "ensign" ),
		"param_name" => "color_scheme",
		"value" => array(
			esc_html__( "Theme Defaults", 'ensign' ) => "",
			esc_html__( "White Scheme", 'ensign' ) => "white",
			esc_html__( "Dark Scheme", 'ensign' ) => "dark"
		),
		"description" => esc_html__( "White Scheme - all text styled to white color, recommended for dark backgrounds.", "ensign" ),
		"group" => esc_html__( "Front Styling", 'ensign' )
	),
	
	
      
      array(
		"type" => "dropdown",
		"class" => "",
		"heading" => esc_html__( "Hover State Color Scheme", "ensign" ),
		"param_name" => "hover_color_scheme",
		"value" => array(
			esc_html__( "Theme Defaults", 'ensign' ) => "",
			esc_html__( "White Scheme", 'ensign' ) => "white",
			esc_html__( "Dark Scheme", 'ensign' ) => "dark"
		),
		"description" => esc_html__( "White Scheme - all text styled to white color, recommended for dark backgrounds.", "ensign" ),
		"group" => esc_html__( "Hover Styling", 'ensign' )
	),
	
	
       array(
		'type' => 'attach_image',
		'heading' => __( 'Hover Background Image', 'ensign' ),
		'param_name' => 'hover_image',
		'value' => '',
		'group' => __( 'Hover Block', 'ensign' ),

		'description' => __( 'Select image from media library.', 'ensign' ),
	),
	array(
		"type" => "dropdown",
		"class" => "",
		"heading" => esc_html__( "Hover Background Image Overlay", 'ensign' ),
		"param_name" => "hover_bg_overlay",
		"value" =>  array(
		esc_html__( "None", "ensign" ) => "none",
		esc_html__( "Dark 10%", "ensign" ) => "dark10",
		esc_html__( "Dark 20%", "ensign" ) => "dark20",
		esc_html__( "Dark 30%", "ensign" ) => "dark30",
		esc_html__( "Dark 40%", "ensign" ) => "dark40",
		esc_html__( "Dark 50%", "ensign" ) => "dark50",
		esc_html__( "Dark 60%", "ensign" ) => "dark60",
		esc_html__( "Dark 70%", "ensign" ) => "dark70",
		esc_html__( "Dark 80%", "ensign" ) => "dark80",
		esc_html__( "Dark 90%", "ensign" ) => "dark90",
		esc_html__( "Light 20%", "ensign" ) => "light20",
		esc_html__( "Light 40%", "ensign" ) => "light40",
		esc_html__( "Light 60%", "ensign" ) => "light60",
		esc_html__( "Light 80%", "ensign" ) => "light80",
	),
		'group' => __( 'Hover Block', 'ensign' ),

		'dependency' => array(
			'element' => 'hover_image',
			'not_empty' => true,
		),
		"description" => esc_html__( "Set a background overlay to darken or lighten the background image and improve the text visibility.", "ensign" ) 
	),
	
	
	
	array(
		'type' => 'colorpicker',
		'heading' => __( 'Background color', 'ensign' ),
		'param_name' => 'hover_custom_background',
		'description' => __( 'Select custom background color.', 'ensign' ),
		'group' => __( 'Hover Block', 'ensign' ),
		
		'edit_field_class' => 'vc_col-sm-6',
	),
		array(
		'type' => 'dropdown',
		'heading' => __( 'Alignment', 'ensign' ),
		'param_name' => 'align',
		'description' => __( 'Select block alignment.', 'ensign' ),
		'value' => array(
			__( 'Left', 'ensign' ) => 'text-left',
			__( 'Right', 'ensign' ) => 'text-right',
			__( 'Center', 'ensign' ) => 'text-center',
		),
		'std' => 'text-center',
	),
	array(
		"type" => "checkbox",
		"heading" => esc_html__( "Add Icon?", "ensign" ),
		"param_name" => "add_icon",
		"class" => "hidden-label",
		"value" => array(
			esc_html__( "Yes", "ensign" ) => "true",
		),
		"description" => esc_html__( "Display icon above the special heading.", "ensign" ) 
	),

      array(
	'type' => 'dropdown',
	'heading' => __( 'Icon library', 'ensign' ),
	'value' => array(      __( 'Font Awesome', 'ensign' ) => 'fontawesome',
				__( 'Open Iconic', 'ensign' ) => 'openiconic',
				__( 'Typicons', 'ensign' ) => 'typicons',
				__( 'Entypo', 'ensign' ) => 'entypo',
				__( 'Linecons', 'ensign' ) => 'linecons',
				__( 'Mono Social', 'ensign' ) => 'monosocial',
				__( 'Material', 'ensign' ) => 'material',
				__( 'Themify', 'ensign' ) => 'themify',

			),
	'param_name' => 'icon_type',

	'description' => __( 'Select icon library.', 'ensign' ),
'dependency' => array(
						'element' => 'add_icon',
						'value' => array('true')
						
                ),
	),
		
		
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_fontawesome',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
			),
			'dependency' => array(
				'element' =>'icon_type',
				'value' => 'fontawesome',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
    ),
         
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_openiconic',
	'value' => 'vc-oi vc-oi-dial',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'openiconic',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'openiconic',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
		
		
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_typicons',
	'value' => 'typcn typcn-adjust-brightness',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'typicons',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'typicons',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_entypo',
	'value' => 'entypo-icon entypo-icon-note',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'entypo',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'entypo',
			),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_linecons',
	'value' => 'vc_li vc_li-heart',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'linecons',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'linecons',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_monosocial',
	'value' => 'vc-mono vc-mono-fivehundredpx',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'monosocial',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'monosocial',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'icon_material',
	'value' => 'vc-material vc-material-cake',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'material',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => 'material',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
			'type' => 'iconpicker',
			'heading' => __( 'Icon', 'ensign' ),
			'param_name' => 'icon_themify',
                        	'value' => 'ti-wand',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				'type' => 'themify' ,
				// default true, display an "EMPTY" icon?
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
			),
			'dependency' => array(
				'element' =>'icon_type',
				'value' => 'themify',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),

		),

      array(
		"type" => "checkbox",
		"heading" => esc_html__( "Add Icon?", "ensign" ),
		"param_name" => "hover_add_icon",
		"class" => "hidden-label",
		'group' => __( 'Hover Block', 'ensign' ),

		"value" => array(
			esc_html__( "Yes", "ensign" ) => "true",
		),
		"description" => esc_html__( "Display icon above the special heading.", "ensign" ) 
	),

      array(
	'type' => 'dropdown',
	'heading' => __( 'Icon library', 'ensign' ),
		'group' => __( 'Hover Block', 'ensign' ),

	'value' => array(      __( 'Font Awesome', 'ensign' ) => 'fontawesome',
				__( 'Open Iconic', 'ensign' ) => 'openiconic',
				__( 'Typicons', 'ensign' ) => 'typicons',
				__( 'Entypo', 'ensign' ) => 'entypo',
				__( 'Linecons', 'ensign' ) => 'linecons',
				__( 'Mono Social', 'ensign' ) => 'monosocial',
				__( 'Material', 'ensign' ) => 'material',
				__( 'Themify', 'ensign' ) => 'themify',

			),
	'param_name' => 'hover_icon_type',

	'description' => __( 'Select icon library.', 'ensign' ),
'dependency' => array(
						'element' => 'hover_add_icon',
						'value' => array('true')
						
                ),
	),
		
		
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'hover_icon_fontawesome',
		'group' => __( 'Hover Block', 'ensign' ),


			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
			),
			'dependency' => array(
				'element' =>'hover_icon_type',
				'value' => 'fontawesome',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
    ),
         
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'hover_icon_openiconic',
		'group' => __( 'Hover Block', 'ensign' ),

	'value' => 'vc-oi vc-oi-dial',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'openiconic',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'hover_icon_type',
				'value' => 'openiconic',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
		
		
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'hover_icon_typicons',
		'group' => __( 'Hover Block', 'ensign' ),

	'value' => 'typcn typcn-adjust-brightness',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'typicons',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'hover_icon_type',
				'value' => 'typicons',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'hover_icon_entypo',
		'group' => __( 'Hover Block', 'ensign' ),

	'value' => 'entypo-icon entypo-icon-note',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'entypo',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'hover_icon_type',
				'value' => 'entypo',
			),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'hover_icon_linecons',
		'group' => __( 'Hover Block', 'ensign' ),

	'value' => 'vc_li vc_li-heart',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'linecons',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'hover_icon_type',
				'value' => 'linecons',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'hover_icon_monosocial',
		'group' => __( 'Hover Block', 'ensign' ),

	'value' => 'vc-mono vc-mono-fivehundredpx',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'monosocial',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'hover_icon_type',
				'value' => 'monosocial',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'ensign' ),
	'param_name' => 'hover_icon_material',
		'group' => __( 'Hover Block', 'ensign' ),

	'value' => 'vc-material vc-material-cake',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				// default true, display an "EMPTY" icon?
				'type' => 'material',
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display
			),
			'dependency' => array(
				'element' => 'hover_icon_type',
				'value' => 'material',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),
	),
array(
			'type' => 'iconpicker',
			'heading' => __( 'Icon', 'ensign' ),
		'group' => __( 'Hover Block', 'ensign' ),

			'param_name' => 'hover_icon_themify',
                        	'value' => 'ti-wand',

			// default value to backend editor admin_label
			'settings' => array(
				'emptyIcon' => false,
				'type' => 'themify' ,
				// default true, display an "EMPTY" icon?
				'iconsPerPage' => 4000,
				// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
			),
			'dependency' => array(
				'element' =>'hover_icon_type',
				'value' => 'themify',
			),
			'description' => __( 'Select icon from library.', 'ensign' ),

		),


	
		
	array(
		'type' => 'el_id',
		'heading' => __( 'Element ID', 'ensign' ),
		'param_name' => 'el_id',
		'description' => sprintf( __( 'Enter element ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'ensign' ), 'http://www.w3schools.com/tags/att_global_id.asp' ),
	),
	array(
		'type' => 'textfield',
		'heading' => __( 'Extra class name', 'ensign' ),
		'param_name' => 'el_class',
		'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'ensign' ),
	),
	array(
		'type' => 'css_editor',
		'heading' => __( 'CSS box', 'ensign' ),
		'param_name' => 'css',
		'group' => __( 'Design Options', 'ensign' ),
	),
      
   ) ));
}


add_shortcode( 'insignia_flip_box', 'insignia_flip_box_shortcode' );
function insignia_flip_box_shortcode( $atts,$content) {
$defaultFont      = 'fontawesome';
	$defaultIconClass = 'fa fa-user-o';
 extract( shortcode_atts( array(
           "image" => '',
	    "url" => '',
	     "bg_overlay" => '',
	     "main_bg_color_custom" => '',
	    "primary_title" => 'Flip Box Element',
	    "use_custom_fonts_primary_title" => '',
	    "primary_align" => 'center',
	    "primary_title_font_container" => '',
	    "hover_title" => 'Hover Title',
	    "use_custom_fonts_hover_title" => '',
	    "hover_align" => 'center',
	    "hover_title_font_container" => '',
	    "hover_custom_background" => '',
	    "align" => 'text-center',
	    "hover_add_button" => '',
	    "hover_btn_title" => 'Text on the button',
	    "el_id" => '',
	    "el_class" => '',
	    "css" => '',
	    "add_icon" => 'false',
	    'icon_type'=>  $defaultFont,
            'icon_fontawesome'=>  $defaultIconClass,
            'icon_openiconic'=> '', 
            'icon_typicons'=> '', 
            'icon_entypo'=> '', 
            'icon_linecons'=> '', 
            'icon_monosocial'=> '', 
            'icon_material'=> '',   
            'icon_themify'=> '',
            "hover_add_icon" => 'false',
	    'hover_icon_type'=>  $defaultFont,
            'hover_icon_fontawesome'=>  $defaultIconClass,
            'hover_icon_openiconic'=> '', 
            'hover_icon_typicons'=> '', 
            'hover_icon_entypo'=> '', 
            'hover_icon_linecons'=> '', 
            'hover_icon_monosocial'=> '', 
            'hover_icon_material'=> '',   
            'hover_icon_themify'=> '',
	    "color_scheme" => '',
	    "hover_color_scheme" => '',
            "hover_image" => '',
	    "hover_bg_overlay" => '',
            "primary_content" => 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
            "hover_content" => 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.'
 
    ), $atts ) );
    
    
    $image_data = $image_src = '';
	
	if ( strpos( $image, 'unsplash') !== false ) {
		$image_src = $image;
	} elseif ( $image != '' ) {
		$image = intval( $image );
		$image_data = wp_get_attachment_image_src( $image, 'large' );
		$image_src = $image_data[0];
	}
	
	$image_src = esc_url( $image_src );



 $hover_image_data = $hover_image_src = '';
	
	if ( strpos( $hover_image, 'unsplash') !== false ) {
		$hover_image_src = $hover_image;
	} elseif ( $hover_image != '' ) {
		$hover_image = intval( $hover_image );
		$hover_image_data = wp_get_attachment_image_src( $hover_image, 'large' );
		$hover_image_src = $hover_image_data[0];
	}
	
	$hover_image_src = esc_url( $hover_image_src );
	
	
	
	
	$id = '';
	if ( ! empty( $el_id ) ) {
		$id = 'id="' . esc_attr( $el_id ) . '"';
	}
	
	$class_to_filter = vc_shortcode_custom_css_class( $css, ' ' );
	
	$el_css = array();
	
	$el_css[] = vc_shortcode_custom_css_class( $css );
	
	// Icon
	
	$icon_output = $icon = '';
	
	if ( $add_icon != "false" ) {
	
		$icon = str_replace( 'fa-', '', $icon );
		vc_icon_element_fonts_enqueue( $icon_type );		
		$iconClass = isset( ${"icon_" . $icon_type} ) ? ${"icon_" . $icon_type} : $defaultIconClass;
		
		$el_css[] = 'flipbox-with-icon';
		$icon_output = '<div class="flipbox-icon"><i class="icon-medium ' . $iconClass . '"></i></div>';
		
	}

     	$hover_icon_output = $hover_icon = '';


       if ( $hover_add_icon != "false" ) {
	
		$hover_icon = str_replace( 'fa-', '', $hover_icon );
		vc_icon_element_fonts_enqueue( $hover_icon_type );		
		$hover_iconClass = isset( ${"icon_" . $hover_icon_type} ) ? ${"icon_" . $hover_icon_type} : $defaultIconClass;
		
		$el_css[] = 'flipbox-with-icon';
		$hover_icon_output = '<div class="flipbox-icon-hover"><i class="icon-medium ' . $hover_iconClass . '"></i></div>';
		
	}
	
	// Front Background
	
	$front_bg = false;
	
	$front_box_css = $front_box_inline_css = '';
	
	
	
		$front_box_inline_css .= 'background-color:' . $main_bg_color_custom . ';';
		$front_bg = true;
	
	
	if ( $image_src != '' ) {
		$front_bg = true;
		$front_box_inline_css .= 'background-image: url(' . $image_src . ');';
		if ( $bg_overlay != '' ) $front_box_css .= ' bg-overlay bg-overlay-' . $bg_overlay;
	}
	
	if ( $front_bg == true && $color_scheme == '' ) $front_box_css .= ' color-scheme-white no-border';
	
	if ( $color_scheme != '' ) $front_box_css .= ' color-scheme-' . $color_scheme;
	
	// Hover Background color
	
	$hover_bg = false;
	$hover_box_inline_css = $hover_box_css = '';
		$hover_box_inline_css .= 'background-color:' . $hover_custom_background . ';';
		$hover_bg = true;
	
	 

	if ( $hover_bg == true && $hover_color_scheme == '' ) $hover_box_css .= ' color-scheme-white no-border';
	if ( $hover_color_scheme != '' ) $hover_box_css .= ' color-scheme-' . $hover_color_scheme;

       if ( $hover_image_src != '' ) {
		$hover_bg = true;
		$hover_box_inline_css .= 'background-image: url(' . $hover_image_src . ');';
		if ( $hover_bg_overlay != '' ) $hover_box_css .= ' hover-bg-overlay hover-bg-overlay-' . $hover_bg_overlay;
	}
	

	// Titles
	
	$primary_title = '<h5 class="flipbox-front-title padding-10px-bottom">' . $primary_title . '</h5>';
	$hover_title = '<h5 class="flipbox-hover-title padding-10px-bottom">' . $hover_title . '</h5>';
	//$hover_title = $this->getHeading( 'hover_title', $atts, $atts['hover_align'] );
	
	
	$button = '';
	
	if ( $hover_add_button ) {
		$button = $this->renderButton( $atts );
	}
	
	$template = '<div class="ins-flipbox vc-hoverbox-wrapper vc-hoverbox-direction--default ' . implode( ' ', $el_css ) . '  " ' . $id . '>
	  <div class="vc-hoverbox">
	    <div class="vc-hoverbox-inner ' . $align . '">
	      <div class="ins-flipbox-front vc-hoverbox-block vc-hoverbox-front' . $front_box_css . '" style="' . $front_box_inline_css . '">
	        <div class="vc-hoverbox-block-inner vc-hoverbox-front-inner">';
	
	if ( $icon_output != '' ) $template .= $icon_output;
	$template .= $primary_title ;
        	$template .= $primary_content . '
            
                 </div>
	      </div>
	      <div class="ensign-flipbox-hover vc-hoverbox-block vc-hoverbox-back ' . $hover_box_css . '" style="' . $hover_box_inline_css . '">
	        <div class="vc-hoverbox-block-inner vc-hoverbox-back-inner">
                    '. $hover_icon_output .'
	            ' . $hover_title . '
	            ' . $hover_content . '
	            ' . $button . '
	        </div>
	      </div>
	    </div>
	  </div>
	</div>';
	
	return $template;
    
    
    

}