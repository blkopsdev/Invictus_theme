<?php
/**
 *
 * News & Blog VC element by INSIGNIA
 *
 */



/*News & Blog*/

add_action( 'vc_before_init', 'insignia_blog' );

function insignia_blog() {
 $terms = get_terms('category', array('hide_empty' => false));
    $categories = array();
    foreach ($terms as $term) {
        $categories[$term->name] = $term->name;
    }

  vc_map (

 array(
      "name" => __( "News & Blog", "ensign" ),
      "base" => "blog_news",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
       "class" => "font-awesome",
	"icon" => "fa fa-file-text",
       
      
      "params" => array(
          array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "group" => "General",
            "heading" => __( "Blog/News Layout", "ensign" ),
            "param_name" => "blog_layout",
             "admin_label" => true,
            "value"       => array(
	'Select Layout'   => 'Grid',       
	'Grid 2 Columns'   => 'Grid2',
	'Grid 3 Columns'   => 'Grid3',
	'Grid 4 Columns' => 'Grid4',
	'Masonry 2 Columns'  => 'Masonry2',
	'Masonry 3 Columns'  => 'Masonry3',
	'Masonry 4 Columns'  => 'Masonry4',
        'Blog Carousel' => 'Carousel'
      ),
      ),



          array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "group" => "General",
            "heading" => __( "Select Blog/News Style", "ensign" ),
            "param_name" => "blog_style",
            "value"       => array(
	'Select Style'   => 'layout_0',       
	'Style 1'   => 'layout_1',
	'Style 2'   => 'layout_2',
	'Style 3' => 'layout_3',
	'Style 4'  => 'layout_4',
	'Style 5'  => 'layout_5',
	'Style 6'  => 'layout_6'
      ),
      'dependency' => array(
				'element' => 'blog_layout',
				'value' => array('Grid','Grid2','Grid3','Grid4','Carousel')
						
                ),
      ),

        
          array(
            "type" => "checkbox",
            "class" => "",
            "edit_field_class" => "vc_col-xs-12 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Select Category", "ensign" ),
            "param_name" => "post_cat",
            "group" => "General",
	'save_always' => true,
            "value"       => $categories,
     
            "description" => __( "Select Categories. You can choose multiple categories", "ensign" )
            

      ),
          
  array(
            "type" => "textfield",
            "class" => "",
      "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Number of Posts to display.", "ensign" ),
            "param_name" => "blog_no_posts",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "admin_label" => true,            
              "description" => __( "You can choose limited number of posts to display on page.", "ensign" )
            
         ),
          
          array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "group" => "General",
            "heading" => __( "Load More Options", "ensign" ),
            "param_name" => "blog_load_more",
            "value"       => array(
       
        'None'   => 'none',
        'Ajax Load more'   => 'ajax_button',
        'Infinite Scroll' => 'infinite',
        'Numeric Pagination'  => 'pagination'
        
        
      ),
      'dependency' => array(
						'element' => 'blog_layout',
						'value' => array('Grid','Grid2','Grid3','Grid4','Masonry2','Masonry3','Masonry4','Default')
						
                ),
      


   ) ,

          array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "group" => "General",
            "heading" => __( "Appear Effects", "ensign" ),
            "param_name" => "post_appear_effects",
            "value"       => array(
	'Select Effect'   => 'default',       
	'Fade Up'   => 'fade-up',
	'Fade Down'   => 'fade-down',
	'Fade Right' => 'fade-right',
	'Fade Left'  => 'fade-left',
	'Zoom In'  => 'zoom-in',
	'Zoom Out'  => 'zoom-out',
	'Flip Up'  => 'flip-up',
	'Flip Down'  => 'flip-down'
      ),
      ),

  array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Gap", "ensign" ),
            "param_name" => "blog_gap",
            "group" => "General",
            "value" => __( "", "ensign" ),
            "description" => __( "Select gap between grid columns(in pixels).Enter Number only, do not add 'px'.", "ensign" )
            
         ),



      array(
            "type" => "textfield",
            "class" => "",
      
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
              "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
            
         ),
             

   
   array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Autoplay", "ensign" ),
            "param_name" => "blog_autoplay",
            "group" => "Carousel setting",
            "value"       => array(
        
        'True'   => 'true',
        'False'   => 'false'
        
      ),
      "std"         => 'True',
        
            "description" => __( "Enable/Disable Autoplay.", "ensign" ),
             'dependency' => array(
						'element' => 'blog_layout',
						'value' => array('Carousel')
						
                ),
            
         ),
            array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Speed", "ensign" ),
            "param_name" => "blog_speed",
            "group" => "Carousel setting",
            "value" => __( "3000", "ensign" ),
            "description" => __( "Choose speed for carousel transition in milliseconds (Example:300).", "ensign" ),
            'dependency' => array(
						'element' => 'blog_layout',
						'value' => array('Carousel')
						
                ),
            
         ),
        array(
            "type" => "textfield",
            "class" => "",
          "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesToShow", "ensign" ),
            "param_name" => "blog_slidetoshow",
            "group" => "Carousel setting",
            "value" => __( "1", "ensign" ),
    
            "description" => __( "No. of Testimonials you need to display at a time (Example:3).", "ensign" ),
            'dependency' => array(
						'element' => 'blog_layout',
						'value' => array('Carousel')
						
                ),
            
         ),
     array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesToScroll", "ensign" ),
            "param_name" => "blog_slidetoscroll",
            "group" => "Carousel setting",
            "value" => __( "1", "ensign" ),
      
            "description" => __( "No. of Testimonials you need to scroll at a time (Example:1).", "ensign" ),
            'dependency' => array(
						'element' => 'blog_layout',
						'value' => array('Carousel')
						
                ),
            
         ),
        array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Dots", "ensign" ),
            "param_name" => "blog_navigation_dots",
            "group" => "Carousel setting",
            "value"       => array(
       
        'True'   => 'true',
        'False'   => 'false'
        
      ),
      "std"         => '',
            "description" => __( "Dots for navigation.", "ensign" ),
            'dependency' => array(
						'element' => 'blog_layout',
						'value' => array('Carousel')
						
                ),
            
         ),
    array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Arrows", "ensign" ),
            "param_name" => "blog_navigation_arrows",
            "group" => "Carousel setting",
            "value"       => array(
        
           'True'   => 'true',
        'False'   => 'false'
        
      ),
      "std"         => '',
            "description" => __( "Arrows for navigation.", "ensign" ),
            'dependency' => array(
						'element' => 'blog_layout',
						'value' => array('Carousel')
						
                ),
            
         ),
    array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "rows", "ensign" ),
            "param_name" => "blog_rows",
            "group" => "Carousel setting",
           
      
            "description" => __( "No. of Rows (Example:2)", "ensign" ),
            'dependency' => array(
						'element' => 'blog_layout',
						'value' => array('Carousel')
						
                ),
            
         ),
     array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesPerRow", "ensign" ),
            "param_name" => "blog_slidesperrow",
            "group" => "Carousel setting",
            "value" => __( "", "ensign" ),
      
            "description" => __( "No. of slidesPerRow (Example:2)", "ensign" ),
            'dependency' => array(
						'element' => 'blog_layout',
						'value' => array('Carousel')
						
                ),
            
         ),
    array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "infinite", "ensign" ),
            "param_name" => "blog_infinite",
            "group" => "Carousel setting",
            "value"       => array(
      
        'True'   => 'true',
        'False'   => 'false'
        
      ),
            "std"         => '',
      
            "description" => __( "Infinite loop sliding.", "ensign" ),
            'dependency' => array(
						'element' => 'blog_layout',
						'value' => array('Carousel')
						
                ),
            
         ),
        array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        ),
   
   )));
}



add_shortcode( 'blog_news', 'blog_news' );


function blog_news( $atts ) {
$css = '';
extract( shortcode_atts( array(
	'blog_layout' => '',
	'blog_style' => '',
	'blog_gap' => '',
	'post_appear_effects' => '',
	'blog_no_posts' => '',
	'post_cat' => '',
	'blog_load_more' => '',
	'fieldName' => '',
	'blog_navigation_arrows' => '',
	'blog_navigation_dots' => '',
	'blog_slidetoscroll' => '',
	'blog_slidetoshow' => '',
	'blog_speed' => '',
	'blog_autoplay' => '',
	'blog_rows' => '',
	'blog_slidesperrow' => '',
	'blog_infinite' => '',
         'css' => '',
        'extra_class' => ''

   ), $atts ) );




global $post, $blog_no_posts1, $blog_out, $blog_style1, $post_cat1, $post_appear_effects1, $blog_load_more1, $blog_auto1, $blog_speed1, $blog_slidetoshow1, $blog_slidetoscroll1, $blog_dots, $blog_arrows, $blog_rows1, $blog_slidesperrow1, $blog_infinite1, $css1, $blog_extra_class1, $blog_gap1;

	$blog_out = ${'blog_layout'};
	$blog_style1 = ${'blog_style'};
	$blog_no_posts1 = ${'blog_no_posts'}; 
	$post_cat1 = ${'post_cat'};
	$post_appear_effects1 = ${'post_appear_effects'};
	$blog_load_more1 = ${'blog_load_more'};
	$blog_auto1= ${'blog_autoplay'};
	$blog_speed1= ${'blog_speed'};
	$blog_slidetoshow1= ${'blog_slidetoshow'};
	$blog_slidetoscroll1= ${'blog_slidetoscroll'};
	$blog_dots=${'blog_navigation_dots'};
	$blog_arrows=${'blog_navigation_arrows'};
	$blog_rows1= ${'blog_rows'};
	$blog_slidesperrow1 = ${'blog_slidesperrow'};
	$blog_infinite1= ${'blog_infinite'};
	$blog_gap1= ${'blog_gap'};
        $blog_extra_class1=${'extra_class'};

        $css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );

      if(!isset($blog_extra_class1)){
      $blog_extra_class1=''; }

      if(empty($blog_no_posts1)){
      $blog_no_posts1=''; }


$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
 
//$select_cat = explode(',', $post_cat1);



if(empty($blog_gap1)){
$blog_gap1 = '0';
}
if(empty($post_cat1)){
$args = array(
	'post_type' => 'post',
	'posts_per_page' => $blog_no_posts1,
        'paged' => $paged
	); 
} else{
$args = array(
	'post_type' => 'post',
	'posts_per_page' => $blog_no_posts1,
	'category_name' => $post_cat1,
        'paged' => $paged
	);
}
$lmb = array(
	'post_type' => 'post',
	'category_name' => $post_cat1,
        'paged' => $paged
	);

		$posts = new WP_Query($args);
		$post_count = new WP_Query($lmb);

if ( $posts->have_posts() || $post_count->have_posts() )  {
if($blog_out == "Grid2" || $blog_out == "Grid3" || $blog_out == "Grid4")
{
	ob_start();
	include(locate_template('blog/archive/blog-grid-main.php'));
	$return_html = trim(preg_replace('/\s\s+/', ' ', ob_get_clean()));
	return $return_html;
}

elseif($blog_out == "Masonry2" || $blog_out == "Masonry3" || $blog_out == "Masonry4")  {
	ob_start();
	include(locate_template('blog/archive/blog-masonry-main.php'));
	$return_html = trim(preg_replace('/\s\s+/', ' ', ob_get_clean()));
	return $return_html;
}

elseif($blog_out == "Carousel"){

        ob_start();
	include(locate_template('blog/archive/blog-carousel.php'));
	$return_html = trim(preg_replace('/\s\s+/', ' ', ob_get_clean()));
	return $return_html;

}
else{
	ob_start();
	include(locate_template('blog/archive/blog-masonry-main.php'));
	$return_html = trim(preg_replace('/\s\s+/', ' ', ob_get_clean()));
	return $return_html;
}
}else{
	echo "<p class='insignia-error-text text-center'>No Post found.</p>";
}
}



