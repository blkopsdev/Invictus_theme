<?php
/**
 *
 * Image Gallery VC element by INSIGNIA
 *
 */



/*Carousel Gallery Element*/


add_action( 'vc_before_init', 'VC_image_gallery' );

function VC_image_gallery() {
  vc_map (

 array(
      "name" => __( "Image Gallery", "ensign" ),
      "base" => "insignia_image_gallery",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
      "class" => "font-awesome",
      "icon" => "fa fa-picture-o",
       
      "params" => array(
      
      array(
            "type" => "dropdown",
            "class" => "",
            "heading" => __( "Select Design Style", "ensign" ),
            "param_name" => "design_style",
            "group" => "General",
              "description" => __( "Select Carousel Gallery design you would like to use", "ensign" ),
             "value"       => array(
       
        'Grid 2 columns'   => 'grid_2x',
        'Grid 3 columns'   => 'grid_3x',
        'Grid 4 columns'   => 'grid_4x',
        'Masonry 2 columns'   => 'masonry_2x',
        'Masonry 3 columns'   => 'masonry_3x',
        'Masonry 4 columns'   => 'masonry_4x',
        'Carousel Gallery '   => 'carousel'         

         ),
      "std"         => '',
            
         ),
     array(
            "type" => "attach_images",
            "class" => "",
            "heading" => __( "Select Multiple Images", "insignia" ),
            "param_name" => "attach_images",
            "group" => "General",
            "value" => __( "", "insignia" )
            
         ),
     array(
                  "type"        => "checkbox",
                  "param_name" => "hover_text",
                  "class" => "",
                   "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
                    "group" => "General",
                     'save_always' => true,
                    "value"         => array('Show Caption on Hover'   => '1' ),
                    
                    
						
                ),

  array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Gap", "ensign" ),
            "param_name" => "gallery_gap",
            "group" => "General",
            "value" => __( "", "ensign" ),
            "description" => __( "Select gap between grid columns(in pixels).Enter Number only, do not add 'px'.", "ensign" )
            
         ),

   array(
            "type" => "textfield",
            "class" => "",
      
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
              "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
            
         ),
         


array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Speed", "ensign" ),
            "param_name" => "carousel_speed",
            "group" => "Carousel setting",
            "value" => __( "3000", "ensign" ),
      
            "description" => __( "Choose speed for carousel transition in milliseconds (Example:300).", "ensign" )
            
         ),
array(
            "type" => "textfield",
            "class" => "",
          "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesToShow", "ensign" ),
            "param_name" => "imgs_slidetoshow",
            "group" => "Carousel setting",
            "value" => __( "1", "ensign" ),
    
            "description" => __( "No. of Images you need to display at a time (Example:3).", "ensign" )
            
         ),
array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "slidesToScroll", "ensign" ),
            "param_name" => "imgs_slidetoscroll",
            "group" => "Carousel setting",
            "value" => __( "1", "ensign" ),
      
            "description" => __( "No. of Images you need to scroll at a time (Example:1).", "ensign" )
            
         ),

array(
            "type" => "dropdown",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "infinite", "ensign" ),
            "param_name" => "carousel_infinite",
            "group" => "Carousel setting",
            "value"       => array(
      
        'True'   => 'true',
        'False'   => 'false'
        
      ),
            "std"         => '',
      
            "description" => __( "Infinite loop sliding.", "ensign" )
            
         ),

        array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'ensign' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'ensign' ),
        ),


       
      

  ) ));
}


add_shortcode( 'insignia_image_gallery', 'insignia_image_gallery_shortcode' );
function insignia_image_gallery_shortcode( $atts,$content) {
 extract( shortcode_atts( array(
      
     'design_style' => '',
     'attach_images' => '',
      'extra_class' => '',
      'carousel_speed' => '',
      'imgs_slidetoshow' => '',
      'imgs_slidetoscroll' => '',
      'gallery_gap' => '30',
      'carousel_infinite' => '',
      'title' => '',
      'css' => '',
      'hover_text' => ''


   ), $atts ) );


global $design_style1, $multiple_imgs1, $extra_class1, $gallery_gap1, $carousel_speed1, $imgs_slidetoshow1, $imgs_slidetoscroll1, $carousel_infinite1, $post, $hover_text1; 

$design_style1= ${'design_style'};
$extra_class1= ${'extra_class'};
$hover_text1= ${'hover_text'};
$gallery_gap1= ${'gallery_gap'};
$carousel_speed1= ${'carousel_speed'};
$imgs_slidetoshow1= ${'imgs_slidetoshow'};
$imgs_slidetoscroll1= ${'imgs_slidetoscroll'};
$carousel_infinite1= ${'carousel_infinite'};

$css1=apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );


$attach_images1= $atts['attach_images'];
$attach_images1= explode( ',', $attach_images1);


if($design_style1 == "carousel")
{

$return="<div class='".$extra_class1." ".$css1." inv-carousel-gallery inv-gallery-element-main-wrapper inv-popup-gallery'>";

$return.="<div class='inv-carousel-imgs-inner'>";


foreach ($attach_images1 as $id) {
$attachment_caption = get_the_excerpt($id);

   $return.="<div class='inv-gallery-main' style='padding: 0 ".$gallery_gap1/2 ."px;'>";
   $return.="<div class='inv-gallery-imgs inv-default-img-hover-wrapper'>";
$return.="<a href='".wp_get_attachment_image_url($id,'full')."' class='inv-popup-gallery'>";
$return.= wp_get_attachment_image($id,'full');
$return.="</a>";
if(!empty($hover_text1)){
if(!empty($attachment_caption)){
$return.="<div class='inv-gallery-imgs-content-inner'>";
$return.="<h4 class='inv-gallery-imgs-title'>";
$return.=$attachment_caption;
$return.="</h4>";
$return.="</div>";
}
}

$return.="</div>";


$return.="</div>";

}
$return.="</div>";


$return.="</div>";
    return $return;
    

}elseif($design_style1 == "grid_2x" || $design_style1 == "grid_3x" || $design_style1 == "grid_4x"){

if($design_style1 == "grid_2x"){
	$column_class = 'col-md-6 col-lg-6 col-sm-6 col-xs-12';
}elseif($design_style1 == "grid_3x"){
	$column_class = 'col-md-4 col-lg-4 col-sm-4 col-xs-12';
}elseif($design_style1 == "grid_4x"){
	$column_class = 'col-md-3 col-lg-3 col-sm-3 col-xs-12';
}

$return="<div class='".$extra_class1." ".$css1." inv-gallery-element-main-wrapper' style='margin: 0 -".$gallery_gap1/2 ."px;'>";

$return.="<div class='inv-grid-imgs-inner clearfix' style='margin: 0 -".$gallery_gap1/2 ."px;'>";


foreach ($attach_images1 as $id) {

$attachment_caption = get_the_excerpt($id);

   $return.="<div class='inv-gallery-main no-padding ".$column_class."'>";
    $return.="<div class='inv-gallery-grid-gap-wrapper' style='margin: 0 ".$gallery_gap1/2 ."px; margin-bottom:".$gallery_gap1."px;'>";
   $return.="<div class='inv-gallery-imgs inv-gallery-grid-imgs  inv-grid-img-hover-wrapper' style='background-image:url(".wp_get_attachment_image_url($id,'full').")'>";
$return.="<a href='".wp_get_attachment_image_url($id,'full')."' class='inv-grid-gallery-link inv-popup-gallery'>";
$return.="</a>";
$return.="</div>";

if(!empty($hover_text1)){
if(!empty($attachment_caption)){
$return.="<div class='inv-gallery-imgs-content-inner'>";
$return.="<h4 class='inv-gallery-imgs-title'>";
$return.=$attachment_caption;
$return.="</h4>";
$return.="</div>";
}
}

$return.="</div>";
$return.="</div>";

}
$return.="</div>";


$return.="</div>";
    return $return;


}elseif($design_style1 == "masonry_2x" || $design_style1 == "masonry_3x" || $design_style1 == "masonry_4x"){

if($design_style1 == "masonry_2x"){
	$column_class = 'col-md-6 col-sm-6 col-xs-12';
}elseif($design_style1 == "masonry_3x"){
	$column_class = 'col-md-4 col-sm-4 col-xs-12';
}elseif($design_style1 == "masonry_4x"){
	$column_class = 'col-md-3 col-sm-3 col-xs-12';
}
 
$return="<div class='".$extra_class1." ".$css1." inv-gallery-element-main-wrapper inv-popup-gallery' style='margin: 0 -".$gallery_gap1/2 ."px;'>";

$return.="<div class='inv-grid-imgs-inner clearfix' id='ms-container' style='margin: 0 -".$gallery_gap1/2 ."px;'>";

foreach ($attach_images1 as $id) {

$attachment_caption = get_the_excerpt($id);

   $return.="<div class='inv-gallery-main inv-gallery-masonry-item-holder ".$column_class." ms-item' style='padding: 0 ".$gallery_gap1/2 ."px; margin-bottom:".$gallery_gap1."px;'>";
   $return.="<div class='inv-gallery-imgs  inv-default-img-hover-wrapper'>";
$return.="<a href='".wp_get_attachment_image_url($id,'full')."' class='inv-popup-gallery'>";
$return.= wp_get_attachment_image($id,'full');
$return.="</a>";
if(!empty($hover_text1)){
if(!empty($attachment_caption)){
$return.="<div class='inv-gallery-imgs-content-inner'>";
$return.="<h4 class='inv-gallery-imgs-title'>";
$return.=$attachment_caption;
$return.="</h4>";
$return.="</div>";
}
}
$return.="</div>";



$return.="</div>";

}
$return.="</div>";


$return.="</div>";
    return $return;


}
}