<?php
/**
 *
 * Button VC element by INSIGNIA
 *
 */



/*Button Element*/


add_action( 'vc_before_init', 'VC_button' );

function VC_button() {
  vc_map (

 array(
      "name" => __( "Buttons", "ensign" ),
      "base" => "insignia_button",
      "class" => "",
      "category" => __( "Insignia", "ensign"),
	"class" => "font-awesome",
	"icon" => "fa fa-square-o",        
       
      "params" => array(
      
      array(
            "type" => "dropdown",
            "class" => "",
            "heading" => __( "Select Button Style", "ensign" ),
            "param_name" => "button_style",
            "group" => "General",
              "description" => __( "Select Button Style you would like to use", "ensign" ),
             "value"       => array(
       
        'Style 1'   => 'first',
         'Style 2'   => 'second',
          'Style 3'   => 'three',
          'Style 4'   => 'four',
          'Style 5'   => 'five',
          'Style 6'   => 'six',
          'Style 7'   => 'seven'


        
         ),
      "std"         => '',
            
         ),
          array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Button Text", "ensign" ),
            "param_name" => "btn_text",
            "group" => "General",
            "value" => __( "", "ensign" )
           
            ),
             array(
            "type" => "vc_link",
            "holder" => "div",
            "class" => "",
             
            "heading" => __( "Button Link (url)", "ensign" ),
            "param_name" => "btn_link",
            "group" => "General",
            "value" => __( "", "ensign" )
           
            ),
            
             array(
            "type" => "dropdown",
            "class" => "",
            "heading" => __( "Select Button Size", "ensign" ),
            "param_name" => "button_size",
            "group" => "General",
              "description" => __( "Select Button Size you would like to use", "ensign" ),
             "value"       => array(
       
       'Select Size' => '',
        'Small'   => 'small',
         'Medium'   => 'medium',
          'Large'   => 'large'
        
         ),
      "std"         => '',
            
         ),
        
          array(
            "type" => "dropdown",
            "class" => "",
            "heading" => __( "Button Alignment", "ensign" ),
            "param_name" => "button_align",
            "group" => "General",
             "value"       => array(
       
       'Select Size' => '',
        'Left'   => 'text-left',
         'Center'   => 'text-center',
          'Right'   => 'text-right'
        
         ),
      "std"         => '',
            
         ),
            
            
     
         
         array(
            "type" => "textfield",
            "class" => "",
             
            "heading" => __( "Extra Class Name", "ensign" ),
            "param_name" => "extra_class",
            "group" => "General",
            "value" => __( "", "ensign" ),
             "description" => __( "Style particular content element differently - add a class name and refer to it in custom CSS.", "ensign" )
            
         ),
         
           array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Text Color", "ensign" ),
            "param_name" => "text_color",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Text Color.If you leave it empty, It will set default color", "ensign" )
           
             ),
                    array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Hover Text Color", "ensign" ),
            "param_name" => "hover_text_color",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Hover Text Color.If you leave it empty, It will set default color", "ensign" )
           
             ),
             
             
             array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Background Color", "ensign" ),
            "param_name" => "bg_color",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Background Color.If you leave it empty, It will set default color", "ensign" )
           
             ),
             
                array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Hover Background Color", "ensign" ),
            "param_name" => "hover_bg_color",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Hover Background Color.If you leave it empty, It will set default color", "ensign" )
           
             ),
             
             array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Border Color", "ensign" ),
            "param_name" => "border_color",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Background Color.If you leave it empty, It will set default color", "ensign" )
           
             ),
             

             
         
             
          
             
             array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Hover Border Color", "ensign" ),
            "param_name" => "hover_border_color",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Hover Border Color.If you leave it empty, It will set default color", "ensign" )
           
             ),
             
             
                           array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Border Width", "ensign" ),
            "param_name" => "border_width",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Enter Border Width (Example:2px)", "ensign" )
           
             ),
             
               array(
            "type" => "textfield",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Border Radius", "ensign" ),
            "param_name" => "border_radius",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Enter Border Radius (Example:10px)", "ensign" ),

              'dependency' => array(
						'element' => 'button_style',
						'value' => array('first', 'second', 'three','four' )
						
                ),
           
             ),
                
         
             array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Arrow Color", "ensign" ),
            "param_name" => "arrow_color",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Arrow Color.If you leave it empty, It will set default color", "ensign" ),
          
            
              'dependency' => array(
						'element' => 'button_style',
						'value' => array('seven' )
						
                ),
           
             ),
    
                  array(
            "type" => "colorpicker",
            "class" => "",
            "edit_field_class" => "vc_col-xs-6 vc_edit_form_elements vc_column-with-padding vc_column",
            "heading" => __( "Arrow Background Color", "ensign" ),
            "param_name" => "arrow_bg_color",
            "group" => "Style",
            "value" => __( "", "ensign" ),
              "description" => __( " Choose Arrow Background Color.If you leave it empty, It will set default color", "ensign" ),

               'dependency' => array(
						'element' => 'button_style',
						'value' => array('seven' )
						
                ),
           
             )


   ) ));
}

add_shortcode( 'insignia_button', 'insignia_button_shortcode' );
function insignia_button_shortcode( $atts,$content) {
 extract( shortcode_atts( array(
      
     'button_style' => '',
     'btn_text' => '',
     'btn_link' => '',
     'extra_class'=>'',
     'button_size' => '',
     'text_color' => '',
     'bg_color' => '',
     'border_color' => '',
     'border_width' => '',
     'border_radius' => '',
     'hover_text_color' => '',
     'hover_bg_color' => '',
     'hover_border_color' => '',
     'arrow_color' => '',
     'arrow_bg_color' => '',
     'button_align' => '',
     'css' =>''

     
     
                                
   ), $atts ) );


global $button_style1,$extra_class1,$btn_text1,$btn_link1,$button_size1,$text_color1,$bg_color1,$border_color1,$border_width1,$border_radius1,$hover_text_color1,$hover_bg_color1,$hover_border_color1,$arrow_color1,$arrow_bg_color1,$arrow_hover_color1,$arrow_hover_bg_color1,$button_align1;

$button_style1= ${'button_style'};
$extra_class1=${'extra_class'};
$btn_text1=${'btn_text'};
$btn_link1=${'btn_link'};
$button_size1=${'button_size'};
$text_color1=${'text_color'};
$bg_color1=${'bg_color'};
$border_color1=${'border_color'};
$border_width1=${'border_width'};
$border_radius1=${'border_radius'};
$hover_text_color1=${'hover_text_color'};
$hover_bg_color1=${'hover_bg_color'};
$hover_border_color1=${'hover_border_color'};
$arrow_color1=${'arrow_color'};
$arrow_bg_color1=${'arrow_bg_color'};
$button_align1=${'button_align'};



$btn_link1= vc_build_link($btn_link1);





  if($button_size1== "small"){
       $button_size_class= 'inv-button-small';
       }
    elseif($button_size1== "large"){ 
       $button_size_class= 'inv-button-large';
       }
       else{
              $button_size_class= 'inv-button-medium';
       }


$uniqid = uniqid('inv-button-');
$css_rules = '';
if($text_color1 != '')
$css_rules .= '#' . $uniqid . ' .inv-button-content, #' . $uniqid . ' .inv-button-4-icon, #' . $uniqid . ' span.inv-button-6-text {color: '.$text_color1.';}';


if($bg_color1 != '')
$css_rules .= '#' . $uniqid . ' .inv-button-content, #' . $uniqid . ' .inv-button-5-content:after, #' . $uniqid . ' span.inv-button-6-text, #' . $uniqid . ' .inv-button-7-content:before {background-color: '.$bg_color1.';}';


if($border_color1!= '')
$css_rules .= '#' . $uniqid . ' .inv-button-content, #' . $uniqid . ' span.inv-button-6-text, #' . $uniqid . ' .inv-button-6-content:before {border-color: '.$border_color1.';}';

if($border_width1!= '')
$css_rules .= '#' . $uniqid . ' .inv-button-content, #' . $uniqid . ' span.inv-button-6-text, #' . $uniqid . ' .inv-button-6-content:before {border-width: '.$border_width1.';}';

if($border_radius1!= '')
$css_rules .= '#' . $uniqid . ' .inv-button-content {border-radius: '.$border_radius1.';}';

if($hover_text_color1!= '')
$css_rules .= '#' . $uniqid . ' .inv-button-content:hover, #' . $uniqid . '.inv-button-4-inner:hover .inv-button-4-icon, #' . $uniqid . '.inv-button-5-content:hover .inv-button-5-text,  #' . $uniqid . ' .inv-button-6-content:hover span.inv-button-6-text, #' . $uniqid . '.inv-button-4-content:hover .inv-button-4-icon {color: '.$hover_text_color1.';}';

if($hover_bg_color1!= '')
$css_rules .= '#' . $uniqid . ' .inv-button-content:hover, #' . $uniqid . ' .inv-button-5-content:hover::after, #' . $uniqid . 'inv-button-6-content:hover span.inv-button-6-text, #' . $uniqid . ' .inv-button-7-content:hover::before, #' . $uniqid . ' .inv-button-7-content:hover::before {background-color: '.$hover_bg_color1.';}';

if($hover_border_color1!= '')
$css_rules .= '#' . $uniqid . ' .inv-button-content:hover,  #' . $uniqid . 'inv-button-6-content:hover span.inv-button-6-text,  #' . $uniqid . 'inv-button-6-content:hover::before {border-color: '.$hover_border_color1.';}';

if($arrow_color1!= '')
$css_rules .= '#' . $uniqid . ' .inv-button-7-content:after {color: '.$arrow_color1.';}';

if($arrow_bg_color1!= '')
$css_rules .= '#' . $uniqid . ' .inv-button-7-content:after {background-color: '.$arrow_bg_color1.';}';


if($button_style1== "first")
{
 
$return="<div id='".$uniqid."' class='inv-button-wrapper inv-button-1-wrapper ".$button_align1." ".$button_size_class." ".$extra_class1."'>";
$return.="<div class='inv-button-inner inv-button-1-inner'>";
$return.="<a class='inv-button-content inv-button-1-content' href='".$btn_link1['url']."' target='".$btn_link1['target']."'>".$btn_text1."</a>";
$return.="</div>";
$return.="</div>";
$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';

return $return;


}



elseif($button_style1== "second")
{

$return="<div id='".$uniqid."' class='inv-button-wrapper inv-button-2-wrapper ".$button_align1." ".$button_size_class." ".$extra_class1."'>";
$return.="<div class='inv-button-inner inv-button-2-inner'>";
$return.="<a class='inv-button-content inv-button-2-content' href='".$btn_link1['url']."' target='".$btn_link1['target']."'>";
$return.="<span class='inv-button-2-text'>";
$return.=$btn_text1;
$return.="</span>";
$return.="</a>";
$return.="</div>";
$return.="</div>";
$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';
return $return;

}

elseif($button_style1== "three")
{

$return="<div id='".$uniqid."' class='inv-button-wrapper inv-button-3-wrapper ".$button_align1." ".$button_size_class." ".$extra_class1."'>";
$return.="<div class='inv-button-inner inv-button-3-inner'>";
$return.="<a class='inv-button-content inv-button-3-content' href='".$btn_link1['url']."' target='".$btn_link1['target']."'>".$btn_text1."</a>";
$return.="</div>";
$return.="</div>";

$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';

return $return;

}

elseif($button_style1== "four")
{

$return="<div id='".$uniqid."' class='inv-button-wrapper inv-button-4-wrapper ".$button_size_class." ".$button_align1." ".$extra_class1."'>";
$return.="<div class='inv-button-inner inv-button-4-inner'>";
$return.="<a class='inv-button-content inv-button-4-content' href='".$btn_link1['url']."' target='".$btn_link1['target']."'>";
$return.=$btn_text1;
$return.="<i class='inv-button-4-icon fa fa-angle-right' aria-hidden='true'><!--icon--></i>";
$return.="</a>";

$return.="</div>";
$return.="</div>";


$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';

return $return;


}


elseif($button_style1== "five")
{

$return="<div id='".$uniqid."' class='inv-button-wrapper inv-button-5-wrapper ".$button_size_class." ".$button_align1." ".$extra_class1."'>";
$return.="<div class='inv-button-inner inv-button-5-inner'>";
$return.="<a class='inv-button-content inv-button-5-content' href='".$btn_link1['url']."' target='".$btn_link1['target']."'>";
$return.="<span class='inv-button-5-text'>";
$return.=$btn_text1;
$return.="</span>";
$return.="</a>";
$return.="</div>";
$return.="</div>";

$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';


return $return;

}

elseif($button_style1== "six")
{

$return="<div id='".$uniqid."' class='inv-button-wrapper inv-button-6-wrapper ".$button_size_class." ".$button_align1." ".$extra_class1."'>";
$return.="<div class='inv-button-inner inv-button-6-inner'>";
$return.="<a class='inv-button-content inv-button-6-content' href='".$btn_link1['url']."' target='".$btn_link1['target']."'>";
$return.="<span class='inv-button-6-text'>";
$return.=$btn_text1;
$return.="</span>";
$return.="</a>";
$return.="</div>";
$return.="</div>";

$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';
return $return;

}

elseif($button_style1== "seven")
{

$return="<div id='".$uniqid."' class='inv-button-wrapper inv-button-7-wrapper ".$button_size_class." ".$button_align1." ".$extra_class1."'>";
$return.="<div class='inv-button-inner inv-button-7-inner'>";
$return.="<a class='inv-button-content inv-button-7-content' href='".$btn_link1['url']."' target='".$btn_link1['target']."'>";
$return.=$btn_text1;
$return.="</a>";
$return.="</div>";
$return.="</div>";

$return.=	'<script type="text/javascript">
		(function(jQuery) {';

		if($css_rules != '') {
					$return.= 'jQuery("head").append("<style>'.$css_rules.'</style>")';
						}

					$return.=	'
					})(jQuery);
						</script>';
return $return;

}

}


