<?php
/**
 *
 * script template
 *
 */

/*testimonial slider*/
global $out,$auto1,$speed1,$slidetoshow1,$slidetoscroll1,$testimonial_dots,$testimonial_arrows,$rows1,$slidesperrow1,$infinite1,$background1;


global $timeline_color1,$time_hover_color1,$test_bg_color1;

global $icon_hover_border_color1,$icon_box_border_color1,$icon_color1,$hover_color1,$dots_color1,$ins_opt;

global $blog_auto1,$blog_speed1,$blog_slidetoshow1,$blog_slidetoscroll1,$blog_dots,$blog_arrows,$blog_rows1,$blog_slidesperrow1,$blog_infinite1;

global $port_auto1,$port_speed1,$port_slidetoshow1,$port_slidetoscroll1,$port_dots,$port_arrows,$port_rows1,$port_slidesperrow1,$port_infinite1;

/*images carousel*/

global $design_style1, $multiple_imgs1, $extra_class1, $carousel_speed1, $imgs_slidetoshow1, $imgs_slidetoscroll1, $carousel_infinite1, $post; 


/*counter box*/

global $date1,$label_font1,$date_font1,$date_color1,$label_color1,$hour1,$minute1,$time1;

global $user_id1,$access_token1,$insta_autoplay1,$insta_speed1,$insta_slidetoshow1,$insta_slidetoscroll1,$insta_dots1,$insta_arrows1,$insta_rows1,$insta_slidesperrow1,$insta_infinite1,$insta_field1,$tag_name1,$limit1,$client_id1; 

?>




<script type="text/javascript">


jQuery(document).on('ready', function() {

jQuery('<style>.inv-layout-4-testimonials-text-box:after{ border-top-color: <?php echo $test_bg_color1; ?> !important;}</style>').appendTo('head');

jQuery('<style>.inv-pricing-plan-inner.inv-pricing-plan-featured.centered-box ul li:nth-child(odd){ background: <?php echo $background1; ?> !important;}</style>').appendTo('head');



});
</script>



<script>


jQuery('.inv-carousel-imgs-inner').slick({
        dots: false,
        arrows: false,
   <?php if ( isset( $carousel_infinite1) ) {?>
     infinite: <?php echo esc_html($carousel_infinite1); ?>,
        <?php }?>
 <?php if ( !empty( $carousel_speed1) ) {?>
     speed: <?php echo esc_html($carousel_speed1); ?>,
        <?php }?>
 <?php if ( !empty( $imgs_slidetoshow1) ) {?>
    slidesToShow: <?php echo esc_html($imgs_slidetoshow1); ?>,
        <?php }?>
        <?php if ( !empty( $imgs_slidetoscroll1) ) {?>
    slidesToScroll: <?php echo esc_html($imgs_slidetoscroll1); ?>,
        <?php }?>
        
    responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
   
  ]
});


</script>






<script type="text/javascript">

  
     jQuery(document).on('ready', function() {
      jQuery(".inv-testimonial-slider").slick({
      
      
     <?php if ( isset( $testimonial_dots) ) {?>
        dots: <?php echo esc_html($testimonial_dots); ?>,<?php }?>
      
        
     <?php if ( !empty ( $slidetoshow1 ) ) {?>

          slidesToShow: <?php echo esc_html($slidetoshow1); ?>,<?php }?>

          <?php if ( !empty ( $slidetoscroll1) ) {?>
        slidesToScroll: <?php echo esc_html($slidetoscroll1); ?>,<?php }?>
          
          <?php if ( isset( $testimonial_arrows) ) {?>
         arrows:<?php echo $testimonial_arrows;?>,<?php }?>


                   <?php if ( isset( $infinite1) ) {?>
                  infinite: <?php echo esc_html($infinite1); ?>,<?php }?>

                <?php if ( isset( $auto1) ) {?>
               autoplay: <?php echo esc_html($auto1); ?>,<?php }?>

           <?php if ( !empty ( $speed1) ) {?>
           autoplaySpeed: <?php echo esc_html($speed1); ?>,<?php }?>
             
<?php if ( !empty ( $rows1) ) {?>
             rows: <?php echo esc_html($rows1); ?>,<?php }?>


      <?php if ( !empty ( $slidesperrow1) ) {?>
      slidesPerRow: <?php echo esc_html($slidesperrow1); ?>,<?php } ?>
        
     responsive: [
    {
      breakpoint: 1024,
      settings: {

     
          slidesToShow:2,
      
        slidesToScroll: 1,
       <?php if ( isset( $infinite1) ) {?>
                  infinite: <?php echo esc_html($infinite1); ?>,<?php }?>
        <?php if ( isset( $testimonial_dots) ) {?>
            
        dots: <?php echo esc_html($testimonial_dots); ?>,<?php }?>

      }
    },
    {
      breakpoint: 600,
      settings: {
          
          slidesToShow: 1,
      
        slidesToScroll: 1,
         <?php if ( isset( $testimonial_dots) ) {?>
          
        dots: <?php echo esc_html($testimonial_dots); ?>,<?php }?>
      }
    }
  ]
      });
     
    });
</script>




<script>
  
jQuery('.example1 .slider-for').slick({
     <?php if ( !empty ( $slidetoshow1 ) ) {?>
          slidesToShow: <?php echo esc_html($slidetoshow1); ?>,<?php }?>
      <?php if ( !empty ( $slidetoscroll1) ) {?>
        slidesToScroll: <?php echo esc_html($slidetoscroll1); ?>,<?php }?>
    fade: false,
    asNavFor: '.example1 .slider-nav',
   <?php if ( isset( $testimonial_dots) ) {?>
        dots: <?php echo esc_html($testimonial_dots); ?>,<?php }?>
      <?php if ( isset( $testimonial_arrows) ) {?>
       
     arrows:<?php echo esc_html($testimonial_arrows); ?>, <?php }?>
    appendArrows: '.pr_images',
    prevArrow:'<i class="fa fa-angle-left slick-prev"></i>',
    nextArrow:'<i class="fa fa-angle-right slick-next"></i>'
});
jQuery('.example1 .slider-nav').slick({
    
   <?php if ( !empty ( $slidetoscroll1) ) {?>
        slidesToScroll: <?php echo esc_html($slidetoscroll1); ?>,<?php }?>
    asNavFor: '.example1 .slider-for',
  
      
      <?php if ( isset( $testimonial_arrows) ) {?>
     arrows:<?php echo esc_html($testimonial_arrows); ?>, <?php }?>
    <?php if ( isset( $infinite1) ) {?>
      infinite: <?php echo esc_html($infinite1); ?>, <?php }?>
    <?php if ( !empty ( $slidetoshow1 ) ) {?>
          slidesToShow: <?php echo esc_html($slidetoshow1); ?>,<?php }?>
    variableWidth: true,
    responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow:2,
      
        slidesToScroll: 1,
      
        <?php if ( isset( $testimonial_arrows) ) {?>
     arrows:<?php echo esc_html($testimonial_arrows); ?>, <?php }?>
    <?php if ( isset( $infinite1) ) {?>
      infinite: <?php echo esc_html($infinite1); ?>, <?php }?>
      
      }
    },
    {
      breakpoint: 600,
      settings: {
       slidesToShow:1,
      
        slidesToScroll: 1,
     
      <?php if ( isset( $testimonial_arrows) ) {?>
     arrows:<?php echo esc_html($testimonial_arrows); ?>, <?php }?>
    
      }
    },
    {
      breakpoint: 480,
      settings: {
      slidesToShow:1,
      
        slidesToScroll: 1,
      }
    }
  ],
    focusOnSelect: true
});



</script>





<script type="text/javascript">

  
     jQuery(document).on('ready', function() {
      jQuery(".ensign-carousel-slider").slick({
      
         <?php if ( !empty( $blog_dots) ) {?>
        dots: <?php echo esc_html($blog_dots); ?>,<?php }?>
      
        
     <?php if ( !empty ( $blog_slidetoshow1) ) {?>

          slidesToShow: <?php echo esc_html($blog_slidetoshow1); ?>,<?php }?>

          <?php if ( !empty ( $blog_slidetoscroll1) ) {?>
        slidesToScroll: <?php echo esc_html($blog_slidetoscroll1); ?>,<?php }?>
          
          <?php if ( !empty( $blog_arrows) ) {?>
         arrows:<?php echo $blog_arrows;?>,<?php }?>


                   <?php if ( !empty( $blog_infinite1) ) {?>
                  infinite: <?php echo esc_html($blog_infinite1); ?>,<?php }?>

                <?php if ( !empty ( $blog_auto1) ) {?>
               autoplay: <?php echo esc_html($blog_auto1); ?>,<?php }?>

           <?php if ( !empty ( $blog_speed1) ) {?>
           autoplaySpeed: <?php echo esc_html($blog_speed1); ?>,<?php }?>
             
<?php if ( !empty ( $blog_rows1) ) {?>
             rows: <?php echo esc_html($blog_rows1); ?>,<?php }?>


      <?php if ( !empty ( $blog_slidesperrow1) ) {?>
      slidesPerRow: <?php echo esc_html($blog_slidesperrow1); ?>,<?php } ?>
        adaptiveHeight: true,
     responsive: [
    {
      breakpoint: 1024,
      settings: {

     
          slidesToShow:2,
      
        slidesToScroll: 1,
       <?php if ( !empty( $blog_infinite1) ) {?>
                  infinite: <?php echo esc_html($blog_infinite1); ?>,<?php }?>
        <?php if ( !empty( $blog_dots) ) {?>
            
        dots: <?php echo esc_html($blog_dots); ?>,<?php }?>

      }
    },
    {
      breakpoint: 600,
      settings: {
          
          slidesToShow: 1,
      
        slidesToScroll: 1,
         <?php if ( !empty( $blog_dots) ) {?>
          
        dots: <?php echo esc_html($blog_dots); ?>,<?php }?>
      }
    }
  ]
      });
     
    });

</script>


<script type="text/javascript">

  
     jQuery(document).on('ready', function() {

       const slider = jQuery(".inv-portfolio-carousel-slider");
      slider
          .slick({
      
         <?php if ( !empty ( $port_dots) ) {?>
        dots: <?php echo esc_html($port_dots); ?>,<?php }?>
      
        
     <?php if ( !empty ( $port_slidetoshow1) ) {?>
          slidesToShow: <?php echo esc_html($port_slidetoshow1); ?>,<?php }?>

          <?php if ( !empty ( $port_slidetoscroll1) ) {?>
        slidesToScroll: <?php echo esc_html($port_slidetoscroll1); ?>,<?php }?>
          
          <?php if (!empty ( $port_arrows) ) {?>
         arrows:<?php echo $port_arrows;?>,<?php }?>


                   <?php if(!empty( $port_infinite1) ) {?>
                  infinite: <?php echo esc_html($port_infinite1); ?>,
                <?php } ?>
                     


       

                <?php if ( !empty( $port_auto1) ) {?>
               autoplay: <?php echo esc_html($port_auto1); ?>,<?php }?>

           <?php if ( !empty ( $port_speed1) ) {?>
           autoplaySpeed: <?php echo esc_html($port_speed1); ?>,<?php }?>
             
<?php if ( !empty ( $port_rows1) ) {?>
             rows: <?php echo esc_html($port_rows1); ?>,<?php }?>


      <?php if ( !empty ( $port_slidesperrow1) ) {?>
      slidesPerRow: <?php echo esc_html($port_slidesperrow1); ?>,<?php } ?>
        
     responsive: [
    {
      breakpoint: 1024,
      settings: {

     
          slidesToShow:2,
      
        slidesToScroll: 1,
       <?php if ( !empty( $port_infinite1) ) {?>
                  infinite: <?php echo esc_html($port_infinite1); ?>,<?php }?>
        <?php if ( !empty ( $port_dots) ) {?>
            
        dots: <?php echo esc_html($port_dots); ?>,<?php }?>

      }
    },
    {
      breakpoint: 600,
      settings: {
          
          slidesToShow: 1,
      
        slidesToScroll: 1,
         <?php if ( !empty ( $port_dots) ) {?>
          
        dots: <?php echo esc_html($port_dots); ?>,<?php }?>
      }
    }
  ]
      });
      
      slider.on('wheel', (function(e) {
  e.preventDefault();

  if (e.originalEvent.deltaY < 0) {
    jQuery(this).slick('slickNext');
  } else {
    jQuery(this).slick('slickPrev');
  }
}));

    });  
</script>


<script>
<?php if(!empty($date1)){?>
// Set the date we're counting down to
var countDownDate = new Date("<?php echo esc_html($date1); ?><?php if(!empty($hour1)){?><?php echo esc_html($hour1); ?>:<?php echo esc_html($minute1); ?><?php echo esc_html($time1); ?> <?php } ?>").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

    // Get todays date and time
    var now = new Date().getTime();
    
    // Find the distance between now an the count down date
    var distance = countDownDate - now;
    
    // Time calculations for days, hours, minutes and seconds
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        var timer;

    
    // Output the result in an element with id="demo"
   document.getElementById("getting-started").innerHTML ="<div class='counter-num-main-box clearfix'><div class='counter-main-element'>" + "<span class='counter-number-text' style='font-size:<?php echo $date_font1; ?>;color:<?php echo $date_color1; ?>'>"+ days + "</span>" + "<p class='counter-text' style='font-size:<?php echo $label_font1; ?>;color:<?php echo $label_color1; ?>'>" + "Days" + "</p>" + "</div></div>" + "<div class='counter-num-main-box clearfix'><div class='counter-main-element'>" + "<span class='counter-number-text' style='font-size:<?php echo $date_font1; ?>;color:<?php echo $date_color1; ?>'>" + hours + "</span> " + "<p class='counter-text' style='font-size:<?php echo $label_font1; ?>;color:<?php echo $label_color1; ?>'>" + "Hours" + "</p>" + "</div></div>" + "<div class='counter-num-main-box clearfix'><div class='counter-main-element'>" + "<span class='counter-number-text' style='font-size:<?php echo $date_font1; ?>;color:<?php echo $date_color1; ?>'>" +  minutes + "</span>" + "<p class='counter-text' style='font-size:<?php echo $label_font1; ?>;color:<?php echo $label_color1; ?>'>" + "Minutes" + "</p>" + "</div></div>" + "<div class='counter-num-main-box clearfix'><div class='counter-main-element'>" + "<span class='counter-number-text' style='font-size:<?php echo $date_font1; ?>;color:<?php echo $date_color1; ?>'>" + seconds + "</span>" + "<p class='counter-text' style='font-size:<?php echo $label_font1; ?>;color:<?php echo $label_color1; ?>'>" + "Seconds" + "</p>" + "</div></div>";
  
    
    // If the count down is over, write some text 
    if (distance < 0) {
        clearInterval(x);
        document.getElementById("getting-started").innerHTML = "EXPIRED";
    }
}, 1000);

<?php }?>
</script>

<script>

if ( jQuery( "#instafeed" ).length ) {

  var userFeed = new Instafeed({
<?php if($insta_field1== "First Option"){ ?>

        get: 'user',
          <?php if ( !empty ( $user_id1) ) {?>
        userId: <?php echo esc_html($user_id1); ?>,<?php }
        }
if($insta_field1== "Second Option"){ ?>

       get: 'tagged',
   <?php if ( !empty ( $tag_name1) ) {?>
        tagName:'<?php echo esc_html($tag_name1); ?>',<?php } ?>
   
    <?php
} ?>

        <?php
        if ( !empty ( $client_id1) ) {?>

        clientId: "<?php echo esc_html($client_id1); ?>",<?php }?>
      

      <?php
        if ( !empty ( $access_token1) ) {?>

        accessToken: "<?php echo esc_html($access_token1); ?>",<?php }?>
        resolution: "standard_resolution",
        <?php
        if ( !empty ( $limit1) ) {?>

        limit: <?php echo esc_html($limit1); ?>,<?php }?>
        
        sortBy: 'most-recent',
         template: 
        '<a href="{{link}}" target="_blank" id="{{id}}">'+
      '<div class="instagram-img-featured-container">'+
        '<div class="instagram-img-backdrop"></div>'+
        '<div class="instagram-description-container">'+
            
          '<span class="instagram-likes"><i class="fa fa-heart" aria-hidden="true"></i> {{likes}}</span>'+
          '<span class="instagram-comments"><i class="fa fa-comment" aria-hidden="true"></i> {{comments}}</span>'+
        '</div>'+
         '<div class="instagram-image" style="background-image: url({{image}})"></div>'+        
      '</div>'+
          '</a>',
     
         after: function() {
      jQuery('#instafeed').slick({
      
        <?php if ( isset( $insta_dots1) ) {?>
        dots: <?php echo esc_html($insta_dots1); ?>,<?php }?>
      
        
     <?php if ( !empty ( $insta_slidetoshow1) ) {?>

          slidesToShow: <?php echo esc_html($insta_slidetoshow1); ?>,<?php }?>

          <?php if ( !empty ( $insta_slidetoscroll1) ) {?>
        slidesToScroll: <?php echo esc_html($insta_slidetoscroll1); ?>,<?php }?>
          
          <?php if ( isset( $insta_arrows1) ) {?>
         arrows:<?php echo $insta_arrows1;?>,<?php }?>


                   <?php if ( isset( $insta_infinite1) ) {?>
                  infinite: <?php echo esc_html($insta_infinite1); ?>,<?php }?>

                <?php if ( isset( $insta_autoplay1) ) {?>
               autoplay: <?php echo esc_html($insta_autoplay1); ?>,<?php }?>

           <?php if ( !empty ( $insta_speed1) ) {?>
           autoplaySpeed: <?php echo esc_html($insta_speed1); ?>,<?php }?>
             
<?php if ( !empty ( $insta_rows1) ) {?>
             rows: <?php echo esc_html($insta_rows1); ?>,<?php }?>


      <?php if ( !empty ( $insta_slidesperrow1) ) {?>
      slidesPerRow: <?php echo esc_html($insta_slidesperrow1); ?>,<?php } ?>
        
     responsive: [
    {
      breakpoint: 1024,
      settings: {

     
          slidesToShow:2,
      
        slidesToScroll: 1,
       <?php if ( isset( $insta_infinite1) ) {?>
                  infinite: <?php echo esc_html($insta_infinite1); ?>,<?php }?>
        <?php if ( isset( $insta_dots1) ) {?>
            
        dots: <?php echo esc_html($insta_dots1); ?>,<?php }?>

      }
    },
    {
      breakpoint: 600,
      settings: {
          
          slidesToShow: 1,
      
        slidesToScroll: 1,
       dots:false,
      arrows:false,
        
            }
    }
  ]
        
      });
    }
    });
    userFeed.run();

}

</script>