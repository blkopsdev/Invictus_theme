<?php
function insignia_socials_sharing() {
 require_once plugin_dir_path( __FILE__)  .'/socials-sharing.php' ;
}
function insignia_socials_sharing_style2() {
 require_once plugin_dir_path( __FILE__)  .'/socials-sharing-style2.php' ;
}

?>